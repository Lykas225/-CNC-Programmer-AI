package ru.cncai.programmer.domain

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** COMP_LEFT / COMP_RIGHT: линейный ход с включением G41 / G42, COMP_OFF: линейный ход с отменой G40. */
enum class MoveType { RAPID, LINEAR, ARC_CW, ARC_CCW, COMP_LEFT, COMP_RIGHT, COMP_OFF }

/**
 * Кадр траектории центра фрезы в системе нуля детали.
 * Для дуг i, j — смещение центра дуги от начальной точки (как в Fanuc, G02/G03 с I J).
 * feed — подача мм/мин (для RAPID = 0).
 */
data class Move(
    val type: MoveType,
    val x: Double,
    val y: Double,
    val z: Double,
    val i: Double = 0.0,
    val j: Double = 0.0,
    val feed: Int = 0,
)

data class Line2(val x1: Double, val y1: Double, val x2: Double, val y2: Double, val rapid: Boolean)

object ArcMath {
    /** Угол дуги в радианах (> 0). Если начало и конец совпадают, это полный круг. */
    fun sweep(ccw: Boolean, x0: Double, y0: Double, x1: Double, y1: Double, cx: Double, cy: Double): Double {
        val a0 = atan2(y0 - cy, x0 - cx)
        val a1 = atan2(y1 - cy, x1 - cx)
        var s = if (ccw) a1 - a0 else a0 - a1
        while (s <= 1e-9) s += 2 * PI
        return s
    }
}

object PathPreview {
    /** Превращает кадры в отрезки для рисования вида сверху (дуги разбиваются на отрезки). */
    fun flatten(moves: List<Move>): List<Line2> {
        val out = ArrayList<Line2>()
        var x = 0.0
        var y = 0.0
        var first = true
        for (m in moves) {
            if (first) {
                x = m.x
                y = m.y
                first = false
                continue
            }
            when (m.type) {
                MoveType.RAPID, MoveType.LINEAR, MoveType.COMP_LEFT, MoveType.COMP_RIGHT, MoveType.COMP_OFF -> {
                    if (hypot(m.x - x, m.y - y) > 1e-9) out.add(Line2(x, y, m.x, m.y, m.type == MoveType.RAPID))
                }
                MoveType.ARC_CCW, MoveType.ARC_CW -> {
                    val ccw = m.type == MoveType.ARC_CCW
                    val cx = x + m.i
                    val cy = y + m.j
                    val r = hypot(m.i, m.j)
                    val a0 = atan2(y - cy, x - cx)
                    val sw = ArcMath.sweep(ccw, x, y, m.x, m.y, cx, cy)
                    val steps = max(4, ceil(sw / (PI / 24)).toInt())
                    var px = x
                    var py = y
                    for (s in 1..steps) {
                        val ang = a0 + (if (ccw) sw else -sw) * s / steps
                        val nx = if (s == steps) m.x else cx + r * cos(ang)
                        val ny = if (s == steps) m.y else cy + r * sin(ang)
                        out.add(Line2(px, py, nx, ny, false))
                        px = nx
                        py = ny
                    }
                }
            }
            x = m.x
            y = m.y
        }
        return out
    }
}

/** Элемент замкнутого контура; len нужен для равномерного спуска по Z. */
data class Seg(
    val type: MoveType,
    val x: Double,
    val y: Double,
    val i: Double,
    val j: Double,
    val len: Double,
)

data class Loop(val sx: Double, val sy: Double, val segs: List<Seg>) {
    val length: Double get() = segs.sumOf { it.len }
}

object Loops {
    private const val E = 1e-9

    private fun line(x: Double, y: Double, len: Double) = Seg(MoveType.LINEAR, x, y, 0.0, 0.0, len)

    private fun arc(ccw: Boolean, x: Double, y: Double, i: Double, j: Double, len: Double) =
        Seg(if (ccw) MoveType.ARC_CCW else MoveType.ARC_CW, x, y, i, j, len)

    private fun neg(v: Double): Double = if (v == 0.0) 0.0 else -v

    /** Зеркало относительно горизонтали y = cy: CCW становится CW. */
    private fun mirror(l: Loop, cy: Double): Loop = Loop(
        l.sx,
        2 * cy - l.sy,
        l.segs.map {
            val t = when (it.type) {
                MoveType.ARC_CCW -> MoveType.ARC_CW
                MoveType.ARC_CW -> MoveType.ARC_CCW
                else -> it.type
            }
            Seg(t, it.x, 2 * cy - it.y, it.i, neg(it.j), it.len)
        },
    )

    /** Прямоугольник со скруглёнными углами. Старт — середина правой стороны. */
    fun rect(cx: Double, cy: Double, hx: Double, hy: Double, c: Double, ccw: Boolean): Loop {
        val up = hy - c
        val top = 2 * (hx - c)
        val side = 2 * (hy - c)
        val q = c * PI / 2
        val s = ArrayList<Seg>()
        if (up > E) s.add(line(cx + hx, cy + up, up))
        if (c > E) s.add(arc(true, cx + hx - c, cy + hy, -c, 0.0, q))
        if (top > E) s.add(line(cx - hx + c, cy + hy, top))
        if (c > E) s.add(arc(true, cx - hx, cy + hy - c, 0.0, -c, q))
        if (side > E) s.add(line(cx - hx, cy - hy + c, side))
        if (c > E) s.add(arc(true, cx - hx + c, cy - hy, c, 0.0, q))
        if (top > E) s.add(line(cx + hx - c, cy - hy, top))
        if (c > E) s.add(arc(true, cx + hx, cy - hy + c, 0.0, c, q))
        if (up > E) s.add(line(cx + hx, cy, up))
        val l = Loop(cx + hx, cy, s)
        return if (ccw) l else mirror(l, cy)
    }

    /** Окружность. Старт — правая точка. */
    fun circle(cx: Double, cy: Double, r: Double, ccw: Boolean): Loop = Loop(
        cx + r, cy,
        listOf(
            arc(ccw, cx - r, cy, -r, 0.0, PI * r),
            arc(ccw, cx + r, cy, r, 0.0, PI * r),
        ),
    )

    /** Контур паза (две прямые и две полуокружности радиуса w вокруг отрезка P1-P2). */
    fun capsule(p1x: Double, p1y: Double, p2x: Double, p2y: Double, w: Double, ccw: Boolean): Loop {
        val len = hypot(p2x - p1x, p2y - p1y)
        val ux = (p2x - p1x) / len
        val uy = (p2y - p1y) / len
        val nx = -uy
        val ny = ux
        val sg = if (ccw) -1.0 else 1.0
        val sx = sg * nx
        val sy = sg * ny
        val mx = (p1x + p2x) / 2
        val my = (p1y + p2y) / 2
        val s = listOf(
            line(p2x + sx * w, p2y + sy * w, len / 2),
            arc(ccw, p2x - sx * w, p2y - sy * w, -sx * w, -sy * w, PI * w),
            line(p1x - sx * w, p1y - sy * w, len),
            arc(ccw, p1x + sx * w, p1y + sy * w, sx * w, sy * w, PI * w),
            line(mx + sx * w, my + sy * w, len / 2),
        )
        return Loop(mx + sx * w, my + sy * w, s)
    }

    /** Паз по ширине фрезы: туда и обратно по осевой линии. */
    fun slotLine(p1x: Double, p1y: Double, p2x: Double, p2y: Double): Loop {
        val len = hypot(p2x - p1x, p2y - p1y)
        return Loop(p1x, p1y, listOf(line(p2x, p2y, len), line(p1x, p1y, len)))
    }
}

/** Накапливает кадры и считает длину пути и время. */
class PathBuilder(private val feed: Int, val plungeFeed: Int, zStart: Double) {
    val moves = ArrayList<Move>()
    var x = 0.0
        private set
    var y = 0.0
        private set
    var z = zStart
        private set
    var cutLen = 0.0
        private set
    var rapidLen = 0.0
        private set
    var cutTimeMin = 0.0
        private set

    private fun d3(dx: Double, dy: Double, dz: Double) = sqrt(dx * dx + dy * dy + dz * dz)

    fun rapid(nx: Double, ny: Double, nz: Double) {
        rapidLen += d3(nx - x, ny - y, nz - z)
        moves.add(Move(MoveType.RAPID, nx, ny, nz))
        x = nx
        y = ny
        z = nz
    }

    fun line(nx: Double, ny: Double, nz: Double, f: Int = feed) {
        val d = d3(nx - x, ny - y, nz - z)
        cutLen += d
        cutTimeMin += d / f
        moves.add(Move(MoveType.LINEAR, nx, ny, nz, feed = f))
        x = nx
        y = ny
        z = nz
    }

    /** Линейный ход с включением (on) или отменой (off) коррекции на радиус. */
    fun compLine(on: Boolean, nx: Double, ny: Double, nz: Double, f: Int = feed) {
        val d = d3(nx - x, ny - y, nz - z)
        cutLen += d
        cutTimeMin += d / f
        moves.add(Move(if (on) MoveType.COMP_LEFT else MoveType.COMP_OFF, nx, ny, nz, feed = f))
        x = nx
        y = ny
        z = nz
    }

    fun arc(ccw: Boolean, nx: Double, ny: Double, nz: Double, i: Double, j: Double, f: Int = feed) {
        val r = hypot(i, j)
        val sw = ArcMath.sweep(ccw, x, y, nx, ny, x + i, y + j)
        val d = d3(r * sw, 0.0, nz - z)
        cutLen += d
        cutTimeMin += d / f
        moves.add(Move(if (ccw) MoveType.ARC_CCW else MoveType.ARC_CW, nx, ny, nz, i, j, f))
        x = nx
        y = ny
        z = nz
    }

    /** Поднять до высоты отвода, если ниже. */
    fun toSafe(zSafe: Double) {
        if (z < zSafe - 1e-9) rapid(x, y, zSafe)
    }

    /** Вверх быстро, вниз с подачей врезания. */
    fun moveZ(nz: Double) {
        if (nz > z + 1e-9) rapid(x, y, nz) else if (nz < z - 1e-9) line(x, y, nz, plungeFeed)
    }

    /** Проход по контуру, высота плавно меняется от z0 к z1 (спираль). Станок уже в начале контура. */
    fun runLoop(l: Loop, z0: Double, z1: Double) {
        val total = l.segs.sumOf { it.len }
        val f = if (abs(z1 - z0) > 1e-9) plungeFeed else feed
        var cum = 0.0
        for (s in l.segs) {
            cum += s.len
            val zz = if (total > 1e-12) z0 + (z1 - z0) * cum / total else z1
            if (s.type == MoveType.LINEAR) line(s.x, s.y, zz, f) else arc(s.type == MoveType.ARC_CCW, s.x, s.y, zz, s.i, s.j, f)
        }
    }
}
