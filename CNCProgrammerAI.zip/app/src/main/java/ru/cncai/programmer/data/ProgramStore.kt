package ru.cncai.programmer.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

/** Сохранённая программа. Версии одной программы имеют одинаковое имя и растущий номер version. */
data class SavedProgram(
    val id: Long,
    val name: String,
    val version: Int,
    val text: String,
    val time: Long,
    val source: String, // generated, imported, created, version
)

object ProgramStore {
    const val MAX_LENGTH = 600_000
    val list = mutableStateListOf<SavedProgram>()
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.getSharedPreferences("cnc_programs", Context.MODE_PRIVATE)
        val s = prefs?.getString("list", null) ?: return
        try {
            val arr = JSONArray(s)
            val loaded = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                SavedProgram(
                    o.getLong("id"), o.getString("name"), o.getInt("version"),
                    o.getString("text"), o.getLong("time"), o.optString("source", "created"),
                )
            }
            list.clear()
            list.addAll(loaded)
        } catch (e: Exception) {
            // повреждённые данные: библиотека остаётся пустой
        }
    }

    /** Добавляет программу; если имя уже есть, создаётся следующая версия. Возвращает null, если текст слишком большой. */
    fun add(name: String, text: String, source: String): SavedProgram? {
        if (text.length > MAX_LENGTH) return null
        val nm = name.trim().ifBlank { "Программа" }
        val ver = (list.filter { it.name == nm }.maxOfOrNull { it.version } ?: 0) + 1
        val id = (list.maxOfOrNull { it.id } ?: 0L) + 1
        val p = SavedProgram(id, nm, ver, text, System.currentTimeMillis(), source)
        list.add(p)
        persist()
        return p
    }

    fun update(id: Long, text: String): Boolean {
        if (text.length > MAX_LENGTH) return false
        val i = list.indexOfFirst { it.id == id }
        if (i < 0) return false
        list[i] = list[i].copy(text = text, time = System.currentTimeMillis())
        persist()
        return true
    }

    fun delete(id: Long) {
        list.removeAll { it.id == id }
        persist()
    }

    fun renameAll(oldName: String, newName: String) {
        val nn = newName.trim()
        if (nn.isEmpty() || nn == oldName) return
        for (i in list.indices) {
            if (list[i].name == oldName) list[i] = list[i].copy(name = nn)
        }
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("name", it.name).put("version", it.version)
                    .put("text", it.text).put("time", it.time).put("source", it.source)
            )
        }
        prefs?.edit()?.putString("list", arr.toString())?.apply()
    }
}
