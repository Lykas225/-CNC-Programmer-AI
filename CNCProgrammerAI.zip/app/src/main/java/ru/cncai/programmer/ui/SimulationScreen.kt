package ru.cncai.programmer.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.MacroCatalog
import ru.cncai.programmer.data.PostStore
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.data.Tool
import ru.cncai.programmer.domain.CompApplier
import ru.cncai.programmer.domain.GcodeGenerator
import ru.cncai.programmer.domain.MacroEntry
import ru.cncai.programmer.domain.MacroRunner
import ru.cncai.programmer.domain.PostSettings
import ru.cncai.programmer.domain.Project
import ru.cncai.programmer.domain.SimBuilder
import ru.cncai.programmer.domain.SimPath
import ru.cncai.programmer.domain.SimState
import ru.cncai.programmer.domain.SimStock
import ru.cncai.programmer.domain.SimTool
import ru.cncai.programmer.domain.ToolRef
import ru.cncai.programmer.domain.ToolSpec
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private val SWarn = Color(0xFFFFB84D)
private val SErr = Color(0xFFFF6B6B)
private const val BASE_SPEED = 40.0

private class SimData(
    val lines: List<String>,
    val path: SimPath,
    val state: SimState,
    val stock: SimStock,
    val tools: Map<Int, SimTool>,
    val warnings: List<String>,
)

/** Формирует G-код проекта, прогоняет его интерпретатором и готовит симуляцию. */
private fun buildSim(
    project: Project,
    post: PostSettings,
    maxRpm: Int,
    tools: List<Tool>,
    macros: List<MacroEntry>,
): Pair<SimData?, List<String>> {
    val refs = tools.map { ToolRef(it.id, ToolSpec(it.name, it.type, it.diameter, it.teeth, it.cuttingLength), it.t, it.h, it.d) }
    val g = GcodeGenerator.generate(project, refs, post, maxRpm, macros)
    if (g.errors.isNotEmpty()) return Pair(null, g.errors)
    val text = g.lines.joinToString("\n")
    val run = MacroRunner.run(text, emptyMap(), Triple(0.0, 0.0, 100.0))
    if (run.errors.isNotEmpty()) return Pair(null, run.errors.map { "Симуляция: $it" })
    val simTools = HashMap<Int, SimTool>()
    val radiusByD = HashMap<Int, Double>()
    for (t in tools) {
        simTools[t.t] = SimTool(t.t, t.name, t.diameter / 2, t.type == "Сферическая фреза")
        radiusByD[t.d] = t.diameter / 2
    }
    val comp = CompApplier.apply(run.moves, run.infos, radiusByD)
    val stock = SimStock(project.part)
    val path = SimBuilder.build(comp.moves, comp.infos, stock.cs * 0.5)
    val state = SimState(stock, path, simTools)
    state.analyze()
    return Pair(SimData(g.lines, path, state, stock, simTools, g.warnings + comp.warnings), emptyList())
}

@Composable
fun SimulationScreen(onBack: () -> Unit) {
    val project = ProjectStore.current.value
    var reload by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var errors by remember { mutableStateOf<List<String>>(emptyList()) }
    var data by remember { mutableStateOf<SimData?>(null) }

    LaunchedEffect(reload) {
        loading = true
        val tools = Library.tools.toList()
        val post = PostStore.settings.value
        val macros = MacroCatalog.entries()
        val rpm = Library.maxRpm.intValue
        val res = withContext(Dispatchers.Default) {
            try {
                buildSim(project, post, rpm, tools, macros)
            } catch (e: Exception) {
                Pair(null, listOf("Ошибка симуляции: ${e.message}"))
            }
        }
        data = res.first
        errors = res.second
        loading = false
    }

    ScreenFrame("Симуляция траектории", onBack) {
        val d = data
        if (loading) {
            Text("Расчёт симуляции…", color = Muted)
            Spacer(Modifier.height(12.dp))
            CircularProgressIndicator()
        } else if (d == null) {
            Text("Симуляцию построить не удалось:", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            errors.forEach { Text("• $it", color = SErr, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)) }
            Spacer(Modifier.height(8.dp))
            Button(onClick = { reload += 1 }, modifier = Modifier.fillMaxWidth()) { Text("Повторить") }
        } else {
            SimBody(d) { reload += 1 }
        }
    }
}

@Composable
private fun SimBody(d: SimData, onReload: () -> Unit) {
    val path = d.path
    val st = d.stock
    var pos by remember(d) { mutableDoubleStateOf(0.0) }
    var playing by remember(d) { mutableStateOf(false) }
    var speedIdx by remember { mutableIntStateOf(2) }
    var view3d by remember { mutableStateOf(false) }
    var byTool by remember { mutableStateOf(false) }
    var angle by remember { mutableFloatStateOf(35f) }
    val speeds = listOf(1.0, 3.0, 10.0, 30.0, 100.0)
    val total = path.total

    LaunchedEffect(playing, d) {
        if (!playing) return@LaunchedEffect
        var last = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1e9
            last = now
            pos += BASE_SPEED * speeds[speedIdx] * dt
            if (pos >= total) {
                pos = total
                playing = false
                break
            }
        }
    }

    val p = path.indexAt(pos.coerceIn(0.0, total))
    d.state.seek(p)

    val bmp = remember(d) { Bitmap.createBitmap(st.nx, st.ny, Bitmap.Config.ARGB_8888) }
    val pixels = remember(d) { IntArray(st.nx * st.ny) }
    val gn = 48
    val vh: FloatArray? = if (view3d) d.state.vertexHeights(gn) else null
    if (!view3d) {
        d.state.fillPixels(pixels, byTool)
        bmp.setPixels(pixels, 0, st.nx, 0, 0, st.nx, st.ny)
    }

    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!view3d) Button(onClick = { view3d = false }, modifier = Modifier.weight(1f)) { Text("2D") }
        else OutlinedButton(onClick = { view3d = false }, modifier = Modifier.weight(1f)) { Text("2D") }
        if (view3d) Button(onClick = { view3d = true }, modifier = Modifier.weight(1f)) { Text("3D") }
        else OutlinedButton(onClick = { view3d = true }, modifier = Modifier.weight(1f)) { Text("3D") }
        OutlinedButton(onClick = { byTool = !byTool }, modifier = Modifier.weight(2f)) {
            Text(if (byTool) "Цвет: по инструменту" else "Цвет: по глубине")
        }
    }

    Canvas(Modifier.fillMaxWidth().height(320.dp).clip(RoundedCornerShape(14.dp)).background(Panel)) {
        if (vh == null) draw2D(d, bmp, p) else draw3D(d, p, angle, vh, gn, byTool)
    }
    if (view3d) {
        Text("Поворот вида", color = Muted, fontSize = 12.sp)
        Slider(value = angle, onValueChange = { angle = it }, valueRange = 0f..360f)
    }

    Slider(
        value = if (total > 0) (pos / total).toFloat().coerceIn(0f, 1f) else 0f,
        onValueChange = { pos = it.toDouble() * total; playing = false },
        valueRange = 0f..1f,
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedButton(onClick = { pos = 0.0; playing = false }, modifier = Modifier.weight(1f)) { Text("⏮") }
        OutlinedButton(onClick = { pos = path.cum[path.prevMove(p)]; playing = false }, modifier = Modifier.weight(1f)) { Text("◀") }
        Button(
            onClick = {
                if (!playing && pos >= total) pos = 0.0
                playing = !playing
            },
            modifier = Modifier.weight(2f),
        ) { Text(if (playing) "⏸ Пауза" else "▶ Пуск") }
        OutlinedButton(onClick = { pos = path.cum[path.nextMove(p)]; playing = false }, modifier = Modifier.weight(1f)) { Text("▶") }
        OutlinedButton(onClick = { pos = total; playing = false }, modifier = Modifier.weight(1f)) { Text("⏭") }
    }
    Spacer(Modifier.height(8.dp))
    Picker("Скорость", listOf("1×", "3×", "10×", "30×", "100×"), speedIdx) { speedIdx = it }

    val tool = d.tools[path.tool[p]]
    PanelCard {
        Text(
            "X ${path.x[p].toDouble().fmt2()}  Y ${path.y[p].toDouble().fmt2()}  Z ${path.z[p].toDouble().fmt2()}",
            fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold,
        )
        Text(
            (if (path.cut[p]) "рабочий ход" else "быстрый ход") + " • " +
                (if (path.tool[p] == 0) "инструмент не выбран" else "T${path.tool[p]} ${tool?.name ?: ""}") +
                " • шпиндель " + (if (path.spindle[p]) "вкл" else "выкл"),
            color = Muted, fontSize = 13.sp,
        )
    }

    val ln = path.line[p]
    val first = if (ln <= 0) 1 else max(1, ln - 3)
    val last = min(d.lines.size, if (ln <= 0) 6 else ln + 3)
    PanelCard {
        Text("Текущая строка G-кода", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Column(Modifier.horizontalScroll(rememberScrollState())) {
            for (k in first..last) {
                val on = k == ln
                Text(
                    "$k  ${d.lines[k - 1]}",
                    fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                    color = if (on) Color(0xFFFBBF24) else Muted,
                )
            }
        }
    }

    Text("Контроль программы", fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(4.dp))
    if (d.state.issues.isEmpty()) {
        Text("Замечаний нет: быстрых ходов в материале, выхода ниже низа детали и работы без шпинделя не найдено.", color = Color(0xFF4ADE80), fontSize = 13.sp)
    }
    d.state.issues.take(15).forEach {
        Text(
            "• стр.${it.line}: ${it.message}",
            color = SErr, fontSize = 13.sp,
            modifier = Modifier.padding(bottom = 4.dp).clickable { pos = d.path.cum[it.point]; playing = false },
        )
    }
    if (d.state.issues.isNotEmpty()) Text("Нажмите на замечание, чтобы перейти к этому месту.", color = Muted, fontSize = 12.sp)
    d.warnings.forEach { Text("• $it", color = SWarn, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp)) }
    Spacer(Modifier.height(6.dp))
    Text(
        "Материал снимается по карте высот (${st.nx}×${st.ny}, ячейка ${st.cs.fmt2()} мм, плоский торец или сфера). " +
            "Симуляция показывает программу из раздела «Генерация G-кода» и не заменяет проверку на станке: " +
            "столкновения державки и зажимов не рассчитываются.",
        color = Muted, fontSize = 12.sp,
    )
    TextButton(onClick = onReload, modifier = Modifier.fillMaxWidth()) { Text("Пересчитать по текущему проекту") }
    Spacer(Modifier.height(16.dp))
}

private fun DrawScope.draw2D(d: SimData, bmp: Bitmap, p: Int) {
    val st = d.stock
    val path = d.path
    val pad = 12.dp.toPx()
    val w = st.nx * st.cs
    val h = st.ny * st.cs
    val scale = minOf((size.width - 2 * pad) / w, (size.height - 2 * pad) / h)
    val ox = (size.width - w * scale) / 2.0
    val oy = (size.height - h * scale) / 2.0
    drawImage(
        image = bmp.asImageBitmap(),
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(st.nx, st.ny),
        dstOffset = IntOffset(ox.roundToInt(), oy.roundToInt()),
        dstSize = IntSize((w * scale).roundToInt(), (h * scale).roundToInt()),
        filterQuality = FilterQuality.None,
    )
    val yTop = st.yMin + h
    fun px(x: Double): Float = (ox + (x - st.xMin) * scale).toFloat()
    fun py(y: Double): Float = (oy + (yTop - y) * scale).toFloat()

    val stride = max(1, p / 3000)
    var k = 0
    while (k < p) {
        val nk = min(k + stride, p)
        drawLine(
            color = if (path.cut[nk]) Color(0xCCFBBF24) else Color(0x33FFFFFF),
            start = Offset(px(path.x[k].toDouble()), py(path.y[k].toDouble())),
            end = Offset(px(path.x[nk].toDouble()), py(path.y[nk].toDouble())),
            strokeWidth = if (path.cut[nk]) 1.5f else 1f,
        )
        k = nk
    }
    val tool = d.tools[path.tool[p]]
    val r = tool?.radius ?: 3.0
    val c = Offset(px(path.x[p].toDouble()), py(path.y[p].toDouble()))
    drawCircle(color = Color(0xFFEF4444), radius = (r * scale).toFloat().coerceAtLeast(3f), center = c, style = Stroke(width = 2f))
    drawLine(color = Color(0xFFEF4444), start = Offset(c.x - 8f, c.y), end = Offset(c.x + 8f, c.y), strokeWidth = 2f)
    drawLine(color = Color(0xFFEF4444), start = Offset(c.x, c.y - 8f), end = Offset(c.x, c.y + 8f), strokeWidth = 2f)
}

private fun DrawScope.draw3D(d: SimData, p: Int, angleDeg: Float, vh: FloatArray, gn: Int, byTool: Boolean) {
    val st = d.stock
    val path = d.path
    val th = Math.toRadians(angleDeg.toDouble())
    val cosT = cos(th)
    val sinT = sin(th)
    val phi = Math.toRadians(38.0)
    val sinP = sin(phi)
    val cosP = cos(phi)
    val diag = hypot(st.w, st.hgt)
    val thick = st.zTop - st.zBot
    val scale = 0.9 * minOf(size.width / diag, size.height / (diag * sinP + (thick + 40.0) * cosP))
    val midZ = (st.zTop + st.zBot) / 2
    fun proj(x: Double, y: Double, z: Double): Offset {
        val dx = x - st.cxw
        val dy = y - st.cyw
        val xr = dx * cosT - dy * sinT
        val yr = dx * sinT + dy * cosT
        val sx = size.width / 2.0 + xr * scale
        val sy = size.height / 2.0 - (yr * sinP + (z - midZ) * cosP) * scale
        return Offset(sx.toFloat(), sy.toFloat())
    }
    val stride = gn + 1
    fun vx(iv: Int): Double = st.xMin + st.w * iv / gn
    fun vy(jv: Int): Double = st.yMin + st.hgt * jv / gn
    val quad = Path()
    fun fillQuad(a: Offset, b: Offset, c: Offset, e: Offset, color: Color) {
        quad.reset()
        quad.moveTo(a.x, a.y)
        quad.lineTo(b.x, b.y)
        quad.lineTo(c.x, c.y)
        quad.lineTo(e.x, e.y)
        quad.close()
        drawPath(quad, color)
    }
    val side = Color(0xFF3B4558)

    if (!st.round) {
        for (iv in 0 until gn) {
            // нижняя (по Y) и верхняя кромки
            fillQuad(
                proj(vx(iv), vy(0), vh[iv].toDouble()), proj(vx(iv + 1), vy(0), vh[iv + 1].toDouble()),
                proj(vx(iv + 1), vy(0), st.zBot), proj(vx(iv), vy(0), st.zBot), side,
            )
            fillQuad(
                proj(vx(iv), vy(gn), vh[gn * stride + iv].toDouble()), proj(vx(iv + 1), vy(gn), vh[gn * stride + iv + 1].toDouble()),
                proj(vx(iv + 1), vy(gn), st.zBot), proj(vx(iv), vy(gn), st.zBot), side,
            )
        }
        for (jv in 0 until gn) {
            fillQuad(
                proj(vx(0), vy(jv), vh[jv * stride].toDouble()), proj(vx(0), vy(jv + 1), vh[(jv + 1) * stride].toDouble()),
                proj(vx(0), vy(jv + 1), st.zBot), proj(vx(0), vy(jv), st.zBot), side,
            )
            fillQuad(
                proj(vx(gn), vy(jv), vh[jv * stride + gn].toDouble()), proj(vx(gn), vy(jv + 1), vh[(jv + 1) * stride + gn].toDouble()),
                proj(vx(gn), vy(jv + 1), st.zBot), proj(vx(gn), vy(jv), st.zBot), side,
            )
        }
    }

    class Cell(val i: Int, val j: Int, val depth: Double)
    val cells = ArrayList<Cell>()
    for (j in 0 until gn) {
        for (i in 0 until gn) {
            val mx = (vx(i) + vx(i + 1)) / 2
            val my = (vy(j) + vy(j + 1)) / 2
            if (st.round && hypot(mx - st.cxw, my - st.cyw) > st.w / 2) continue
            cells.add(Cell(i, j, (mx - st.cxw) * sinT + (my - st.cyw) * cosT))
        }
    }
    cells.sortByDescending { it.depth }
    val cw = st.w / gn
    val ch = st.hgt / gn
    for (c in cells) {
        val i = c.i
        val j = c.j
        val h00 = vh[j * stride + i].toDouble()
        val h10 = vh[j * stride + i + 1].toDouble()
        val h11 = vh[(j + 1) * stride + i + 1].toDouble()
        val h01 = vh[(j + 1) * stride + i].toDouble()
        val avg = (h00 + h10 + h11 + h01) / 4
        val frac = ((st.zTop - avg) / max(0.001, thick)).toFloat().coerceIn(0f, 1f)
        val base = d.state.colorAt(frac, d.state.ownerAtVertex(gn, i, j), byTool)
        val gx = (h10 + h11 - h00 - h01) / (2 * cw)
        val gy = (h01 + h11 - h00 - h10) / (2 * ch)
        val gxr = gx * cosT - gy * sinT
        val gyr = gx * sinT + gy * cosT
        val shade = (1.0 + (gxr - gyr) * 0.35).coerceIn(0.55, 1.3)
        val r = (((base shr 16) and 0xFF) * shade).toInt().coerceIn(0, 255)
        val g = (((base shr 8) and 0xFF) * shade).toInt().coerceIn(0, 255)
        val b = ((base and 0xFF) * shade).toInt().coerceIn(0, 255)
        fillQuad(
            proj(vx(i), vy(j), h00), proj(vx(i + 1), vy(j), h10),
            proj(vx(i + 1), vy(j + 1), h11), proj(vx(i), vy(j + 1), h01),
            Color(r, g, b),
        )
    }

    val tool = d.tools[path.tool[p]]
    val rr = tool?.radius ?: 3.0
    val tx = path.x[p].toDouble()
    val ty = path.y[p].toDouble()
    val tz = path.z[p].toDouble()
    val tip = proj(tx, ty, tz)
    val top = proj(tx, ty, tz + 40.0)
    val hw = (rr * scale).toFloat().coerceAtLeast(2f)
    fillQuad(
        Offset(tip.x - hw, tip.y), Offset(tip.x + hw, tip.y),
        Offset(top.x + hw, top.y), Offset(top.x - hw, top.y),
        Color(0xCCEF4444),
    )
}
