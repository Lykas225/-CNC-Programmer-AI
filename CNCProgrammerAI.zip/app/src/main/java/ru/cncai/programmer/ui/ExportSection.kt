package ru.cncai.programmer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.ProgramStore
import ru.cncai.programmer.domain.ExportFormat
import ru.cncai.programmer.domain.ProgramExport

/** Экспорт программы в файл (.NC, .TAP, .TXT, .EIA), отправка текстом и сохранение в библиотеку. */
@Composable
fun ExportSection(baseName: String, text: String, source: String = "generated", showLibrary: Boolean = true) {
    val ctx = LocalContext.current
    var fmtIdx by remember { mutableIntStateOf(0) }
    val fmt = ExportFormat.entries[fmtIdx]
    val export = rememberExporter()
    PanelCard {
        Text("Экспорт и сохранение", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Picker("Формат файла", ExportFormat.entries.map { ".${it.ext}: ${it.title}" }, fmtIdx) { fmtIdx = it }
        Text("Имя файла: ${ProgramExport.fileName(baseName, fmt)}", color = Muted, fontSize = 13.sp)
        Text(fmt.note, color = Muted, fontSize = 12.sp)
        if (fmt != ExportFormat.TXT && ProgramExport.hasNonAsciiOutsideComments(text)) {
            Text(
                "В тексте есть не латинские символы вне комментариев: в файле они заменятся на «?». Исправьте программу в редакторе.",
                color = Color(0xFFFFB84D), fontSize = 12.sp,
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { export(ProgramExport.fileName(baseName, fmt), ProgramExport.bytes(text, fmt)) },
            modifier = Modifier.fillMaxWidth(),
            enabled = text.isNotBlank(),
        ) { Text("Сохранить файл…") }
        OutlinedButton(
            onClick = { shareText(ctx, baseName, ProgramExport.text(text, ExportFormat.TXT)) },
            modifier = Modifier.fillMaxWidth(),
            enabled = text.isNotBlank(),
        ) { Text("Отправить текстом") }
        if (showLibrary) {
            OutlinedButton(
                onClick = {
                    val sp = ProgramStore.add(baseName, text, source)
                    if (sp == null) toast(ctx, "Программа слишком большая для библиотеки")
                    else toast(ctx, "Сохранено в библиотеку: ${sp.name}, версия ${sp.version}")
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = text.isNotBlank(),
            ) { Text("Сохранить в библиотеку программ") }
        }
    }
}
