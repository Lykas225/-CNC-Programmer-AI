package ru.cncai.programmer.domain

import kotlin.math.hypot

enum class PartShape(val title: String) { RECT("Прямоугольная"), ROUND("Круглая") }

enum class ZeroXY(val title: String) {
    CORNER_LL("Левый нижний угол"),
    CORNER_LR("Правый нижний угол"),
    CORNER_UL("Левый верхний угол"),
    CORNER_UR("Правый верхний угол"),
    CENTER("Центр"),
}

enum class ZeroZ(val title: String) { TOP("Верх детали"), BOTTOM("Низ детали") }

enum class FeatureType(val title: String) {
    HOLE("Отверстие"),
    RECT_POCKET("Прямоугольный карман"),
    ROUND_POCKET("Круглый карман"),
    SLOT("Паз"),
}

/**
 * Заготовка. Для круглой детали sizeX = диаметр, sizeY = sizeX.
 * Все координаты считаются в системе нуля детали (X/Y по выбранной привязке).
 */
data class Part(
    val shape: PartShape,
    val sizeX: Double,
    val sizeY: Double,
    val thickness: Double,
    val zeroXY: ZeroXY,
    val zeroZ: ZeroZ,
    val wcs: String,
    val materialName: String,
) {
    val width: Double get() = sizeX
    val height: Double get() = if (shape == PartShape.ROUND) sizeX else sizeY

    val xMin: Double
        get() = when (zeroXY) {
            ZeroXY.CORNER_LL, ZeroXY.CORNER_UL -> 0.0
            ZeroXY.CORNER_LR, ZeroXY.CORNER_UR -> -width
            ZeroXY.CENTER -> -width / 2
        }
    val xMax: Double get() = xMin + width

    val yMin: Double
        get() = when (zeroXY) {
            ZeroXY.CORNER_LL, ZeroXY.CORNER_LR -> 0.0
            ZeroXY.CORNER_UL, ZeroXY.CORNER_UR -> -height
            ZeroXY.CENTER -> -height / 2
        }
    val yMax: Double get() = yMin + height

    val cx: Double get() = (xMin + xMax) / 2
    val cy: Double get() = (yMin + yMax) / 2
}

/**
 * Элемент геометрии. Смысл полей по типам:
 * HOLE / ROUND_POCKET: x, y — центр, a — диаметр
 * RECT_POCKET: x, y — центр, a — размер по X, b — размер по Y, r — радиус угла
 * SLOT: x, y — начало, x2, y2 — конец, a — ширина
 * depth — глубина от верха детали.
 */
data class Feature(
    val id: Long,
    val type: FeatureType,
    val x: Double,
    val y: Double,
    val x2: Double,
    val y2: Double,
    val a: Double,
    val b: Double,
    val r: Double,
    val depth: Double,
)

data class Project(
    val name: String,
    val part: Part,
    val features: List<Feature>,
)

object GeometryValidator {
    private const val EPS = 1e-6
    private const val OUT = "Элемент выходит за контур детали"

    private fun circleInside(p: Part, x: Double, y: Double, rad: Double): Boolean =
        when (p.shape) {
            PartShape.RECT ->
                x - rad >= p.xMin - EPS && x + rad <= p.xMax + EPS &&
                    y - rad >= p.yMin - EPS && y + rad <= p.yMax + EPS
            PartShape.ROUND -> hypot(x - p.cx, y - p.cy) + rad <= p.sizeX / 2 + EPS
        }

    private fun rectInside(p: Part, cx: Double, cy: Double, w: Double, h: Double): Boolean {
        val x1 = cx - w / 2
        val x2 = cx + w / 2
        val y1 = cy - h / 2
        val y2 = cy + h / 2
        return when (p.shape) {
            PartShape.RECT ->
                x1 >= p.xMin - EPS && x2 <= p.xMax + EPS && y1 >= p.yMin - EPS && y2 <= p.yMax + EPS
            PartShape.ROUND -> {
                val rr = p.sizeX / 2 + EPS
                hypot(x1 - p.cx, y1 - p.cy) <= rr && hypot(x1 - p.cx, y2 - p.cy) <= rr &&
                    hypot(x2 - p.cx, y1 - p.cy) <= rr && hypot(x2 - p.cx, y2 - p.cy) <= rr
            }
        }
    }

    fun validate(part: Part, f: Feature): String? {
        if (f.depth <= 0) return "Глубина должна быть больше 0"
        if (f.depth > part.thickness + EPS) return "Глубина больше толщины детали"
        when (f.type) {
            FeatureType.HOLE, FeatureType.ROUND_POCKET -> {
                if (f.a <= 0) return "Диаметр должен быть больше 0"
                if (!circleInside(part, f.x, f.y, f.a / 2)) return OUT
            }
            FeatureType.RECT_POCKET -> {
                if (f.a <= 0 || f.b <= 0) return "Размеры кармана должны быть больше 0"
                if (f.r < 0 || f.r > minOf(f.a, f.b) / 2 + EPS) return "Радиус угла не больше половины меньшей стороны"
                if (!rectInside(part, f.x, f.y, f.a, f.b)) return OUT
            }
            FeatureType.SLOT -> {
                if (f.a <= 0) return "Ширина паза должна быть больше 0"
                if (hypot(f.x2 - f.x, f.y2 - f.y) <= EPS) return "Начало и конец паза совпадают"
                if (!circleInside(part, f.x, f.y, f.a / 2) || !circleInside(part, f.x2, f.y2, f.a / 2)) return OUT
            }
        }
        return null
    }
}
