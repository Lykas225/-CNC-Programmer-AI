package ru.cncai.programmer.domain

enum class ExportFormat(val ext: String, val title: String, val note: String) {
    NC("NC", "программа ЧПУ Fanuc", "Текст программы как в приложении, строки CRLF, комментарии латиницей."),
    TAP("TAP", "лента ISO", "Знак % в начале и конце, заглавные буквы, строки CRLF."),
    TXT("TXT", "обычный текст UTF-8", "Без преобразований, строки LF. Подходит для просмотра и пересылки."),
    EIA("EIA", "компактный ISO-код", "Знак % в начале и конце, заглавные буквы, без пробелов между словами. Это текстовый файл, а не двоичный код перфоленты EIA RS-244."),
}

object ProgramExport {
    private val COMMENT = Regex("\\([^)]*\\)")

    fun fileName(base: String, f: ExportFormat): String {
        val safe = GcodeGenerator.ascii(base).replace(' ', '_').replace(Regex("[^A-Za-z0-9_.-]"), "")
        return (if (safe.isBlank()) "PROGRAM" else safe) + "." + f.ext
    }

    private fun splitLines(src: String): List<String> =
        src.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { it.trimEnd() }.dropLastWhile { it.isEmpty() }

    private fun wrapPercent(lines: List<String>): List<String> {
        val out = ArrayList(lines)
        if (out.isEmpty() || out.first().trim() != "%") out.add(0, "%")
        if (out.last().trim() != "%") out.add("%")
        return out
    }

    /** Убирает пробелы вне комментариев. */
    private fun compact(line: String): String {
        val sb = StringBuilder()
        var last = 0
        for (m in COMMENT.findAll(line)) {
            sb.append(line.substring(last, m.range.first).filter { !it.isWhitespace() })
            sb.append(m.value)
            last = m.range.last + 1
        }
        sb.append(line.substring(last).filter { !it.isWhitespace() })
        return sb.toString()
    }

    fun text(src: String, f: ExportFormat): String {
        val lines = splitLines(src)
        return when (f) {
            ExportFormat.TXT -> lines.joinToString("\n") + "\n"
            ExportFormat.NC -> lines.map { GcodeGenerator.sanitizeComments(it) }.joinToString("\r\n") + "\r\n"
            ExportFormat.TAP -> wrapPercent(lines.map { GcodeGenerator.sanitizeComments(it).uppercase() }).joinToString("\r\n") + "\r\n"
            ExportFormat.EIA -> wrapPercent(lines.map { compact(GcodeGenerator.sanitizeComments(it).uppercase()) }).joinToString("\r\n") + "\r\n"
        }
    }

    /** Байты файла: TXT в UTF-8, остальные форматы в ASCII (прочие символы заменяются на «?»). */
    fun bytes(src: String, f: ExportFormat): ByteArray {
        val t = text(src, f)
        if (f == ExportFormat.TXT) return t.toByteArray(Charsets.UTF_8)
        val out = ByteArray(t.length)
        for (i in t.indices) out[i] = if (t[i].code < 128) t[i].code.toByte() else '?'.code.toByte()
        return out
    }

    /** Есть ли символы вне ASCII за пределами комментариев (в комментариях они транслитерируются). */
    fun hasNonAsciiOutsideComments(src: String): Boolean =
        COMMENT.replace(src, "").any { it.code > 127 }
}

/** Приводит программу к аккуратному виду: заглавные буквы, пробелы между словами, перенумерация N. */
object ProgramFormatter {
    private val COMMENT = Regex("\\([^)]*\\)")
    private val WORD = Regex("([A-Z])([-+]?(?:\\d+\\.?\\d*|\\.\\d+))")
    private val LABEL = Regex("^N(\\d+)")
    private val MACRO_START = Regex("^(IF|WHILE|GOTO|DO\\d|END\\d)")

    fun format(text: String, renumber: Boolean, step: Int): String {
        val out = ArrayList<String>()
        var n = step.coerceAtLeast(1)
        val st = step.coerceAtLeast(1)
        for (raw in text.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            val line = raw.trim()
            if (line.isEmpty()) {
                out.add("")
                continue
            }
            if (line == "%") {
                out.add("%")
                continue
            }
            val comments = COMMENT.findAll(line).map { it.value }.toList()
            val code = COMMENT.replace(line, "").uppercase().replace(Regex("\\s+"), "")
            if (code.isEmpty()) {
                out.add(line)
                continue
            }
            val lm = LABEL.find(code)
            val body = if (lm != null) code.substring(lm.value.length) else code
            val isHeader = Regex("^O\\d+").containsMatchIn(body)
            val isMacro = body.contains('#') || body.contains('[') || MACRO_START.containsMatchIn(body)
            val tail = if (comments.isEmpty()) "" else " " + comments.joinToString(" ")
            if (isHeader || isMacro || body.isEmpty()) {
                out.add((if (lm != null) lm.value + " " else "") + body + tail)
                continue
            }
            val words = WORD.findAll(body).map { it.value }.toList()
            if (words.joinToString("") != body) {
                out.add(line.uppercase())
                continue
            }
            val nPart = if (renumber) {
                val s = "N$n "
                n += st
                s
            } else if (lm != null) lm.value + " " else ""
            out.add(nPart + words.joinToString(" ") + tail)
        }
        return out.joinToString("\n")
    }
}
