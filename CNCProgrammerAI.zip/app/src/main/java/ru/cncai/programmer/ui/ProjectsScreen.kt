package ru.cncai.programmer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.ProjectMeta
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.domain.GcodeGenerator

/** Вкладка «Проекты»: список, открытие, копия, переименование, удаление, импорт и экспорт файла проекта. */
@Composable
fun ProjectsScreen() {
    val ctx = LocalContext.current
    val currentId = ProjectStore.currentId.longValue
    var action by remember { mutableStateOf<ProjectMeta?>(null) }
    var showNew by remember { mutableStateOf(false) }
    var renameFor by remember { mutableStateOf<ProjectMeta?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val export = rememberExporter()
    val import = rememberImporter { _, text ->
        if (ProjectStore.importJson(text)) toast(ctx, "Проект добавлен в список") else toast(ctx, "Файл не похож на проект CNC Programmer AI")
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Проекты", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Button(onClick = { showNew = true }, modifier = Modifier.fillMaxWidth()) { Text("Новый проект") }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { import() }, modifier = Modifier.weight(1f)) { Text("Импорт файла") }
            OutlinedButton(
                onClick = {
                    val p = ProjectStore.current.value
                    export(
                        GcodeGenerator.ascii(p.name).replace(' ', '_').ifBlank { "PROJECT" } + ".cncai.json",
                        ProjectStore.exportJson(p).toByteArray(Charsets.UTF_8),
                    )
                },
                modifier = Modifier.weight(1f),
            ) { Text("Экспорт текущего") }
        }
        Spacer(Modifier.height(6.dp))
        ProjectStore.projects.sortedByDescending { it.updated }.forEach { m ->
            PanelCard(onClick = { action = m; confirmDelete = false }) {
                Row {
                    Text(m.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    if (m.id == currentId) Text("открыт", color = Color(0xFF4ADE80), fontSize = 12.sp)
                }
                Text("Изменён: ${formatTime(m.updated)}", color = Muted, fontSize = 13.sp)
            }
        }
        Text(
            "Нажмите на проект, чтобы открыть, копировать, переименовать или удалить его. Все разделы приложения работают с открытым проектом.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
        )
    }

    if (showNew) {
        var name by remember { mutableStateOf("Новый проект") }
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("Новый проект") },
            text = { TextInput("Название", name) { name = it } },
            confirmButton = { TextButton(onClick = { ProjectStore.newProject(name); showNew = false }) { Text("Создать") } },
            dismissButton = { TextButton(onClick = { showNew = false }) { Text("Отмена") } },
        )
    }
    renameFor?.let { m ->
        var name by remember(m.id) { mutableStateOf(m.name) }
        AlertDialog(
            onDismissRequest = { renameFor = null },
            title = { Text("Переименовать") },
            text = { TextInput("Название", name) { name = it } },
            confirmButton = { TextButton(onClick = { ProjectStore.rename(m.id, name); renameFor = null }) { Text("Сохранить") } },
            dismissButton = { TextButton(onClick = { renameFor = null }) { Text("Отмена") } },
        )
    }
    action?.let { m ->
        AlertDialog(
            onDismissRequest = { action = null },
            title = { Text(m.name) },
            text = {
                Column {
                    TextButton(onClick = { ProjectStore.open(m.id); action = null }, modifier = Modifier.fillMaxWidth()) { Text("Открыть") }
                    TextButton(onClick = { ProjectStore.duplicate(m.id); action = null }, modifier = Modifier.fillMaxWidth()) { Text("Сделать копию") }
                    TextButton(onClick = { renameFor = m; action = null }, modifier = Modifier.fillMaxWidth()) { Text("Переименовать") }
                    TextButton(
                        onClick = {
                            if (confirmDelete) {
                                ProjectStore.delete(m.id)
                                action = null
                            } else confirmDelete = true
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text(if (confirmDelete) "Точно удалить?" else "Удалить", color = Color(0xFFFF6B6B)) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { action = null }) { Text("Закрыть") } },
        )
    }
}
