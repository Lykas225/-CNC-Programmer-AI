package ru.cncai.programmer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.MacroCatalog
import ru.cncai.programmer.data.PostStore
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.data.Tool
import ru.cncai.programmer.domain.CheckCategory
import ru.cncai.programmer.domain.CheckContext
import ru.cncai.programmer.domain.CheckReport
import ru.cncai.programmer.domain.CheckSeverity
import ru.cncai.programmer.domain.CheckTool
import ru.cncai.programmer.domain.GcodeGenerator
import ru.cncai.programmer.domain.MacroEntry
import ru.cncai.programmer.domain.PostSettings
import ru.cncai.programmer.domain.ProgramChecker
import ru.cncai.programmer.domain.Project
import ru.cncai.programmer.domain.ToolRef
import ru.cncai.programmer.domain.ToolSpec

private val COk = Color(0xFF4ADE80)
private val CWarn = Color(0xFFFFB84D)
private val CErr = Color(0xFFFF6B6B)
private const val MAX_ISSUES_SHOWN = 120

private class GenResult(val text: String?, val errors: List<String>, val report: CheckReport?)

private fun ctxOf(project: Project, tools: List<Tool>, maxRpm: Int): CheckContext =
    CheckContext(
        project.part,
        tools.map { CheckTool(it.t, it.name, it.diameter / 2, it.d, it.h, it.type == "Сферическая фреза") },
        maxRpm,
    )

private suspend fun generateAndCheck(
    project: Project,
    post: PostSettings,
    maxRpm: Int,
    tools: List<Tool>,
    macros: List<MacroEntry>,
): GenResult = withContext(Dispatchers.Default) {
    try {
        val refs = tools.map { ToolRef(it.id, ToolSpec(it.name, it.type, it.diameter, it.teeth, it.cuttingLength), it.t, it.h, it.d) }
        val g = GcodeGenerator.generate(project, refs, post, maxRpm, macros)
        if (g.errors.isNotEmpty()) {
            GenResult(null, g.errors, null)
        } else {
            val text = g.lines.joinToString("\n")
            GenResult(text, emptyList(), ProgramChecker.check(text, ctxOf(project, tools, maxRpm)))
        }
    } catch (e: Exception) {
        GenResult(null, listOf("Ошибка проверки: ${e.message}"), null)
    }
}

private suspend fun checkText(text: String, project: Project, tools: List<Tool>, maxRpm: Int): GenResult =
    withContext(Dispatchers.Default) {
        try {
            GenResult(text, emptyList(), ProgramChecker.check(text, ctxOf(project, tools, maxRpm)))
        } catch (e: Exception) {
            GenResult(text, listOf("Ошибка проверки: ${e.message}"), null)
        }
    }

@Composable
fun ProgramCheckScreen(onBack: () -> Unit) {
    val project = ProjectStore.current.value
    var text by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<CheckReport?>(null) }
    var genErrors by remember { mutableStateOf<List<String>>(emptyList()) }
    var busy by remember { mutableStateOf(true) }
    var edited by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        val r = generateAndCheck(project, PostStore.settings.value, Library.maxRpm.intValue, Library.tools.toList(), MacroCatalog.entries())
        genErrors = r.errors
        r.text?.let { text = it }
        report = r.report
        busy = false
    }

    ScreenFrame("Проверка УП", onBack) {
        Button(
            onClick = {
                scope.launch {
                    busy = true
                    val r = generateAndCheck(project, PostStore.settings.value, Library.maxRpm.intValue, Library.tools.toList(), MacroCatalog.entries())
                    genErrors = r.errors
                    r.text?.let { text = it }
                    report = r.report
                    edited = false
                    busy = false
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Сформировать из проекта и проверить") }
        Spacer(Modifier.height(8.dp))

        if (busy) {
            Text("Проверка выполняется…", color = Muted)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
        }
        if (genErrors.isNotEmpty()) {
            Text("Программу сформировать не удалось:", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            genErrors.forEach { Text("• $it", color = CErr, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)) }
            Spacer(Modifier.height(6.dp))
        }

        val rep = report
        if (rep != null) ReportView(rep, text)

        Spacer(Modifier.height(10.dp))
        Text("Текст программы (можно править и проверять заново)", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it; edited = true },
            modifier = Modifier.fillMaxWidth(),
            minLines = 6,
            maxLines = 14,
            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
        )
        Spacer(Modifier.height(6.dp))
        OutlinedButton(
            onClick = {
                scope.launch {
                    busy = true
                    val r = checkText(text, project, Library.tools.toList(), Library.maxRpm.intValue)
                    genErrors = r.errors
                    report = r.report
                    busy = false
                }
            },
            enabled = !busy && text.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (edited) "Проверить изменённый текст" else "Проверить текст ещё раз") }

        Spacer(Modifier.height(12.dp))
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Готово") }
        PanelCard {
            Text("Советы", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(
                "Проверка находит формальные и типовые ошибки, но не заменяет прогон на станке. Перед запуском проверьте программу " +
                    "в покадровом режиме на холостом ходу, нули G54–G59, значения H и D в корректорах и режимы резания по каталогу инструмента.",
                color = Muted, fontSize = 13.sp,
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ReportView(rep: CheckReport, text: String) {
    val lines = remember(text) { text.split('\n') }
    val ok = rep.errors == 0 && rep.warnings == 0
    val bannerColor = when {
        rep.errors > 0 -> CErr
        rep.warnings > 0 -> CWarn
        else -> COk
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bannerColor.copy(alpha = 0.18f)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(if (rep.errors > 0) "✗" else if (rep.warnings > 0) "⚠" else "✓", fontSize = 28.sp, color = bannerColor)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(
                when {
                    ok -> "Ошибок не найдено"
                    rep.errors > 0 -> "Найдено ошибок: ${rep.errors}" + if (rep.warnings > 0) ", предупреждений: ${rep.warnings}" else ""
                    else -> "Критичных ошибок нет, предупреждений: ${rep.warnings}"
                },
                fontWeight = FontWeight.Bold, fontSize = 17.sp,
            )
            Text("Строк в программе: ${rep.lineCount}", color = Muted, fontSize = 13.sp)
        }
    }
    Spacer(Modifier.height(10.dp))
    PanelCard {
        Text("Проверено", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        CheckCategory.entries.forEach { c ->
            val st = rep.status(c)
            val sym = when (st) {
                0 -> "✓"
                1 -> "⚠"
                else -> "✗"
            }
            val col = when (st) {
                0 -> COk
                1 -> CWarn
                else -> CErr
            }
            Row(Modifier.padding(vertical = 2.dp)) {
                Text(sym, color = col, modifier = Modifier.width(22.dp))
                Text(c.title + if (st != 0) " (${rep.count(c)})" else "", fontSize = 14.sp)
            }
        }
    }
    if (rep.issues.isNotEmpty()) {
        Text("Найденные замечания", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        rep.issues.take(MAX_ISSUES_SHOWN).forEach { it ->
            val col = if (it.severity == CheckSeverity.ERROR) CErr else CWarn
            PanelCard {
                Text(
                    (if (it.severity == CheckSeverity.ERROR) "Ошибка" else "Предупреждение") +
                        (if (it.line > 0) ", строка ${it.line}" else ""),
                    color = col, fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                )
                Text(it.message, fontSize = 14.sp)
                if (it.line in 1..lines.size) {
                    Spacer(Modifier.height(3.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        Text(lines[it.line - 1].trim(), color = Muted, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
                Text(it.category.title, color = Muted, fontSize = 11.sp)
            }
        }
        if (rep.issues.size > MAX_ISSUES_SHOWN) {
            Text("Показаны первые $MAX_ISSUES_SHOWN из ${rep.issues.size} замечаний.", color = Muted, fontSize = 12.sp)
        }
    }
}
