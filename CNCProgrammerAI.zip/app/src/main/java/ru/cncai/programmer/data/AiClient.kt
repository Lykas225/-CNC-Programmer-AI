package ru.cncai.programmer.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class AiResult(val text: String?, val error: String?)

/** Запрос к Claude (Anthropic Messages API) без сторонних библиотек. */
object AiClient {
    private const val URL_MESSAGES = "https://api.anthropic.com/v1/messages"
    private const val VERSION = "2023-06-01"

    suspend fun ask(
        apiKey: String,
        model: String,
        system: String,
        messages: List<Pair<String, String>>,
        maxTokens: Int = 3000,
    ): AiResult = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            conn = URL(URL_MESSAGES).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 120000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", apiKey)
            conn.setRequestProperty("anthropic-version", VERSION)
            val arr = JSONArray()
            for (m in messages) arr.put(JSONObject().put("role", m.first).put("content", m.second))
            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", maxTokens)
                .put("system", system)
                .put("messages", arr)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code in 200..299) {
                val o = JSONObject(resp)
                val content = o.optJSONArray("content")
                val sb = StringBuilder()
                if (content != null) {
                    for (i in 0 until content.length()) {
                        val c = content.getJSONObject(i)
                        if (c.optString("type") == "text") sb.append(c.optString("text"))
                    }
                }
                if (sb.isEmpty()) AiResult(null, "Пустой ответ модели") else AiResult(sb.toString(), null)
            } else {
                val msg = try {
                    JSONObject(resp).optJSONObject("error")?.optString("message") ?: ""
                } catch (e: Exception) {
                    ""
                }
                val human = when (code) {
                    401 -> "Неверный API-ключ (401). Проверьте ключ в настройках ИИ."
                    403 -> "Доступ запрещён (403): у ключа нет прав на эту модель или запрос."
                    404 -> "Модель не найдена (404). Выберите другую модель в настройках."
                    429 -> "Слишком много запросов или исчерпан лимит (429). Подождите и повторите."
                    413 -> "Запрос слишком большой (413). Уберите вложения или сократите программу."
                    500, 502, 503, 529 -> "Сервис ИИ перегружен или недоступен ($code). Повторите чуть позже."
                    else -> "Ошибка $code"
                }
                AiResult(null, if (msg.isNotBlank()) "$human\n$msg" else human)
            }
        } catch (e: IOException) {
            AiResult(null, "Нет подключения к интернету или сервер не отвечает.")
        } catch (e: Exception) {
            AiResult(null, "Ошибка запроса: ${e.message}")
        } finally {
            conn?.disconnect()
        }
    }
}
