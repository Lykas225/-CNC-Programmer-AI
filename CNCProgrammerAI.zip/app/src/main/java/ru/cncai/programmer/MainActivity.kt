package ru.cncai.programmer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import ru.cncai.programmer.data.AiStore
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.MacroStore
import ru.cncai.programmer.data.PostStore
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.ui.CncTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Library.init(applicationContext)
        ProjectStore.init(applicationContext)
        PostStore.init(applicationContext)
        MacroStore.init(applicationContext)
        AiStore.init(applicationContext)
        setContent { CncTheme { AppNav() } }
    }
}
