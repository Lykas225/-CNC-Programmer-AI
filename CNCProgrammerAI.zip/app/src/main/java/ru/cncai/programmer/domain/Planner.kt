package ru.cncai.programmer.domain

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Параметры инструмента для расчёта траектории. */
data class ToolSpec(
    val name: String,
    val type: String,
    val diameter: Double,
    val teeth: Int,
    val cuttingLength: Double,
)

/**
 * Операция в проекте.
 * ap: глубина за проход (для сверления — шаг врезания), ae: шаг по ширине,
 * allowance: припуск под чистовую на стенку (для сверления — перебег для сквозных отверстий),
 * depth: глубина (контур, торцовка), stock: снимаемый слой по периметру (наружный контур),
 * safeZ: высота отвода над верхом детали.
 * kind = "macro": вызов макроса G65 (macroRef — ссылка на макрос, args — аргументы).
 * featureId = 0: для сверления «все отверстия по диаметру сверла», для контура и торцовки не используется.
 */
data class OpInstance(
    val id: Long,
    val kind: String,
    val featureId: Long,
    val toolId: Long,
    val vc: Double,
    val fz: Double,
    val ap: Double,
    val ae: Double,
    val allowance: Double,
    val depth: Double,
    val stock: Double,
    val safeZ: Double,
    val macroRef: String = "",
    val args: String = "",
)

data class PlanResult(
    val moves: List<Move>,
    val rpm: Int,
    val feed: Int,
    val plungeFeed: Int,
    val cutLength: Double,
    val rapidLength: Double,
    val timeMin: Double,
    val warnings: List<String>,
)

data class PlanOutcome(val result: PlanResult?, val error: String?)

data class DrillTarget(val x: Double, val y: Double, val zBottom: Double)

object OperationPlanner {
    val supported = setOf("pocket_rect", "pocket_round", "slot", "drill", "contour_outer", "facing")

    /** Скорость быстрых перемещений для оценки времени, мм/мин. */
    const val RAPID_RATE = 10000.0
    const val PLUNGE_FACTOR = 0.5
    private const val EPS = 1e-6

    private class Ctx(
        val project: Project,
        val op: OpInstance,
        val tool: ToolSpec,
        val part: Part,
        val zTop: Double,
        val zSafe: Double,
        val rt: Double,
        val b: PathBuilder,
        val warnings: MutableList<String>,
        val useComp: Boolean,
    )

    private fun layers(depth: Double, step: Double): Int = ceil(depth / step - 1e-9).toInt().coerceAtLeast(1)

    private fun r1(v: Double): Double = (v * 10).roundToInt() / 10.0

    fun plan(project: Project, op: OpInstance, tool: ToolSpec, maxRpm: Int, useComp: Boolean = false): PlanOutcome {
        fun fail(msg: String) = PlanOutcome(null, msg)
        if (op.kind !in supported) return fail("Эта операция пока не поддерживается")
        val isDrill = op.kind == "drill"
        if (isDrill && tool.type != "Сверло") return fail("Для сверления нужен инструмент типа «Сверло»")
        if (!isDrill && (tool.type == "Сверло" || tool.type == "Резьбофреза")) {
            return fail("Для этой операции нужна фреза (выбрано: ${tool.type.lowercase()})")
        }
        if (tool.diameter <= 0 || tool.teeth < 1) return fail("Некорректные данные инструмента")
        if (op.vc <= 0 || op.fz <= 0) return fail("Vc и fz должны быть больше 0")
        if (maxRpm <= 0) return fail("Предел оборотов станка должен быть больше 0")
        if (op.ap <= 0) return fail(if (isDrill) "Шаг сверления должен быть больше 0" else "Глубина резания ap должна быть больше 0")
        if (!isDrill) {
            if (op.ap > tool.cuttingLength + EPS) return fail("ap больше рабочей длины фрезы")
            if (op.ae <= 0 || op.ae > tool.diameter + EPS) return fail("Ширина резания ae должна быть больше 0 и не больше диаметра фрезы")
        }
        if (op.allowance < 0) return fail("Припуск (перебег) не может быть отрицательным")
        if (op.safeZ < 2.0) return fail("Высота отвода над деталью: не меньше 2 мм")

        val part = project.part
        val zTop = if (part.zeroZ == ZeroZ.TOP) 0.0 else part.thickness
        val zSafe = zTop + op.safeZ
        val nIdeal = 1000.0 * op.vc / (PI * tool.diameter)
        val n = minOf(nIdeal, maxRpm.toDouble())
        val feed = (n * op.fz * tool.teeth).roundToInt().coerceAtLeast(1)
        val plunge = (feed * PLUNGE_FACTOR).roundToInt().coerceAtLeast(1)
        val b = PathBuilder(feed, plunge, zSafe)
        val warnings = mutableListOf<String>()
        if (nIdeal > maxRpm) {
            val vcAct = PI * tool.diameter * n / 1000.0
            warnings.add("Обороты ограничены станком (по Vc вышло бы ${nIdeal.roundToInt()}). Фактическая Vc ${r1(vcAct)} м/мин")
        }
        val c = Ctx(project, op, tool, part, zTop, zSafe, tool.diameter / 2, b, warnings, useComp)
        val err = when (op.kind) {
            "pocket_rect" -> planRectPocket(c)
            "pocket_round" -> planRoundPocket(c)
            "slot" -> planSlot(c)
            "drill" -> planDrill(c)
            "contour_outer" -> planOuter(c)
            "facing" -> planFacing(c)
            else -> "Эта операция пока не поддерживается"
        }
        if (err != null) return fail(err)
        b.toSafe(zSafe)
        val time = b.cutTimeMin + b.rapidLen / RAPID_RATE
        return PlanOutcome(
            PlanResult(b.moves, n.roundToInt(), feed, plunge, b.cutLen, b.rapidLen, time, warnings),
            null,
        )
    }

    private fun feat(c: Ctx, t: FeatureType): Feature? =
        c.project.features.firstOrNull { it.id == c.op.featureId && it.type == t }

    /**
     * Общая схема выборки: слои по глубине, на каждом первый контур проходится по спирали вниз,
     * затем плоско, затем остальные контуры к центру. После всех слоёв: чистовой проход по стенке.
     */
    private fun pocketLayers(c: Ctx, depth: Double, rough: List<Loop>, tail: (Double) -> Unit, finish: Loop?, finishComp: Boolean = false) {
        val b = c.b
        val first = rough[0]
        val n = layers(depth, c.op.ap)
        val step = depth / n
        val rampDeg = atan(step / first.length) * 180.0 / PI
        if (rampDeg > 20.0) {
            c.warnings.add("Крутой заход по спирали (${rampDeg.roundToInt()}°): уменьшите ap или увеличьте карман")
        }
        if (depth > c.tool.cuttingLength + EPS) {
            c.warnings.add("Глубина ${r1(depth)} мм больше рабочей длины фрезы: проверьте вылет и державку")
        }
        b.toSafe(c.zSafe)
        b.rapid(first.sx, first.sy, c.zSafe)
        b.rapid(first.sx, first.sy, c.zTop + 1.0)
        b.line(first.sx, first.sy, c.zTop, b.plungeFeed)
        var zPrev = c.zTop
        for (k in 1..n) {
            val z = c.zTop - step * k
            b.runLoop(first, zPrev, z)
            b.runLoop(first, z, z)
            for (idx in 1 until rough.size) {
                val lp = rough[idx]
                b.line(lp.sx, lp.sy, z)
                b.runLoop(lp, z, z)
            }
            tail(z)
            if (k < n) b.line(first.sx, first.sy, z)
            zPrev = z
        }
        if (finish != null) {
            val nf = layers(depth, c.tool.cuttingLength)
            b.line(first.sx, first.sy, zPrev)
            for (j in 1..nf) {
                val zf = c.zTop - depth * j / nf
                b.moveZ(zf)
                if (finishComp) {
                    b.compLine(true, finish.sx, finish.sy, zf)
                    b.runLoop(finish, zf, zf)
                    b.compLine(false, first.sx, first.sy, zf)
                } else {
                    b.line(finish.sx, finish.sy, zf)
                    b.runLoop(finish, zf, zf)
                    b.line(first.sx, first.sy, zf)
                }
            }
        }
    }

    private fun planRectPocket(c: Ctx): String? {
        val f = feat(c, FeatureType.RECT_POCKET) ?: return "Выберите прямоугольный карман из геометрии детали"
        val op = c.op
        val b = c.b
        val d0 = c.rt + op.allowance
        val hx0 = f.a / 2 - d0
        val hy0 = f.b / 2 - d0
        if (hx0 <= EPS || hy0 <= EPS) {
            return "Фреза слишком большая для кармана: меньший размер должен быть больше Ø фрезы + 2×припуск"
        }
        val c0 = maxOf(f.r - d0, 0.0)
        val m = minOf(hx0, hy0)
        val n = ceil(m / op.ae - 1e-9).toInt().coerceAtLeast(1)
        val aeE = m / n
        val rough = (0 until n).map { k ->
            Loops.rect(f.x, f.y, hx0 - k * aeE, hy0 - k * aeE, maxOf(c0 - k * aeE, 0.0), true)
        }
        val hxN = hx0 - n * aeE
        val hyN = hy0 - n * aeE
        val tail: (Double) -> Unit = { z ->
            if (hxN > EPS) {
                b.line(f.x + hxN, f.y, z)
                b.line(f.x - hxN, f.y, z)
            } else if (hyN > EPS) {
                b.line(f.x, f.y - hyN, z)
                b.line(f.x, f.y + hyN, z)
            } else {
                b.line(f.x, f.y, z)
            }
        }
        val compOk = c.useComp && f.r >= c.rt - EPS
        if (c.useComp && !compOk && op.allowance > EPS) {
            c.warnings.add("Радиус угла кармана меньше радиуса фрезы: чистовой проход без G41")
        }
        val finish = if (op.allowance > EPS) {
            if (compOk) Loops.rect(f.x, f.y, f.a / 2, f.b / 2, f.r, true)
            else Loops.rect(f.x, f.y, f.a / 2 - c.rt, f.b / 2 - c.rt, maxOf(f.r - c.rt, 0.0), true)
        } else null
        if (f.r < c.rt - EPS) {
            c.warnings.add("Радиус угла кармана R${r1(f.r)} меньше радиуса фрезы: в углах останется радиус фрезы")
        }
        pocketLayers(c, f.depth, rough, tail, finish, compOk && op.allowance > EPS)
        return null
    }

    private fun planRoundPocket(c: Ctx): String? {
        val f = feat(c, FeatureType.ROUND_POCKET) ?: return "Выберите круглый карман из геометрии детали"
        val op = c.op
        val b = c.b
        val r0 = f.a / 2 - (c.rt + op.allowance)
        if (r0 <= EPS) return "Фреза слишком большая для кармана: Ø кармана должен быть больше Ø фрезы + 2×припуск"
        val n = ceil(r0 / op.ae - 1e-9).toInt().coerceAtLeast(1)
        val aeE = r0 / n
        val rough = (0 until n).map { k -> Loops.circle(f.x, f.y, r0 - k * aeE, true) }
        val tail: (Double) -> Unit = { z -> b.line(f.x, f.y, z) }
        val finish = if (op.allowance > EPS) {
            Loops.circle(f.x, f.y, if (c.useComp) f.a / 2 else f.a / 2 - c.rt, true)
        } else null
        pocketLayers(c, f.depth, rough, tail, finish, c.useComp && op.allowance > EPS)
        return null
    }

    private fun planSlot(c: Ctx): String? {
        val f = feat(c, FeatureType.SLOT) ?: return "Выберите паз из геометрии детали"
        val op = c.op
        val b = c.b
        val len = hypot(f.x2 - f.x, f.y2 - f.y)
        if (len <= EPS) return "У паза нулевая длина"
        if (f.a < c.tool.diameter - EPS) return "Фреза шире паза"
        val w0 = f.a / 2 - (c.rt + op.allowance)
        if (w0 < -EPS) return "Припуск слишком большой для ширины паза"
        val rough: List<Loop>
        val tail: (Double) -> Unit
        if (w0 <= EPS) {
            rough = listOf(Loops.slotLine(f.x, f.y, f.x2, f.y2))
            tail = { _ -> }
        } else {
            val n = ceil(w0 / op.ae - 1e-9).toInt().coerceAtLeast(1)
            val aeE = w0 / n
            rough = (0 until n).map { k -> Loops.capsule(f.x, f.y, f.x2, f.y2, w0 - k * aeE, true) }
            tail = { z ->
                b.line(f.x, f.y, z)
                b.line(f.x2, f.y2, z)
            }
        }
        val finish = if (op.allowance > EPS) {
            Loops.capsule(f.x, f.y, f.x2, f.y2, if (c.useComp) f.a / 2 else f.a / 2 - c.rt, true)
        } else null
        pocketLayers(c, f.depth, rough, tail, finish, c.useComp && op.allowance > EPS)
        return null
    }

    private fun selectHoles(project: Project, op: OpInstance, dia: Double): Pair<List<Feature>, String?> {
        val holes: List<Feature> = if (op.featureId == 0L) {
            project.features.filter { it.type == FeatureType.HOLE && abs(it.a - dia) <= 0.05 }
        } else {
            val one = project.features.firstOrNull { it.id == op.featureId && it.type == FeatureType.HOLE }
                ?: return Pair(emptyList(), "Выбранное отверстие не найдено в геометрии детали")
            listOf(one)
        }
        if (holes.isEmpty()) return Pair(emptyList(), "В детали нет отверстий диаметром Ø${r1(dia)} мм")
        val bad = holes.firstOrNull { abs(it.a - dia) > 0.05 }
        if (bad != null) {
            return Pair(emptyList(), "Диаметр сверла Ø${r1(dia)} не совпадает с диаметром отверстия Ø${r1(bad.a)}")
        }
        val rest = holes.toMutableList()
        val ordered = ArrayList<Feature>()
        var px = 0.0
        var py = 0.0
        while (rest.isNotEmpty()) {
            val nx = rest.minByOrNull { hypot(it.x - px, it.y - py) }!!
            rest.remove(nx)
            ordered.add(nx)
            px = nx.x
            py = nx.y
        }
        return Pair(ordered, null)
    }

    /** Точки сверления в порядке обхода: координаты и Z дна (с учётом перебега для сквозных). */
    fun drillTargets(project: Project, op: OpInstance, diameter: Double): List<DrillTarget> {
        val sel = selectHoles(project, op, diameter)
        if (sel.second != null) return emptyList()
        val part = project.part
        val zTop = if (part.zeroZ == ZeroZ.TOP) 0.0 else part.thickness
        return sel.first.map { h ->
            val depth = if (h.depth >= part.thickness - EPS) h.depth + op.allowance else h.depth
            DrillTarget(h.x, h.y, zTop - depth)
        }
    }

    private fun planDrill(c: Ctx): String? {
        val op = c.op
        val b = c.b
        val sel = selectHoles(c.project, op, c.tool.diameter)
        if (sel.second != null) return sel.second
        val part = c.part
        val zR = c.zTop + 2.0
        for (h in sel.first) {
            val depth = if (h.depth >= part.thickness - EPS) h.depth + op.allowance else h.depth
            val np = layers(depth, op.ap)
            b.toSafe(c.zSafe)
            b.rapid(h.x, h.y, c.zSafe)
            b.rapid(h.x, h.y, zR)
            var zPrev = c.zTop
            for (p in 1..np) {
                val zp = c.zTop - depth * p / np
                if (p > 1) {
                    b.rapid(h.x, h.y, zR)
                    b.rapid(h.x, h.y, zPrev + 0.5)
                }
                b.line(h.x, h.y, zp)
                zPrev = zp
            }
        }
        return null
    }

    private fun planOuter(c: Ctx): String? {
        val op = c.op
        val part = c.part
        val b = c.b
        val rt = c.rt
        if (op.stock <= EPS) return "Укажите слой заготовки по периметру (больше 0)"
        if (op.depth <= 0 || op.depth > part.thickness + EPS) return "Глубина обработки: от 0 до толщины детали"
        val base = part.width / 2
        val baseHy = part.height / 2
        fun loopAt(d: Double): Loop =
            if (part.shape == PartShape.RECT) Loops.rect(part.cx, part.cy, base + d, baseHy + d, d, false)
            else Loops.circle(part.cx, part.cy, base + d, false)

        val rad = op.stock - op.allowance
        val nR = if (rad > EPS) ceil(rad / op.ae - 1e-9).toInt() else 0
        val aeE = if (nR > 0) rad / nR else 0.0
        val rough = (nR - 1 downTo 0).map { i -> loopAt(rt + op.allowance + i * aeE) }
        val finish = if (c.useComp) loopAt(0.0) else loopAt(rt)
        val ax = part.cx + base + op.stock + rt + 1.5
        val ay = part.cy
        val nl = layers(op.depth, op.ap)
        val step = op.depth / nl
        if (op.depth > c.tool.cuttingLength + EPS) {
            c.warnings.add("Глубина ${r1(op.depth)} мм больше рабочей длины фрезы: проверьте вылет и державку")
        }
        b.toSafe(c.zSafe)
        b.rapid(ax, ay, c.zSafe)
        b.rapid(ax, ay, c.zTop + 1.0)
        if (rough.isNotEmpty()) {
            for (k in 1..nl) {
                val z = c.zTop - step * k
                b.moveZ(z)
                for (lp in rough) {
                    b.line(lp.sx, lp.sy, z)
                    b.runLoop(lp, z, z)
                }
                b.line(ax, ay, z)
            }
        }
        val nf = layers(op.depth, c.tool.cuttingLength)
        for (j in 1..nf) {
            val zf = c.zTop - op.depth * j / nf
            b.moveZ(zf)
            if (c.useComp) {
                b.compLine(true, finish.sx, finish.sy, zf)
                b.runLoop(finish, zf, zf)
                b.compLine(false, ax, ay, zf)
            } else {
                b.line(finish.sx, finish.sy, zf)
                b.runLoop(finish, zf, zf)
                b.line(ax, ay, zf)
            }
        }
        return null
    }

    private fun planFacing(c: Ctx): String? {
        val op = c.op
        val part = c.part
        val b = c.b
        val rt = c.rt
        if (op.depth <= 0 || op.depth > part.thickness + EPS) return "Глубина торцовки: от 0 до толщины детали"
        val h = part.height
        val n = ceil(h / op.ae - 1e-9).toInt().coerceAtLeast(1)
        val aeE = h / n
        val nl = layers(op.depth, op.ap)
        val step = op.depth / nl
        fun extent(y: Double): Pair<Double, Double> =
            if (part.shape == PartShape.RECT) {
                Pair(part.xMin - rt - 2.0, part.xMax + rt + 2.0)
            } else {
                val dy = maxOf(abs(y - part.cy) - rt, 0.0)
                val rr = part.sizeX / 2
                val half = sqrt(maxOf(rr * rr - dy * dy, 0.0)) + rt + 2.0
                Pair(part.cx - half, part.cx + half)
            }
        var zPrev = c.zTop
        for (k in 1..nl) {
            val z = c.zTop - step * k
            val xStart = extent(part.yMin).first
            b.toSafe(c.zSafe)
            b.rapid(xStart, part.yMin, c.zSafe)
            b.rapid(xStart, part.yMin, zPrev + 1.0)
            b.line(xStart, part.yMin, z, b.plungeFeed)
            var dirRight = true
            for (j in 0..n) {
                val y = part.yMin + j * aeE
                val ex = extent(y)
                val sx = if (dirRight) ex.first else ex.second
                val tx = if (dirRight) ex.second else ex.first
                if (j > 0) b.line(sx, y, z)
                b.line(tx, y, z)
                dirRight = !dirRight
            }
            zPrev = z
        }
        return null
    }
}
