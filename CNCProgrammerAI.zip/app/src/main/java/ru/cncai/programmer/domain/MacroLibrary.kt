package ru.cncai.programmer.domain

data class MacroParam(val letter: String, val label: String)

data class MacroTemplate(
    val id: String,
    val name: String,
    val description: String,
    val defaultArgs: String,
    val params: List<MacroParam>,
    val source: String,
) {
    val program: Int get() = MacroParser.programNumber(source)
}

/** Готовые макросы Fanuc Macro B. Номера программ O9101–O9108. */
object MacroLibrary {
    val all: List<MacroTemplate> = listOf(
        MacroTemplate(
            id = "outer_rect",
            name = "Наружный контур (прямоугольник)",
            description = "Фреза обходит прямоугольный контур снаружи слоями по Z (по часовой, попутное фрезерование).",
            defaultArgs = "X50 Y35 I60 J40 R5 K0 Z-5 Q2.5 D10 F300 B5",
            params = listOf(
                MacroParam("X, Y", "центр прямоугольника"),
                MacroParam("I, J", "размеры по X и Y"),
                MacroParam("R", "радиус угла"),
                MacroParam("K", "верхняя плоскость Z (по умолчанию 0)"),
                MacroParam("Z", "глубина (дно)"),
                MacroParam("Q", "шаг по Z"),
                MacroParam("D", "диаметр фрезы"),
                MacroParam("F", "рабочая подача"),
                MacroParam("B", "безопасная высота (по умолчанию K+5)"),
                MacroParam("E", "подача врезания (по умолчанию F/2)"),
            ),
            source = """O9101 (NARUZHNYJ KONTUR PRYAMOUGOLNIK)
(X Y CENTR, I J RAZMERY, R RADIUS UGLA, K VERH Z, Z DNO)
(Q SHAG PO Z, D DIAM FREZY, F PODACHA, B BEZOP Z, E VREZANIE)
IF [#4 LE 0] THEN #3000=1 (NET RAZMERA I)
IF [#5 LE 0] THEN #3000=2 (NET RAZMERA J)
IF [#7 LE 0] THEN #3000=3 (NET DIAMETRA FREZY D)
IF [#17 LE 0] THEN #3000=4 (NET SHAGA Q)
IF [#9 LE 0] THEN #3000=5 (NET PODACHI F)
IF [#26 GE #6] THEN #3000=6 (Z DOLZHNO BYT NIZHE K)
IF [#2 EQ #0] THEN #2=#6+5
IF [#8 EQ #0] THEN #8=#9/2
#27=#4/2+#7/2
#28=#5/2+#7/2
#29=#18+#7/2
#30=#6
G00 Z#2
G00 X[#24+#27+3] Y#25
G00 Z[#6+1]
WHILE [#30 GT #26] DO 1
#30=#30-#17
IF [#30 LT #26] THEN #30=#26
G01 Z#30 F#8
G01 X[#24+#27] F#9
G01 Y[#25-#28+#29]
G02 X[#24+#27-#29] Y[#25-#28] I-#29 J0
G01 X[#24-#27+#29]
G02 X[#24-#27] Y[#25-#28+#29] I0 J#29
G01 Y[#25+#28-#29]
G02 X[#24-#27+#29] Y[#25+#28] I#29 J0
G01 X[#24+#27-#29]
G02 X[#24+#27] Y[#25+#28-#29] I0 J-#29
G01 Y#25
G01 X[#24+#27+3]
END 1
G00 Z#2
M99
""".trimIndent(),
        ),
        MacroTemplate(
            id = "inner_rect",
            name = "Внутренний контур (прямоугольник)",
            description = "Фреза обходит прямоугольное окно изнутри слоями (против часовой). Врезание вертикальное: нужна фреза с центральным резом.",
            defaultArgs = "X50 Y35 I60 J40 R8 K0 Z-5 Q2.5 D10 F300 B5",
            params = listOf(
                MacroParam("X, Y", "центр окна"),
                MacroParam("I, J", "размеры по X и Y"),
                MacroParam("R", "радиус угла"),
                MacroParam("K", "верхняя плоскость Z"),
                MacroParam("Z", "дно"),
                MacroParam("Q", "шаг по Z"),
                MacroParam("D", "диаметр фрезы"),
                MacroParam("F", "подача"),
                MacroParam("B", "безопасная высота"),
                MacroParam("E", "подача врезания"),
            ),
            source = """O9102 (VNUTRENNIJ KONTUR PRYAMOUGOLNIK)
(X Y CENTR, I J RAZMERY, R RADIUS UGLA, K VERH Z, Z DNO)
(Q SHAG PO Z, D DIAM FREZY, F PODACHA, B BEZOP Z, E VREZANIE)
(VREZANIE VERTIKALNOE: NUZHNA FREZA S CENTROVYM REZOM)
IF [#4 LE #7] THEN #3000=1 (I DOLZHNO BYT BOLSHE D)
IF [#5 LE #7] THEN #3000=2 (J DOLZHNO BYT BOLSHE D)
IF [#18 GT #4/2] THEN #3000=3 (R BOLSHE POLOVINY I)
IF [#18 GT #5/2] THEN #3000=4 (R BOLSHE POLOVINY J)
IF [#17 LE 0] THEN #3000=5 (NET SHAGA Q)
IF [#9 LE 0] THEN #3000=6 (NET PODACHI F)
IF [#26 GE #6] THEN #3000=7 (Z DOLZHNO BYT NIZHE K)
IF [#2 EQ #0] THEN #2=#6+5
IF [#8 EQ #0] THEN #8=#9/2
#27=#4/2-#7/2
#28=#5/2-#7/2
#29=#18-#7/2
IF [#29 LT 0.01] THEN #29=0.01
#30=#6
G00 Z#2
G00 X[#24+#27] Y#25
G00 Z[#6+1]
WHILE [#30 GT #26] DO 1
#30=#30-#17
IF [#30 LT #26] THEN #30=#26
G01 Z#30 F#8
G01 Y[#25+#28-#29] F#9
G03 X[#24+#27-#29] Y[#25+#28] I-#29 J0
G01 X[#24-#27+#29]
G03 X[#24-#27] Y[#25+#28-#29] I0 J-#29
G01 Y[#25-#28+#29]
G03 X[#24-#27+#29] Y[#25-#28] I#29 J0
G01 X[#24+#27-#29]
G03 X[#24+#27] Y[#25-#28+#29] I0 J#29
G01 Y#25
END 1
G00 Z#2
M99
""".trimIndent(),
        ),
        MacroTemplate(
            id = "facing",
            name = "Торцовка",
            description = "Торцовка прямоугольной области змейкой, слоями по Z. Заход и выход за пределами детали.",
            defaultArgs = "X50 Y35 I100 J70 K0 Z-1 Q0.5 D50 U35 F800 B5",
            params = listOf(
                MacroParam("X, Y", "центр области"),
                MacroParam("I, J", "размеры по X и Y"),
                MacroParam("K", "верхняя плоскость Z"),
                MacroParam("Z", "конечный Z"),
                MacroParam("Q", "шаг по Z"),
                MacroParam("D", "диаметр фрезы"),
                MacroParam("U", "шаг между проходами (по умолчанию 0.75·D)"),
                MacroParam("F", "подача"),
                MacroParam("B", "безопасная высота"),
            ),
            source = """O9103 (TORCOVKA)
(X Y CENTR, I J RAZMERY, K VERH Z, Z KONECHNYJ Z)
(Q SHAG PO Z, D DIAM FREZY, U SHAG PO Y, F PODACHA, B BEZOP Z)
IF [#4 LE 0] THEN #3000=1 (NET RAZMERA I)
IF [#5 LE 0] THEN #3000=2 (NET RAZMERA J)
IF [#7 LE 0] THEN #3000=3 (NET DIAMETRA FREZY D)
IF [#17 LE 0] THEN #3000=4 (NET SHAGA Q)
IF [#9 LE 0] THEN #3000=5 (NET PODACHI F)
IF [#26 GE #6] THEN #3000=6 (Z DOLZHNO BYT NIZHE K)
IF [#21 EQ #0] THEN #21=#7*0.75
IF [#21 GT #7] THEN #3000=7 (SHAG U BOLSHE DIAMETRA FREZY)
IF [#2 EQ #0] THEN #2=#6+5
IF [#8 EQ #0] THEN #8=#9/2
#27=#24-#4/2-#7/2-2
#28=#24+#4/2+#7/2+2
#29=FUP[#5/#21]
#31=#5/#29
#30=#6
#33=#6
WHILE [#30 GT #26] DO 1
#30=#30-#17
IF [#30 LT #26] THEN #30=#26
G00 Z#2
G00 X#27 Y[#25-#5/2]
G00 Z[#33+1]
G01 Z#30 F#8
#32=0
WHILE [#32 LE #29] DO 2
#10=#25-#5/2+#32*#31
#12=#28
IF [[#32 MOD 2] EQ 1] THEN #12=#27
G01 Y#10 F#9
G01 X#12
#32=#32+1
END 2
#33=#30
END 1
G00 Z#2
M99
""".trimIndent(),
        ),
        MacroTemplate(
            id = "pocket_round",
            name = "Круговой карман",
            description = "Круговой карман: концентрические окружности от центра к стенке, слоями по Z. Врезание в центре: нужна фреза с центральным резом.",
            defaultArgs = "X50 Y35 I40 K0 Z-8 Q2 D10 U4 F300 B5",
            params = listOf(
                MacroParam("X, Y", "центр кармана"),
                MacroParam("I", "диаметр кармана"),
                MacroParam("K", "верхняя плоскость Z"),
                MacroParam("Z", "дно"),
                MacroParam("Q", "шаг по Z"),
                MacroParam("D", "диаметр фрезы"),
                MacroParam("U", "шаг по радиусу (по умолчанию 0.4·D)"),
                MacroParam("F", "подача"),
                MacroParam("B", "безопасная высота"),
            ),
            source = """O9104 (KRUGOVOJ KARMAN)
(X Y CENTR, I DIAMETR KARMANA, K VERH Z, Z DNO)
(Q SHAG PO Z, D DIAM FREZY, U SHAG PO RADIUSU, F PODACHA, B BEZOP Z)
(VREZANIE V CENTRE: NUZHNA FREZA S CENTROVYM REZOM)
IF [#4 LE #7] THEN #3000=1 (DIAMETR KARMANA MENSHE FREZY)
IF [#7 LE 0] THEN #3000=2 (NET DIAMETRA FREZY D)
IF [#17 LE 0] THEN #3000=3 (NET SHAGA Q)
IF [#9 LE 0] THEN #3000=4 (NET PODACHI F)
IF [#26 GE #6] THEN #3000=5 (Z DOLZHNO BYT NIZHE K)
IF [#21 EQ #0] THEN #21=#7*0.4
IF [#21 LE 0] THEN #3000=6 (NET SHAGA U)
IF [#2 EQ #0] THEN #2=#6+5
IF [#8 EQ #0] THEN #8=#9/2
#27=#4/2-#7/2
#30=#6
#33=#6
WHILE [#30 GT #26] DO 1
#30=#30-#17
IF [#30 LT #26] THEN #30=#26
G00 Z#2
G00 X#24 Y#25
G00 Z[#33+1]
G01 Z#30 F#8
#32=#21
WHILE [#32 LT #27] DO 2
G01 X[#24+#32] Y#25 F#9
G03 I-#32 J0
#32=#32+#21
END 2
G01 X[#24+#27] Y#25 F#9
G03 I-#27 J0
#33=#30
END 1
G00 Z#2
M99
""".trimIndent(),
        ),
        MacroTemplate(
            id = "pocket_rect",
            name = "Прямоугольный карман",
            description = "Прямоугольный карман: змейка с заходом по наклонной на первом проходе и чистовой проход по периметру на каждом слое.",
            defaultArgs = "X50 Y35 I60 J40 K0 Z-6 Q2 D10 U4 F300 B5",
            params = listOf(
                MacroParam("X, Y", "центр кармана"),
                MacroParam("I, J", "размеры по X и Y"),
                MacroParam("K", "верхняя плоскость Z"),
                MacroParam("Z", "дно"),
                MacroParam("Q", "шаг по Z"),
                MacroParam("D", "диаметр фрезы"),
                MacroParam("U", "шаг по Y (по умолчанию 0.4·D)"),
                MacroParam("F", "подача"),
                MacroParam("B", "безопасная высота"),
            ),
            source = """O9105 (PRYAMOUGOLNYJ KARMAN)
(X Y CENTR, I J RAZMERY, K VERH Z, Z DNO)
(Q SHAG PO Z, D DIAM FREZY, U SHAG PO Y, F PODACHA, B BEZOP Z)
(ZAHOD PO NAKLONNOJ PERVOGO PROHODA)
IF [#4 LE #7] THEN #3000=1 (I DOLZHNO BYT BOLSHE D)
IF [#5 LE #7] THEN #3000=2 (J DOLZHNO BYT BOLSHE D)
IF [#17 LE 0] THEN #3000=3 (NET SHAGA Q)
IF [#9 LE 0] THEN #3000=4 (NET PODACHI F)
IF [#26 GE #6] THEN #3000=5 (Z DOLZHNO BYT NIZHE K)
IF [#21 EQ #0] THEN #21=#7*0.4
IF [#21 LE 0] THEN #3000=6 (NET SHAGA U)
IF [#2 EQ #0] THEN #2=#6+5
IF [#8 EQ #0] THEN #8=#9/2
#27=#4/2-#7/2
#28=#5/2-#7/2
#29=FUP[2*#28/#21]
#31=2*#28/#29
#30=#6
#33=#6
WHILE [#30 GT #26] DO 1
#30=#30-#17
IF [#30 LT #26] THEN #30=#26
G00 Z#2
G00 X[#24-#27] Y[#25-#28]
G00 Z[#33+1]
G01 Z#33 F#8
G01 X[#24+#27] Z#30 F#8
G01 X[#24-#27] F#9
#32=1
WHILE [#32 LE #29] DO 2
#10=#25-#28+#32*#31
#12=#24+#27
IF [[#32 MOD 2] EQ 0] THEN #12=#24-#27
G01 Y#10 F#9
G01 X#12
#32=#32+1
END 2
G01 X[#24+#27]
G01 Y[#25-#28]
G01 X[#24-#27]
G01 Y[#25+#28]
G01 X[#24+#27]
#33=#30
END 1
G00 Z#2
M99
""".trimIndent(),
        ),
        MacroTemplate(
            id = "hole_grid",
            name = "Сетка отверстий",
            description = "Сетка отверстий змейкой циклом G81 (Q=0) или G83 (Q>0).",
            defaultArgs = "X20 Y15 I15 J12 H4 K3 Z-10 R2 Q3 F150 B7",
            params = listOf(
                MacroParam("X, Y", "первое отверстие"),
                MacroParam("I, J", "шаг по X и Y"),
                MacroParam("H, K", "количество по X и Y"),
                MacroParam("Z", "глубина"),
                MacroParam("R", "плоскость R (по умолчанию 2)"),
                MacroParam("Q", "шаг сверления, 0 = G81"),
                MacroParam("F", "подача"),
                MacroParam("B", "начальная плоскость"),
            ),
            source = """O9106 (SETKA OTVERSTIJ)
(X Y PERVOE OTVERSTIE, I J SHAG PO X Y, H K KOLICHESTVO PO X Y)
(Z GLUBINA, R PLOSKOST R, Q SHAG SVERLENIYA 0=G81, F PODACHA, B NACHALNAYA PL)
IF [#11 LT 1] THEN #3000=1 (H KOLICHESTVO PO X)
IF [#6 LT 1] THEN #3000=2 (K KOLICHESTVO PO Y)
IF [#9 LE 0] THEN #3000=3 (NET PODACHI F)
IF [#18 EQ #0] THEN #18=2
IF [#26 GE #18] THEN #3000=4 (Z DOLZHNO BYT NIZHE R)
IF [#2 EQ #0] THEN #2=#18+5
G00 Z#2
G00 X#24 Y#25
IF [#17 GT 0] GOTO 20
G98 G81 X#24 Y#25 Z#26 R#18 F#9
GOTO 30
N20 G98 G83 X#24 Y#25 Z#26 R#18 Q#17 F#9
N30 #32=0
WHILE [#32 LT #6] DO 1
#12=0
WHILE [#12 LT #11] DO 2
IF [[#32 EQ 0] AND [#12 EQ 0]] GOTO 40
#14=#24+#12*#4
IF [[#32 MOD 2] EQ 1] THEN #14=#24+[#11-1-#12]*#4
X#14 Y[#25+#32*#5]
N40 #12=#12+1
END 2
#32=#32+1
END 1
G80
G00 Z#2
M99
""".trimIndent(),
        ),
        MacroTemplate(
            id = "thread_mill",
            name = "Резьбофрезерование (внутренняя)",
            description = "Внутренняя правая резьба: спираль снизу вверх против часовой, попутное фрезерование.",
            defaultArgs = "X50 Y35 I12 K1.75 E0 Z-14 D8 F200 B5",
            params = listOf(
                MacroParam("X, Y", "центр отверстия"),
                MacroParam("I", "номинальный диаметр резьбы"),
                MacroParam("D", "диаметр резьбофрезы"),
                MacroParam("K", "шаг резьбы"),
                MacroParam("E", "верхняя плоскость Z (по умолчанию 0)"),
                MacroParam("Z", "низ резьбы"),
                MacroParam("F", "подача"),
                MacroParam("B", "безопасная высота"),
            ),
            source = """O9107 (REZBOFREZEROVANIE VNUTRENNEJ REZBY)
(X Y CENTR, I DIAMETR REZBY, D DIAM FREZY, K SHAG REZBY)
(E VERH Z, Z NIZ REZBY, F PODACHA, B BEZOP Z)
(PRAVAYA REZBA, POPUTNOE FREZEROVANIE, SPIRAL SNIZU VVERH)
IF [#4 LE #7] THEN #3000=1 (DIAMETR REZBY MENSHE FREZY)
IF [#6 LE 0] THEN #3000=2 (NET SHAGA REZBY K)
IF [#9 LE 0] THEN #3000=3 (NET PODACHI F)
IF [#8 EQ #0] THEN #8=0
IF [#26 GE #8] THEN #3000=4 (Z DOLZHNO BYT NIZHE E)
IF [#2 EQ #0] THEN #2=#8+5
#27=[#4-#7]/2
#28=FUP[[#8-#26]/#6]
#29=0
G00 Z#2
G00 X#24 Y#25
G00 Z[#8+1]
G01 Z#26 F#9
G01 X[#24+#27] Y#25 F#9
WHILE [#29 LT #28] DO 1
#29=#29+1
G03 X[#24+#27] Y#25 Z[#26+#29*#6] I-#27 J0 F#9
END 1
G01 X#24 Y#25
G00 Z#2
M99
""".trimIndent(),
        ),
        MacroTemplate(
            id = "chamfer",
            name = "Фаска на отверстии (45°)",
            description = "Фаска 45° на кромке отверстия фасочной фрезой 90°: центральная траектория по окружности.",
            defaultArgs = "X50 Y35 I10 U1.5 D3 E0 F300 B5",
            params = listOf(
                MacroParam("X, Y", "центр отверстия"),
                MacroParam("I", "диаметр отверстия"),
                MacroParam("U", "катет фаски"),
                MacroParam("D", "диаметр торца фрезы (плоской части)"),
                MacroParam("E", "верхняя плоскость Z"),
                MacroParam("F", "подача"),
                MacroParam("B", "безопасная высота"),
            ),
            source = """O9108 (FASKA NA OTVERSTII 45 GRAD)
(X Y CENTR, I DIAMETR OTVERSTIYA, U KATET FASKI)
(D DIAMETR TORCA FREZY, E VERH Z, F PODACHA, B BEZOP Z)
(FREZA FASOCHNAYA 90 GRAD)
IF [#4 LE 0] THEN #3000=1 (NET DIAMETRA OTVERSTIYA I)
IF [#21 LE 0] THEN #3000=2 (NET KATETA FASKI U)
IF [#9 LE 0] THEN #3000=3 (NET PODACHI F)
IF [#7 LT 0] THEN #3000=4 (D MENSHE NULYA)
IF [#8 EQ #0] THEN #8=0
IF [#2 EQ #0] THEN #2=#8+5
#27=#4/2-#7/2-0.5
IF [#27 LT 0] THEN #3000=5 (FREZA BOLSHE OTVERSTIYA)
#28=#8-#21-0.5
G00 Z#2
G00 X#24 Y#25
G00 Z[#8+1]
G01 Z#28 F[#9/2]
G01 X[#24+#27] Y#25 F#9
G03 I-#27 J0
G01 X#24 Y#25
G00 Z#2
M99
""".trimIndent(),
        ),
    )

    fun byId(id: String): MacroTemplate? = all.firstOrNull { it.id == id }
}

/** Макрос для вызова из проекта: библиотечный или пользовательский. ref: lib_<id> или user_<id>. */
data class MacroEntry(
    val ref: String,
    val name: String,
    val program: Int,
    val source: String,
    val defaultArgs: String,
)
