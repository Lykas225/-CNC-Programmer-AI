package ru.cncai.programmer.domain

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class MacroException(val msg: String, val line: Int) : Exception(msg)

data class OutBlock(val line: Int, val text: String)

/** Сведения о кадре движения для симуляции: строка программы, инструмент, коррекция, шпиндель. */
data class MoveInfo(val line: Int, val tool: Int, val comp: Int, val d: Int, val spindle: Boolean)

data class MacroRun(
    val blocks: List<OutBlock>,
    val moves: List<Move>,
    val errors: List<String>,
    val warnings: List<String>,
    val locals: Map<Int, Double>,
    val globals: Map<Int, Double>,
    val steps: Int,
    val infos: List<MoveInfo> = emptyList(),
)

class MLine(val src: Int, val body: String, val comment: String, val label: Int?)

class MProgram(val number: Int) {
    val lines = ArrayList<MLine>()
    val labels = HashMap<Int, Int>()
    val whileEnd = HashMap<Int, Int>()
    val endWhile = HashMap<Int, Int>()
}

/** Соответствие букв аргументов G65 локальным переменным (спецификация аргументов I). */
val MACRO_ARG_MAP: Map<Char, Int> = mapOf(
    'A' to 1, 'B' to 2, 'C' to 3, 'I' to 4, 'J' to 5, 'K' to 6, 'D' to 7, 'E' to 8, 'F' to 9,
    'H' to 11, 'M' to 13, 'Q' to 17, 'R' to 18, 'S' to 19, 'T' to 20, 'U' to 21, 'V' to 22, 'W' to 23,
    'X' to 24, 'Y' to 25, 'Z' to 26,
)

private val MACRO_FUNCS = listOf(
    "ASIN", "ACOS", "ATAN", "SQRT", "ROUND", "SIN", "COS", "TAN", "ABS", "BIN", "BCD", "FIX", "FUP", "LN", "EXP",
)
private val CMP_OPS = listOf("EQ", "NE", "GT", "LT", "GE", "LE")
private const val AXIS_LETTERS = "XYZIJKRABCUVW"
private const val MAX_STEPS = 200000
private val DO_LINE = Regex("^DO\\d$")
private val END_LINE = Regex("^END\\d$")

object MacroParser {
    private val COMMENT = Regex("\\(([^)]*)\\)")
    private val WS = Regex("\\s+")
    private val PROG = Regex("^O(\\d+)")
    private val LABEL = Regex("^N(\\d+)(.*)$")
    private val DO_ONLY = Regex("^DO(\\d)$")
    private val END_RE = Regex("^END(\\d)$")

    /** Возвращает (текст без пробелов и комментариев в верхнем регистре, текст первого комментария). */
    fun normalize(raw: String): Pair<String, String> {
        val m = COMMENT.find(raw)
        val comment = m?.groupValues?.get(1)?.trim() ?: ""
        val s = WS.replace(COMMENT.replace(raw, ""), "").uppercase()
        return Pair(s, comment)
    }

    fun findClose(s: String, start: Int): Int {
        var depth = 0
        for (k in start until s.length) {
            if (s[k] == '[') depth += 1
            else if (s[k] == ']') {
                depth -= 1
                if (depth == 0) return k
            }
        }
        return -1
    }

    /** Номер первой программы O в тексте (0, если нет). */
    fun programNumber(text: String): Int {
        for (raw in text.split('\n')) {
            val s = normalize(raw).first
            if (s.isEmpty() || s == "%") continue
            val m = PROG.find(s)
            return m?.groupValues?.get(1)?.toIntOrNull() ?: 0
        }
        return 0
    }

    fun parse(text: String): LinkedHashMap<Int, MProgram> {
        val progs = LinkedHashMap<Int, MProgram>()
        var cur: MProgram? = null
        val rows = text.split('\n')
        for (k in rows.indices) {
            val n = k + 1
            val nc = normalize(rows[k])
            val s = nc.first
            if (s.isEmpty() || s == "%") continue
            val pm = PROG.find(s)
            if (pm != null) {
                val num = pm.groupValues[1].toInt()
                if (progs.containsKey(num)) throw MacroException("Программа O$num определена дважды", n)
                val np = MProgram(num)
                progs[num] = np
                cur = np
                continue
            }
            val c = cur ?: throw MacroException("Текст должен начинаться с номера программы (например O9101)", n)
            var label: Int? = null
            var body = s
            val lm = LABEL.find(s)
            if (lm != null) {
                label = lm.groupValues[1].toInt()
                body = lm.groupValues[2]
            }
            if (body.startsWith("/")) body = ""
            c.lines.add(MLine(n, body, nc.second, label))
        }
        for (p in progs.values) {
            val stack = ArrayList<Pair<Int, Int>>()
            for (idx in p.lines.indices) {
                val ln = p.lines[idx]
                val lab = ln.label
                if (lab != null) {
                    if (p.labels.containsKey(lab)) throw MacroException("Метка N$lab повторяется", ln.src)
                    p.labels[lab] = idx
                }
                val b = ln.body
                if (b.startsWith("WHILE[")) {
                    val c = findClose(b, 5)
                    if (c < 0) throw MacroException("Не закрыта скобка в WHILE", ln.src)
                    val m = Regex("^DO(\\d)$").find(b.substring(c + 1))
                        ?: throw MacroException("После WHILE[...] ожидается DO n", ln.src)
                    val dn = m.groupValues[1].toInt()
                    if (dn < 1 || dn > 3) throw MacroException("Номер DO должен быть от 1 до 3", ln.src)
                    stack.add(Pair(dn, idx))
                } else {
                    val dm = DO_ONLY.find(b)
                    if (dm != null) {
                        val dn = dm.groupValues[1].toInt()
                        if (dn < 1 || dn > 3) throw MacroException("Номер DO должен быть от 1 до 3", ln.src)
                        stack.add(Pair(dn, idx))
                    } else {
                        val em = END_RE.find(b)
                        if (em != null) {
                            val en = em.groupValues[1].toInt()
                            if (stack.isEmpty()) throw MacroException("END $en без WHILE/DO", ln.src)
                            val top = stack.removeAt(stack.size - 1)
                            if (top.first != en) throw MacroException("END $en не соответствует DO ${top.first}", ln.src)
                            p.whileEnd[top.second] = idx
                            p.endWhile[idx] = top.second
                        }
                    }
                }
                if (stack.size > 3) throw MacroException("Вложенность циклов больше 3", ln.src)
            }
            if (stack.isNotEmpty()) {
                val last = stack[stack.size - 1]
                throw MacroException("Нет END ${last.first} для цикла", p.lines[last.second].src)
            }
        }
        return progs
    }
}

/** Разбор выражений Macro B. Пустая переменная (vacant) представлена как null. */
class ExprParser(private val ip: MacroInterp, private val s: String, private val line: Int) {
    var i = 0

    private fun err(msg: String): Nothing = throw MacroException(msg, line)
    fun done(): Boolean = i >= s.length
    private fun starts(t: String): Boolean = s.startsWith(t, i)
    private fun n(v: Double?): Double = v ?: 0.0

    fun expectEnd() {
        if (!done()) err("Лишние символы: '${s.substring(i)}'")
    }

    fun parseCmp(): Double? {
        var left = parseAdd()
        while (true) {
            var op: String? = null
            for (t in CMP_OPS) {
                if (starts(t)) {
                    op = t
                    break
                }
            }
            if (op == null) return left
            i += 2
            val right = parseAdd()
            val res: Boolean
            if (op == "EQ" || op == "NE") {
                val l = left
                val eq = if (l == null || right == null) (l == null && right == null) else abs(l - right) < 1e-9
                res = if (op == "EQ") eq else !eq
            } else {
                val a = n(left)
                val b = n(right)
                res = when (op) {
                    "GT" -> a > b
                    "LT" -> a < b
                    "GE" -> a >= b - 1e-12
                    else -> a <= b + 1e-12
                }
            }
            left = if (res) 1.0 else 0.0
        }
    }

    fun parseAdd(): Double? {
        var left = parseMul()
        while (!done()) {
            if (starts("+")) {
                i += 1
                left = n(left) + n(parseMul())
            } else if (starts("-")) {
                i += 1
                left = n(left) - n(parseMul())
            } else if (starts("XOR")) {
                i += 3
                left = (n(left).toLong() xor n(parseMul()).toLong()).toDouble()
            } else if (starts("OR")) {
                i += 2
                left = (n(left).toLong() or n(parseMul()).toLong()).toDouble()
            } else break
        }
        return left
    }

    fun parseMul(): Double? {
        var left = parseUnary()
        while (!done()) {
            if (starts("*")) {
                i += 1
                left = n(left) * n(parseUnary())
            } else if (starts("/")) {
                i += 1
                val r = n(parseUnary())
                if (abs(r) < 1e-12) err("Деление на ноль")
                left = n(left) / r
            } else if (starts("AND")) {
                i += 3
                left = (n(left).toLong() and n(parseUnary()).toLong()).toDouble()
            } else if (starts("MOD")) {
                i += 3
                val r = n(parseUnary())
                if (abs(r) < 1e-12) err("MOD на ноль")
                left = n(left) % r
            } else break
        }
        return left
    }

    fun parseUnary(): Double? {
        if (starts("+")) {
            i += 1
            return n(parseUnary())
        }
        if (starts("-")) {
            i += 1
            return -n(parseUnary())
        }
        return parsePrimary()
    }

    private fun sub(from: Int, to: Int): Double? {
        val p = ExprParser(ip, s.substring(from, to), line)
        val v = p.parseCmp()
        p.expectEnd()
        return v
    }

    /** Вызывается после '#': возвращает номер переменной. */
    fun parseVarIndex(): Int {
        if (starts("[")) {
            val c = MacroParser.findClose(s, i)
            if (c < 0) err("Не закрыта скобка")
            val v = sub(i + 1, c)
            i = c + 1
            return Math.round(n(v)).toInt()
        }
        if (starts("#")) {
            i += 1
            val idx = parseVarIndex()
            return Math.round(n(ip.getVar(idx, line))).toInt()
        }
        var j = i
        while (j < s.length && s[j] in '0'..'9') j++
        if (j == i) err("После # ожидается номер переменной")
        val num = s.substring(i, j).toInt()
        i = j
        return num
    }

    private fun parsePrimary(): Double? {
        if (done()) err("Неожиданный конец выражения")
        if (starts("[")) {
            val c = MacroParser.findClose(s, i)
            if (c < 0) err("Не закрыта скобка")
            val v = sub(i + 1, c)
            i = c + 1
            return v
        }
        if (starts("#")) {
            i += 1
            val idx = parseVarIndex()
            return ip.getVar(idx, line)
        }
        var j = i
        var dot = false
        while (j < s.length) {
            val ch = s[j]
            if (ch in '0'..'9') j++
            else if (ch == '.' && !dot) {
                dot = true
                j++
            } else break
        }
        val numText = s.substring(i, j)
        if (numText.isNotEmpty() && numText != ".") {
            i = j
            return numText.toDouble()
        }
        for (f in MACRO_FUNCS) {
            if (starts(f)) {
                val k = i + f.length
                if (k < s.length && s[k] == '[') {
                    val c = MacroParser.findClose(s, k)
                    if (c < 0) err("Не закрыта скобка")
                    val a = n(sub(k + 1, c))
                    i = c + 1
                    if (f == "ATAN") {
                        var b = 1.0
                        if (starts("/[")) {
                            val c2 = MacroParser.findClose(s, i + 1)
                            if (c2 < 0) err("Не закрыта скобка")
                            b = n(sub(i + 2, c2))
                            i = c2 + 1
                        }
                        val d = Math.toDegrees(atan2(a, b))
                        return if (d < 0) d + 360.0 else d
                    }
                    return func(f, a)
                }
            }
        }
        err("Неожиданный символ '${s[i]}'")
    }

    private fun func(f: String, a: Double): Double = when (f) {
        "SIN" -> sin(Math.toRadians(a))
        "COS" -> cos(Math.toRadians(a))
        "TAN" -> tan(Math.toRadians(a))
        "ASIN" -> { if (abs(a) > 1) err("ASIN: аргумент вне [-1; 1]"); Math.toDegrees(asin(a)) }
        "ACOS" -> { if (abs(a) > 1) err("ACOS: аргумент вне [-1; 1]"); Math.toDegrees(acos(a)) }
        "SQRT" -> { if (a < 0) err("SQRT от отрицательного числа"); sqrt(a) }
        "ABS" -> abs(a)
        "BIN", "BCD" -> a
        "ROUND" -> floor(a + 0.5)
        "FIX" -> floor(a + 1e-9)
        "FUP" -> ceil(a - 1e-9)
        "LN" -> { if (a <= 0) err("LN от неположительного числа"); ln(a) }
        "EXP" -> exp(a)
        else -> err("Неизвестная функция $f")
    }
}

private class Frame(args: Map<Char, Double>?) {
    val loc: Array<Double?> = Array(34) { null }

    init {
        if (args != null) {
            for ((k, v) in args) {
                val idx = MACRO_ARG_MAP[k]
                if (idx != null) loc[idx] = v
            }
        }
    }
}

private class CallEntry(
    val prog: MProgram,
    val ret: Int,
    val kind: String,
    var rem: Int,
    val target: Int,
    val args: Map<Char, Double>?,
    val frame: Frame,
)

/** Построчное выполнение макропрограммы Fanuc Macro B для просмотра координат (без станка). */
class MacroInterp(private val progs: Map<Int, MProgram>, start: Triple<Double, Double, Double>) {
    private val moves = ArrayList<Move>()
    private val blocks = ArrayList<OutBlock>()
    private val errors = ArrayList<String>()
    private val warnings = ArrayList<String>()
    private val glob = HashMap<Int, Double?>()
    private var frame = Frame(null)
    private var topLocals: Array<Double?>? = null
    private var x = start.first
    private var y = start.second
    private var z = start.third
    private var absMode = true
    private var motion = 0
    private var feed = 0.0
    private var canned: Int? = null
    private var ret98 = true
    private var cR: Double? = null
    private var cZ: Double? = null
    private var cInitZ = 0.0
    private var quiet = false
    private var curComment = ""
    private var stepsDone = 0
    private val vacWarned = HashSet<Int>()
    private val infos = ArrayList<MoveInfo>()
    private var curT = 0
    private var pendingT = 0
    private var compSide = 0
    private var dNum = 0
    private var spindleOn = false
    private var curLine = 0

    private fun n(v: Double?): Double = v ?: 0.0

    fun getVar(num: Int, line: Int): Double? {
        val v: Double?
        if (num in 1..33) v = frame.loc[num]
        else if (num in 100..199 || num in 500..999) v = glob[num]
        else if (num == 5001) return x
        else if (num == 5002) return y
        else if (num == 5003) return z
        else if (num == 0) return null
        else throw MacroException("Переменная #$num недоступна", line)
        if (v == null && !vacWarned.contains(num) && !quiet) {
            vacWarned.add(num)
            warnings.add("Строка $line: переменная #$num не определена (считается 0)")
        }
        return v
    }

    private fun setVar(num: Int, v: Double?, line: Int) {
        if (num == 3000) {
            if (v != null && abs(v) > 1e-9) throw MacroException("ALARM ${v.roundToInt()}: $curComment", line)
            return
        }
        if (num in 1..33) frame.loc[num] = v
        else if (num in 100..199 || num in 500..999) glob[num] = v
        else throw MacroException("В переменную #$num нельзя записывать", line)
    }

    private fun ev(s: String, line: Int): Double? {
        val p = ExprParser(this, s, line)
        val v = p.parseCmp()
        p.expectEnd()
        return v
    }

    private fun assign(stmt: String, line: Int) {
        if (!stmt.startsWith("#")) throw MacroException("Ожидалось присваивание #n=...", line)
        val p = ExprParser(this, stmt, line)
        p.i = 1
        val idx = p.parseVarIndex()
        if (p.done() || stmt[p.i] != '=') throw MacroException("После #n ожидается '='", line)
        p.i += 1
        val v = p.parseCmp()
        p.expectEnd()
        setVar(idx, v, line)
    }

    private fun words(b: String, line: Int): List<Pair<Char, Double?>> {
        val p = ExprParser(this, b, line)
        val out = ArrayList<Pair<Char, Double?>>()
        while (!p.done()) {
            val ch = b[p.i]
            if (ch !in 'A'..'Z') throw MacroException("Неожиданный символ '$ch'", line)
            p.i += 1
            out.add(Pair(ch, p.parseUnary()))
        }
        return out
    }

    private fun fmtWord(l: Char, v: Double): String {
        if (AXIS_LETTERS.indexOf(l) >= 0) return "$l" + GcodeGenerator.fmtNum(v, 3)
        if (abs(v - Math.round(v).toDouble()) < 1e-9) {
            val num = Math.round(v).toInt()
            if ((l == 'G' || l == 'M') && num in 0..99) return "$l" + num.toString().padStart(2, '0')
            return "$l$num"
        }
        return "$l" + GcodeGenerator.fmtNum(v, 3).trimEnd('.')
    }

    private fun render(words: List<Pair<Char, Double?>>): String =
        words.filter { it.second != null }.joinToString(" ") { fmtWord(it.first, it.second!!) }

    private fun emitMove(t: MoveType, nx: Double, ny: Double, nz: Double, i: Double = 0.0, j: Double = 0.0) {
        val f = if (t == MoveType.RAPID) 0 else feed.roundToInt()
        moves.add(Move(t, nx, ny, nz, i, j, f))
        infos.add(MoveInfo(curLine, curT, compSide, dNum, spindleOn))
        x = nx
        y = ny
        z = nz
    }

    fun run(entry: Int, args: Map<Char, Double>): MacroRun {
        try {
            exec(entry, args)
        } catch (e: MacroException) {
            errors.add(if (e.line > 0) "Строка ${e.line}: ${e.msg}" else e.msg)
        }
        val loc = HashMap<Int, Double>()
        val tl = topLocals
        if (tl != null) {
            for (k in 1..33) {
                val v = tl[k]
                if (v != null) loc[k] = v
            }
        }
        val g = HashMap<Int, Double>()
        for ((k, v) in glob) if (v != null) g[k] = v
        return MacroRun(blocks, moves, errors, warnings, loc, g, stepsDone, infos)
    }

    private fun exec(entry: Int, args: Map<Char, Double>) {
        val first = progs[entry] ?: throw MacroException("Программа O$entry не найдена", 0)
        moves.add(Move(MoveType.RAPID, x, y, z))
        infos.add(MoveInfo(0, 0, 0, 0, false))
        frame = Frame(args)
        topLocals = frame.loc
        val stack = ArrayList<CallEntry>()
        var prog = first
        var idx = 0
        var steps = 0
        while (true) {
            steps += 1
            stepsDone = steps
            if (steps > MAX_STEPS) {
                throw MacroException(
                    "Превышен лимит шагов: возможен бесконечный цикл",
                    if (idx < prog.lines.size) prog.lines[idx].src else 0,
                )
            }
            if (idx >= prog.lines.size) {
                if (stack.isEmpty()) break
                warnings.add("O${prog.number}: нет M99 в конце программы")
                val top = stack.removeAt(stack.size - 1)
                if (top.kind == "G65") frame = top.frame
                prog = top.prog
                idx = top.ret
                continue
            }
            val ln = prog.lines[idx]
            val b = ln.body
            val line = ln.src
            curComment = ln.comment
            curLine = line
            if (b.isEmpty()) {
                idx += 1
                continue
            }
            if (b.startsWith("IF[")) {
                val c = MacroParser.findClose(b, 2)
                if (c < 0) throw MacroException("Не закрыта скобка в IF", line)
                val inner = b.substring(3, c)
                quiet = inner.contains("#0")
                val cond = ev(inner, line)
                quiet = false
                val rest = b.substring(c + 1)
                val isTrue = cond != null && abs(cond) > 1e-12
                if (rest.startsWith("GOTO")) {
                    if (isTrue) {
                        val t = Math.round(n(ev(rest.substring(4), line))).toInt()
                        val target = prog.labels[t] ?: throw MacroException("Метка N$t не найдена", line)
                        idx = target
                        continue
                    }
                } else if (rest.startsWith("THEN")) {
                    if (isTrue) assign(rest.substring(4), line)
                } else {
                    throw MacroException("После IF[...] ожидается GOTO или THEN", line)
                }
                idx += 1
                continue
            }
            if (b.startsWith("WHILE[")) {
                val c = MacroParser.findClose(b, 5)
                val cond = ev(b.substring(6, c), line)
                val endIdx = prog.whileEnd[idx] ?: throw MacroException("Нет END для цикла", line)
                idx = if (cond == null || abs(cond) < 1e-12) endIdx + 1 else idx + 1
                continue
            }
            if (DO_LINE.matches(b)) {
                idx += 1
                continue
            }
            if (END_LINE.matches(b)) {
                idx = prog.endWhile[idx] ?: throw MacroException("END без цикла", line)
                continue
            }
            if (b.startsWith("GOTO")) {
                val t = Math.round(n(ev(b.substring(4), line))).toInt()
                idx = prog.labels[t] ?: throw MacroException("Метка N$t не найдена", line)
                continue
            }
            if (b.startsWith("#")) {
                assign(b, line)
                idx += 1
                continue
            }
            val ws = words(b, line)
            val gs = ws.filter { it.first == 'G' && it.second != null }.map { Math.round(it.second!!).toInt() }
            val ms = ws.filter { it.first == 'M' && it.second != null }.map { Math.round(it.second!!).toInt() }
            val wd = HashMap<Char, Double?>()
            for (w in ws) wd[w.first] = w.second

            if (gs.contains(65)) {
                val pv = wd['P'] ?: throw MacroException("G65 без P", line)
                val target = Math.round(pv).toInt()
                val rep = wd['L']?.let { Math.round(it).toInt() } ?: 1
                val a = LinkedHashMap<Char, Double>()
                for (w in ws) {
                    val v = w.second
                    if (MACRO_ARG_MAP.containsKey(w.first) && v != null) a[w.first] = v
                }
                val tp = progs[target] ?: throw MacroException("Программа O$target не найдена", line)
                if (stack.size >= 4) throw MacroException("Вложенность вызовов G65 больше 4", line)
                stack.add(CallEntry(prog, idx + 1, "G65", rep, target, a, frame))
                frame = Frame(a)
                prog = tp
                idx = 0
                continue
            }
            if (ms.contains(98)) {
                val pv = wd['P'] ?: throw MacroException("M98 без P", line)
                val target = Math.round(pv).toInt()
                val rep = wd['L']?.let { Math.round(it).toInt() } ?: 1
                val tp = progs[target] ?: throw MacroException("Программа O$target не найдена", line)
                if (stack.size >= 8) throw MacroException("Вложенность подпрограмм больше 8", line)
                stack.add(CallEntry(prog, idx + 1, "M98", rep, target, null, frame))
                prog = tp
                idx = 0
                continue
            }
            if (ms.contains(99)) {
                if (stack.isEmpty()) break
                val top = stack[stack.size - 1]
                if (top.rem > 1) {
                    top.rem -= 1
                    if (top.kind == "G65") frame = Frame(top.args)
                    prog = progs[top.target]!!
                    idx = 0
                    continue
                }
                stack.removeAt(stack.size - 1)
                if (top.kind == "G65") frame = top.frame
                prog = top.prog
                idx = top.ret
                continue
            }
            val tw = wd['T']
            if (tw != null) pendingT = Math.round(tw).toInt()
            if (ms.contains(6)) curT = pendingT
            if (ms.contains(3) || ms.contains(4)) spindleOn = true
            if (ms.contains(5) || ms.contains(30) || ms.contains(2)) spindleOn = false
            if (ms.contains(30) || ms.contains(2)) {
                blocks.add(OutBlock(line, render(ws)))
                break
            }
            motionBlock(gs, wd, line)
            blocks.add(OutBlock(line, render(ws)))
            idx += 1
        }
    }

    private fun motionBlock(gi: List<Int>, wd: Map<Char, Double?>, line: Int) {
        val prevComp = compSide
        for (g in gi) {
            when (g) {
                0, 1, 2, 3 -> motion = g
                90 -> absMode = true
                91 -> absMode = false
                81, 83 -> canned = g
                80 -> {
                    canned = null
                    cZ = null
                }
                98 -> ret98 = true
                99 -> ret98 = false
                41, 42 -> {
                    compSide = g
                    val dw = wd['D']
                    if (dw != null) dNum = Math.round(dw).toInt()
                }
                40 -> compSide = 0
                else -> {}
            }
        }
        if (gi.contains(28)) {
            // возврат в референтную точку: для просмотра X0 Y0 = (0; 0), Z = 100
            val rx = if (wd['X'] != null) 0.0 else x
            val ry = if (wd['Y'] != null) 0.0 else y
            val rz = if (wd['Z'] != null) 100.0 else z
            if (rx != x || ry != y || rz != z) emitMove(MoveType.RAPID, rx, ry, rz)
            return
        }
        if (gi.contains(53) || gi.contains(92)) return
        val ff = wd['F']
        if (ff != null) feed = ff
        fun tgt(axis: Char, cur: Double): Double {
            val v = wd[axis] ?: return cur
            return if (absMode) v else cur + v
        }
        val hasXY = wd['X'] != null || wd['Y'] != null
        val hasAxis = hasXY || wd['Z'] != null
        if (canned != null) {
            if (gi.contains(81) || gi.contains(83)) {
                val rr = wd['R']
                if (rr != null) cR = rr
                val zz = wd['Z']
                if (zz != null) cZ = zz
                cInitZ = z
            }
            val cr = cR
            val cz = cZ
            if (hasXY && cz != null && cr != null) {
                val nx = tgt('X', x)
                val ny = tgt('Y', y)
                emitMove(MoveType.RAPID, nx, ny, z)
                emitMove(MoveType.RAPID, nx, ny, cr)
                emitMove(MoveType.LINEAR, nx, ny, cz)
                emitMove(MoveType.RAPID, nx, ny, if (ret98) cInitZ else cr)
            }
            return
        }
        if (!hasAxis) return
        val nx = tgt('X', x)
        val ny = tgt('Y', y)
        val nz = tgt('Z', z)
        when (motion) {
            0 -> emitMove(MoveType.RAPID, nx, ny, nz)
            1 -> {
                val lt = when {
                    gi.contains(41) -> MoveType.COMP_LEFT
                    gi.contains(42) -> MoveType.COMP_RIGHT
                    gi.contains(40) && prevComp != 0 -> MoveType.COMP_OFF
                    else -> MoveType.LINEAR
                }
                emitMove(lt, nx, ny, nz)
            }
            2, 3 -> {
                if (wd['R'] != null) throw MacroException("Дуга с R в просмотре не поддерживается: используйте I и J", line)
                val iv = wd['I']
                val jv = wd['J']
                if (iv == null && jv == null) throw MacroException("У дуги нет I и J", line)
                val i = iv ?: 0.0
                val j = jv ?: 0.0
                val cx = x + i
                val cy = y + j
                val r1 = hypot(i, j)
                val r2 = hypot(nx - cx, ny - cy)
                if (abs(r1 - r2) > 0.01) {
                    throw MacroException(
                        "Радиусы дуги не совпадают: начало ${GcodeGenerator.fmtNum(r1, 3)}, конец ${GcodeGenerator.fmtNum(r2, 3)}",
                        line,
                    )
                }
                emitMove(if (motion == 2) MoveType.ARC_CW else MoveType.ARC_CCW, nx, ny, nz, i, j)
            }
            else -> {}
        }
    }
}

object MacroRunner {
    fun run(source: String, args: Map<Char, Double>, start: Triple<Double, Double, Double>): MacroRun {
        val progs = try {
            MacroParser.parse(source)
        } catch (e: MacroException) {
            val msg = if (e.line > 0) "Строка ${e.line}: ${e.msg}" else e.msg
            return MacroRun(emptyList(), emptyList(), listOf(msg), emptyList(), emptyMap(), emptyMap(), 0)
        }
        if (progs.isEmpty()) {
            return MacroRun(emptyList(), emptyList(), listOf("В тексте нет программы O"), emptyList(), emptyMap(), emptyMap(), 0)
        }
        return MacroInterp(progs, start).run(progs.keys.first(), args)
    }
}

/** Разбор аргументов вызова вида «X50 Y35 I60 D10 F300». */
object MacroArgs {
    private val TOKEN = Regex("([A-Z])\\s*(-?\\d*\\.?\\d+)")

    fun parse(text: String): Pair<LinkedHashMap<Char, Double>, String?> {
        val out = LinkedHashMap<Char, Double>()
        val up = text.uppercase()
        for (m in TOKEN.findAll(up)) {
            val letter = m.groupValues[1][0]
            if (!MACRO_ARG_MAP.containsKey(letter)) {
                return Pair(out, "Буква $letter не может быть аргументом G65 (допустимы A–F, H, I–K, M, Q–Z)")
            }
            val v = m.groupValues[2].toDoubleOrNull() ?: return Pair(out, "Неверное число после $letter")
            out[letter] = v
        }
        val rest = TOKEN.replace(up, "").trim()
        if (rest.isNotEmpty()) {
            return Pair(out, "Не удалось разобрать аргументы: «$rest». Формат: X50 Y35 Z-5 (десятичная точка, пробелы)")
        }
        return Pair(out, null)
    }

    /** Убирает указанные буквы из строки аргументов. */
    fun strip(text: String, letters: Set<Char>): String {
        var s = text.uppercase()
        for (l in letters) s = Regex("$l\\s*-?\\d*\\.?\\d+").replace(s, "")
        return Regex("\\s+").replace(s, " ").trim()
    }
}

data class MacroIssue(val line: Int, val isError: Boolean, val message: String)

/** Статическая проверка текста макроса: структура, метки, вызовы, переменные. */
object MacroChecker {
    private val KEYWORDS = setOf("IF", "THEN", "GOTO", "WHILE", "DO", "END", "EQ", "NE", "GT", "LT", "GE", "LE", "AND", "OR", "XOR", "MOD")
    private val ALPHA = Regex("[A-Z]{2,}")
    private val VAR = Regex("#(\\d+)")
    private val ASSIGN = Regex("^(?:IF\\[.*\\]THEN)?#(\\d+)=")
    private val LOCAL_NON_ARG = setOf(10, 12, 14, 15, 16) + (27..33).toSet()

    fun check(text: String): List<MacroIssue> {
        val issues = ArrayList<MacroIssue>()
        val progs = try {
            MacroParser.parse(text)
        } catch (e: MacroException) {
            issues.add(MacroIssue(e.line, true, e.msg))
            return issues
        }
        if (progs.isEmpty()) {
            issues.add(MacroIssue(0, true, "В тексте нет программы O"))
            return issues
        }
        // все присваивания глобальных переменных по всему тексту
        val globalWrites = HashSet<Int>()
        for (p in progs.values) for (ln in p.lines) {
            val m = ASSIGN.find(ln.body)
            if (m != null) {
                val v = m.groupValues[1].toInt()
                if (v >= 100) globalWrites.add(v)
            }
        }
        for (p in progs.values) {
            val localWrites = HashSet<Int>()
            for (ln in p.lines) {
                val m = ASSIGN.find(ln.body)
                if (m != null) {
                    val v = m.groupValues[1].toInt()
                    if (v in 1..33) localWrites.add(v)
                }
            }
            var hasReturn = false
            for (idx in p.lines.indices) {
                val ln = p.lines[idx]
                val b = ln.body
                if (b.isEmpty()) continue
                if (b.count { it == '[' } != b.count { it == ']' }) {
                    issues.add(MacroIssue(ln.src, true, "Не совпадает число скобок [ и ]"))
                }
                if (b.contains("M99") || b.contains("M30") || b.contains("M02")) hasReturn = true
                for (gm in Regex("GOTO(\\d+)").findAll(b)) {
                    val t = gm.groupValues[1].toInt()
                    if (!p.labels.containsKey(t)) issues.add(MacroIssue(ln.src, true, "Метка N$t не найдена в O${p.number}"))
                }
                if (b.contains("G65") || b.contains("M98")) {
                    val pm = Regex("P(\\d+)").find(b)
                    if (pm == null) {
                        issues.add(MacroIssue(ln.src, true, "В вызове нет адреса P"))
                    } else {
                        val t = pm.groupValues[1].toInt()
                        if (!progs.containsKey(t)) {
                            issues.add(MacroIssue(ln.src, false, "Программа O$t не входит в этот текст: она должна быть в памяти станка"))
                        }
                    }
                }
                for (m in ALPHA.findAll(b)) {
                    val t = m.value
                    val ok = KEYWORDS.contains(t) || MACRO_FUNCS.contains(t) ||
                        (t.length > 1 && MACRO_FUNCS.contains(t.substring(1)))
                    if (!ok) issues.add(MacroIssue(ln.src, true, "Неизвестное слово или функция: $t"))
                }
                if (Regex("/0(?![0-9.])").containsMatchIn(b)) {
                    issues.add(MacroIssue(ln.src, true, "Деление на ноль"))
                }
                val am = ASSIGN.find(b)
                val written = am?.groupValues?.get(1)?.toIntOrNull()
                if (written != null) {
                    if (written == 3000) {
                        // сигнал тревоги
                    } else if (written !in 1..33 && written !in 100..199 && written !in 500..999) {
                        issues.add(MacroIssue(ln.src, true, "В переменную #$written нельзя записывать"))
                    }
                }
                for (vm in VAR.findAll(b)) {
                    val v = vm.groupValues[1].toInt()
                    if (vm.range.first == (am?.groups?.get(1)?.range?.first ?: -1) - 1) continue
                    if (v >= 100 && (v in 100..199 || v in 500..999) && !globalWrites.contains(v)) {
                        issues.add(MacroIssue(ln.src, false, "Переменная #$v читается, но нигде не присваивается"))
                    }
                    if (LOCAL_NON_ARG.contains(v) && !localWrites.contains(v)) {
                        issues.add(MacroIssue(ln.src, false, "Локальная переменная #$v читается до присваивания"))
                    }
                }
            }
            if (!hasReturn) {
                issues.add(MacroIssue(p.lines.lastOrNull()?.src ?: 0, false, "В O${p.number} нет M99 (возврата)"))
            }
            // циклы, условие которых не меняется внутри
            for ((wi, ei) in p.whileEnd) {
                val wb = p.lines[wi].body
                if (!wb.startsWith("WHILE[")) continue
                val cond = wb.substring(6, MacroParser.findClose(wb, 5))
                val condVars = VAR.findAll(cond).map { it.groupValues[1].toInt() }.toSet()
                if (condVars.isEmpty()) continue
                var changed = false
                for (k in wi + 1 until ei) {
                    val m = ASSIGN.find(p.lines[k].body)
                    if (m != null && condVars.contains(m.groupValues[1].toInt())) changed = true
                }
                if (!changed) {
                    issues.add(MacroIssue(p.lines[wi].src, false, "Переменные условия WHILE не меняются внутри цикла: возможен бесконечный цикл"))
                }
            }
        }
        return issues
    }
}
