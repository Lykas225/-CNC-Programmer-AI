package ru.cncai.programmer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.ProgramStore
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.data.SavedProgram
import ru.cncai.programmer.domain.CheckContext
import ru.cncai.programmer.domain.CheckReport
import ru.cncai.programmer.domain.CheckSeverity
import ru.cncai.programmer.domain.CheckTool
import ru.cncai.programmer.domain.ProgramChecker
import ru.cncai.programmer.domain.ProgramFormatter

private val LErr = Color(0xFFFF6B6B)
private val LWarn = Color(0xFFFFB84D)
private val LOk = Color(0xFF4ADE80)

private fun sourceLabel(s: String): String = when (s) {
    "generated" -> "из проекта"
    "imported" -> "импорт из файла"
    "created" -> "создана вручную"
    "version" -> "новая версия"
    else -> s
}

@Composable
fun ProgramLibraryScreen(onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val ctx = LocalContext.current
    val import = rememberImporter { name, text ->
        val sp = ProgramStore.add(name.substringBeforeLast('.'), text, "imported")
        if (sp == null) toast(ctx, "Файл слишком большой для библиотеки") else onOpen(sp.id)
    }
    ScreenFrame("Библиотека программ", onBack) {
        Button(onClick = { import() }, modifier = Modifier.fillMaxWidth()) { Text("Импорт файла (.NC .TAP .TXT .EIA)") }
        OutlinedButton(
            onClick = {
                val sp = ProgramStore.add("Новая программа", "%\nO0001 (NEW PROGRAM)\nN10 G21 G17 G40 G49 G80 G90\nN20 M30\n%", "created")
                if (sp != null) onOpen(sp.id)
            },
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
        ) { Text("Новая пустая программа") }
        Spacer(Modifier.height(10.dp))
        val groups = ProgramStore.list.groupBy { it.name }
        if (groups.isEmpty()) {
            Text(
                "Библиотека пуста. Сохраняйте программы кнопкой «Сохранить в библиотеку программ» на экране «Генерация G-кода» или импортируйте файлы.",
                color = Muted, fontSize = 13.sp,
            )
        }
        groups.entries.sortedByDescending { e -> e.value.maxOf { it.time } }.forEach { e ->
            val latest = e.value.maxByOrNull { it.version }!!
            PanelCard(onClick = { onOpen(latest.id) }) {
                Text(e.key, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(
                    "Версий: ${e.value.size} • последняя v${latest.version} • ${formatTime(latest.time)}",
                    color = Muted, fontSize = 13.sp,
                )
                Text("${sourceLabel(latest.source)} • строк: ${latest.text.count { it == '\n' } + 1}", color = Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

private val HL_COMMENT = Regex("\\([^)]*\\)")
private val HL_LABEL = Regex("^N\\d+", RegexOption.MULTILINE)
private val HL_G = Regex("G\\d+(\\.\\d+)?")
private val HL_M = Regex("M\\d+")
private val HL_VAR = Regex("#\\d+")
private val HL_TSFHD = Regex("[TSFHD]-?\\d+\\.?\\d*")
private val HL_KEY = Regex("\\b(IF|THEN|WHILE|DO|END|GOTO)\\b")

/** Подсветка G-кода и Macro B в редакторе. */
private class GcodeHighlighter : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(s)
        val comments = HL_COMMENT.findAll(s).map { it.range }.toList()
        fun inComment(i: Int): Boolean = comments.any { i >= it.first && i <= it.last }
        fun paint(re: Regex, color: Long) {
            for (m in re.findAll(s)) {
                if (!inComment(m.range.first)) b.addStyle(SpanStyle(color = Color(color)), m.range.first, m.range.last + 1)
            }
        }
        paint(HL_LABEL, 0xFF6B7794)
        paint(HL_G, 0xFF60A5FA)
        paint(HL_M, 0xFFFBBF24)
        paint(HL_TSFHD, 0xFF4ADE80)
        paint(HL_VAR, 0xFFC084FC)
        paint(HL_KEY, 0xFFC084FC)
        for (c in comments) b.addStyle(SpanStyle(color = Color(0xFF7F8CA8)), c.first, c.last + 1)
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}

@Composable
fun ProgramEditorScreen(id: Long, onBack: () -> Unit) {
    var curId by remember { mutableLongStateOf(id) }
    val prog = ProgramStore.list.firstOrNull { it.id == curId }
    if (prog == null) {
        StubScreen("Редактор программы", "Программа не найдена.", onBack)
        return
    }
    EditorBody(prog, { curId = it }, onBack)
}

@Composable
private fun EditorBody(prog: SavedProgram, onSwitch: (Long) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var tfv by remember(prog.id) { mutableStateOf(TextFieldValue(prog.text)) }
    var name by remember(prog.id) { mutableStateOf(prog.name) }
    var find by remember(prog.id) { mutableStateOf("") }
    var repl by remember(prog.id) { mutableStateOf("") }
    var info by remember(prog.id) { mutableStateOf<String?>(null) }
    var renumber by remember { mutableStateOf(true) }
    var step by remember { mutableStateOf("10") }
    var report by remember(prog.id) { mutableStateOf<CheckReport?>(null) }
    var checking by remember { mutableStateOf(false) }
    var confirmDelete by remember(prog.id) { mutableStateOf(false) }
    val dirty = tfv.text != prog.text || name.trim() != prog.name
    val highlighter = remember { GcodeHighlighter() }

    ScreenFrame("Редактор программы", onBack) {
        TextInput("Название программы", name) { name = it }
        Text(
            "Версия ${prog.version} • ${formatTime(prog.time)} • ${sourceLabel(prog.source)}" + if (dirty) " • есть несохранённые изменения" else "",
            color = if (dirty) LWarn else Muted, fontSize = 12.sp,
        )
        Spacer(Modifier.height(6.dp))

        val lineCount = tfv.text.count { it == '\n' } + 1
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(8.dp)) {
            Text(
                (1..lineCount).joinToString("\n"),
                modifier = Modifier.width(36.dp),
                textAlign = TextAlign.End,
                style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp, color = Color(0xFF6B7794)),
            )
            Spacer(Modifier.width(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                BasicTextField(
                    value = tfv,
                    onValueChange = { tfv = it; info = null },
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp, color = Color.White),
                    cursorBrush = SolidColor(Color.White),
                    visualTransformation = highlighter,
                    modifier = Modifier.widthIn(min = 260.dp),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = {
                val s = tfv.selection
                val ins = "(KOMMENTARIJ)"
                val t = tfv.text.substring(0, s.min) + ins + tfv.text.substring(s.max)
                tfv = TextFieldValue(t, TextRange(s.min + ins.length))
            }) { Text("Комментарий") }
            OutlinedButton(onClick = {
                val t = tfv.text
                val pos = tfv.selection.min.coerceIn(0, t.length)
                val ls = t.lastIndexOf('\n', pos - 1) + 1
                val le = t.indexOf('\n', pos).let { if (it < 0) t.length else it }
                val line = t.substring(ls, le)
                tfv = TextFieldValue(t.substring(0, le) + "\n" + line + t.substring(le), TextRange(le + 1 + line.length))
            }) { Text("Дублировать строку") }
            OutlinedButton(onClick = {
                val s = tfv.selection
                val part = if (s.collapsed) tfv.text else tfv.text.substring(s.min, s.max)
                clipboard.setText(AnnotatedString(part))
                info = if (s.collapsed) "Скопирована вся программа" else "Скопирован выделенный блок"
            }) { Text("Копировать") }
        }

        PanelCard {
            Text("Поиск и замена", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            TextInput("Найти", find) { find = it }
            TextInput("Заменить на", repl) { repl = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (find.isEmpty()) {
                        info = "Введите, что искать"
                    } else {
                        val t = tfv.text
                        var cnt = 0
                        var k = t.indexOf(find)
                        while (k >= 0) {
                            cnt++
                            k = t.indexOf(find, k + find.length)
                        }
                        val from = tfv.selection.max.coerceIn(0, t.length)
                        var nx = t.indexOf(find, from)
                        if (nx < 0) nx = t.indexOf(find)
                        if (nx >= 0) tfv = tfv.copy(selection = TextRange(nx, nx + find.length))
                        info = if (cnt == 0) "Не найдено" else "Найдено: $cnt (выделено следующее)"
                    }
                }) { Text("Найти") }
                OutlinedButton(onClick = {
                    if (find.isEmpty()) {
                        info = "Введите, что заменять"
                    } else {
                        val cnt = tfv.text.split(find).size - 1
                        tfv = TextFieldValue(tfv.text.replace(find, repl))
                        info = "Заменено: $cnt"
                    }
                }) { Text("Заменить все") }
            }
        }

        PanelCard {
            Text("Форматирование", fontWeight = FontWeight.SemiBold)
            Text("Заглавные буквы, пробелы между словами, перенумерация кадров N. Макростроки не меняются.", color = Muted, fontSize = 12.sp)
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text("Перенумеровать N", modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(checked = renumber, onCheckedChange = { renumber = it })
            }
            if (renumber) TextInput("Шаг нумерации", step) { step = it }
            OutlinedButton(onClick = {
                val st = step.trim().toIntOrNull()
                if (renumber && (st == null || st < 1 || st > 100)) {
                    info = "Шаг нумерации: целое число от 1 до 100"
                } else {
                    tfv = TextFieldValue(ProgramFormatter.format(tfv.text, renumber, st ?: 10))
                    info = "Программа отформатирована"
                }
            }) { Text("Форматировать") }
        }

        info?.let { Text(it, color = LOk, fontSize = 13.sp, modifier = Modifier.padding(vertical = 4.dp)) }

        OutlinedButton(
            onClick = {
                val project = ProjectStore.current.value
                val tools = Library.tools.toList()
                val rpm = Library.maxRpm.intValue
                val text = tfv.text
                scope.launch {
                    checking = true
                    report = withContext(Dispatchers.Default) {
                        ProgramChecker.check(
                            text,
                            CheckContext(
                                project.part,
                                tools.map { CheckTool(it.t, it.name, it.diameter / 2, it.d, it.h, it.type == "Сферическая фреза") },
                                rpm,
                            ),
                        )
                    }
                    checking = false
                }
            },
            enabled = !checking,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (checking) "Проверка…" else "Проверить программу") }
        report?.let { rep ->
            Spacer(Modifier.height(6.dp))
            if (rep.issues.isEmpty()) {
                Text("Ошибок не найдено (это не гарантия безопасности).", color = LOk, fontSize = 13.sp)
            } else {
                Text("Ошибок: ${rep.errors}, предупреждений: ${rep.warnings}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                rep.issues.take(10).forEach {
                    Text(
                        "• стр.${it.line}: ${it.message}",
                        color = if (it.severity == CheckSeverity.ERROR) LErr else LWarn, fontSize = 12.sp,
                    )
                }
                if (rep.issues.size > 10) Text("… и ещё ${rep.issues.size - 10}. Полный список: раздел «Проверка УП».", color = Muted, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                val nm = name.trim().ifBlank { prog.name }
                if (nm != prog.name) ProgramStore.renameAll(prog.name, nm)
                if (ProgramStore.update(prog.id, tfv.text)) toast(ctx, "Сохранено") else toast(ctx, "Программа слишком большая")
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Сохранить") }
        OutlinedButton(
            onClick = {
                val nm = name.trim().ifBlank { prog.name }
                val np = ProgramStore.add(nm, tfv.text, "version")
                if (np == null) toast(ctx, "Программа слишком большая") else {
                    toast(ctx, "Создана версия ${np.version}")
                    onSwitch(np.id)
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Сохранить как новую версию") }

        val versions = ProgramStore.list.filter { it.name == prog.name }.sortedByDescending { it.version }
        if (versions.size > 1) {
            Spacer(Modifier.height(10.dp))
            Text("Версии программы", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            versions.forEach { v ->
                PanelCard(onClick = { if (v.id != prog.id) onSwitch(v.id) }) {
                    Text(
                        "v${v.version} • ${formatTime(v.time)}" + if (v.id == prog.id) " • открыта" else "",
                        fontSize = 14.sp, fontWeight = if (v.id == prog.id) FontWeight.Bold else FontWeight.Normal,
                    )
                    Text("строк: ${v.text.count { it == '\n' } + 1} • ${sourceLabel(v.source)}", color = Muted, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        ExportSection(name.trim().ifBlank { prog.name }, tfv.text, "version", showLibrary = false)

        TextButton(
            onClick = {
                if (confirmDelete) {
                    ProgramStore.delete(prog.id)
                    val other = ProgramStore.list.filter { it.name == prog.name }.maxByOrNull { it.version }
                    if (other != null) onSwitch(other.id) else onBack()
                } else confirmDelete = true
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (confirmDelete) "Точно удалить эту версию?" else "Удалить эту версию", color = LErr) }
        Spacer(Modifier.height(16.dp))
    }
}
