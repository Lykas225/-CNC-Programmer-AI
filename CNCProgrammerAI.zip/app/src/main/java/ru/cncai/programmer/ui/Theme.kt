package ru.cncai.programmer.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B1220)
val Panel = Color(0xFF131C2E)
val Panel2 = Color(0xFF1B2640)
val Muted = Color(0xFFB6C2DA)
val Blue = Color(0xFF2563EB)
val Green = Color(0xFF16A34A)
val Purple = Color(0xFF6D4AE0)
val Orange = Color(0xFFF08A00)
val Teal = Color(0xFF0FA3A3)
val Slate = Color(0xFF5A6A95)

private val scheme = darkColorScheme(
    primary = Blue,
    onPrimary = Color.White,
    background = Bg,
    onBackground = Color.White,
    surface = Panel,
    onSurface = Color.White,
    surfaceVariant = Panel2,
    onSurfaceVariant = Muted,
)

@Composable
fun CncTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
