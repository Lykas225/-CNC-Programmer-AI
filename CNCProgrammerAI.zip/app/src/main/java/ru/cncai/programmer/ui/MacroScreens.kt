package ru.cncai.programmer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.MacroCatalog
import ru.cncai.programmer.data.MacroStore
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.data.UserMacro
import ru.cncai.programmer.domain.MacroArgs
import ru.cncai.programmer.domain.MacroChecker
import ru.cncai.programmer.domain.MacroIssue
import ru.cncai.programmer.domain.MacroLibrary
import ru.cncai.programmer.domain.MacroParser
import ru.cncai.programmer.domain.MacroRun
import ru.cncai.programmer.domain.MacroRunner
import ru.cncai.programmer.domain.Move
import ru.cncai.programmer.domain.OpInstance
import ru.cncai.programmer.domain.PathPreview
import ru.cncai.programmer.domain.ZeroZ
import kotlin.math.PI
import kotlin.math.roundToInt

private val MWarn = Color(0xFFFFB84D)
private val MErr = Color(0xFFFF6B6B)
private val MOk = Color(0xFF4ADE80)
private const val MAX_BLOCKS_SHOWN = 200

private val NEW_MACRO_TEMPLATE = """O9201 (MOJ MAKROS)
(X Y - POZICIYA, Z - GLUBINA, F - PODACHA)
IF [#9 LE 0] THEN #3000=1 (NET PODACHI F)
G00 X#24 Y#25
G01 Z#26 F#9
G00 Z5
M99"""

@Composable
fun MacroListScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    ScreenFrame("Макросы Macro B", onBack) {
        Button(onClick = { onOpen("user_0") }, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Новый макрос")
        }
        Text("Библиотека", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        MacroLibrary.all.forEach { t ->
            PanelCard(onClick = { onOpen("lib_${t.id}") }) {
                Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("O${t.program}", color = Muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("Мои макросы", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        if (MacroStore.list.isEmpty()) Text("Своих макросов пока нет.", color = Muted, fontSize = 13.sp)
        MacroStore.list.forEach { m ->
            PanelCard(onClick = { onOpen("user_${m.id}") }) {
                Text(m.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text("O${MacroParser.programNumber(m.source)}", color = Muted, fontSize = 13.sp)
            }
        }
        Text(
            "Программы O9000–O9999 на Fanuc защищены параметром 3202 (NE9): для загрузки файла с такими номерами запись нужно разрешить.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
        )
    }
}

@Composable
fun MovesCanvas(moves: List<Move>) {
    val lines = remember(moves) { PathPreview.flatten(moves) }
    Canvas(Modifier.fillMaxWidth().height(240.dp).clip(RoundedCornerShape(14.dp)).background(Panel)) {
        if (lines.isEmpty()) return@Canvas
        var minX = Double.MAX_VALUE
        var maxX = -Double.MAX_VALUE
        var minY = Double.MAX_VALUE
        var maxY = -Double.MAX_VALUE
        for (l in lines) {
            minX = minOf(minX, l.x1, l.x2)
            maxX = maxOf(maxX, l.x1, l.x2)
            minY = minOf(minY, l.y1, l.y2)
            maxY = maxOf(maxY, l.y1, l.y2)
        }
        val w = maxOf(maxX - minX, 1.0)
        val h = maxOf(maxY - minY, 1.0)
        val pad = 20.dp.toPx()
        val scale = minOf((size.width - 2 * pad) / w, (size.height - 2 * pad) / h)
        val ox = (size.width - w * scale) / 2.0
        val oy = (size.height - h * scale) / 2.0
        fun px(x: Double): Float = (ox + (x - minX) * scale).toFloat()
        fun py(y: Double): Float = (oy + (maxY - y) * scale).toFloat()
        for (l in lines) {
            drawLine(
                color = if (l.rapid) Color(0x66FFFFFF) else Color(0xFFFBBF24),
                start = Offset(px(l.x1), py(l.y1)),
                end = Offset(px(l.x2), py(l.y2)),
                strokeWidth = if (l.rapid) 1f else 2f,
            )
        }
        drawCircle(color = Color(0xFF22C55E), radius = 5f, center = Offset(px(lines[0].x1), py(lines[0].y1)))
    }
}

@Composable
private fun RunReport(run: MacroRun?, issues: List<MacroIssue>?, argError: String?) {
    argError?.let { Text("• $it", color = MErr, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)) }
    if (issues != null) {
        if (issues.isEmpty()) Text("Проверка: ошибок не найдено", color = MOk, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
        issues.forEach {
            Text(
                "• строка ${it.line}: ${it.message}",
                color = if (it.isError) MErr else MWarn, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp),
            )
        }
    }
    if (run != null) {
        run.errors.forEach { Text("• $it", color = MErr, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp)) }
        run.warnings.forEach { Text("• $it", color = MWarn, fontSize = 13.sp, modifier = Modifier.padding(bottom = 3.dp)) }
        if (run.errors.isEmpty()) {
            Spacer(Modifier.height(6.dp))
            Text("Выполнено шагов: ${run.steps}, кадров: ${run.blocks.size}", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            MovesCanvas(run.moves)
            Text(
                "Вид сверху: жёлтое — рабочие ходы, серое — быстрые, зелёная точка — начало.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp),
            )
            if (run.locals.isNotEmpty() || run.globals.isNotEmpty()) {
                PanelCard {
                    Text("Переменные после выполнения", fontWeight = FontWeight.SemiBold)
                    val all = run.locals.toSortedMap().map { "#${it.key} = ${fmt2(it.value)}" } +
                        run.globals.toSortedMap().map { "#${it.key} = ${fmt2(it.value)}" }
                    Text(all.joinToString("\n"), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
            PanelCard {
                Text("Вычисленные кадры", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    Text(
                        run.blocks.take(MAX_BLOCKS_SHOWN).joinToString("\n") { "стр.${it.line}: ${it.text}" },
                        fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                    )
                }
                if (run.blocks.size > MAX_BLOCKS_SHOWN) {
                    Text("Показаны первые $MAX_BLOCKS_SHOWN кадров.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

private fun fmt2(v: Double): String = v.fmt2()

@Composable
fun MacroEditorScreen(ref: String, onBack: () -> Unit) {
    val isLib = ref.startsWith("lib_")
    val tpl = if (isLib) MacroLibrary.byId(ref.removePrefix("lib_")) else null
    val userId = if (isLib) 0L else (ref.removePrefix("user_").toLongOrNull() ?: 0L)
    val existing = if (isLib) null else MacroStore.list.firstOrNull { it.id == userId }
    if (isLib && tpl == null) {
        StubScreen("Макрос", "Макрос не найден в библиотеке.", onBack)
        return
    }
    val startName = tpl?.name ?: existing?.name ?: "Мой макрос"
    val startSource = tpl?.source ?: existing?.source ?: NEW_MACRO_TEMPLATE
    val startArgs = tpl?.defaultArgs ?: existing?.args ?: "X0 Y0 Z-2 F200"

    var name by remember { mutableStateOf(startName) }
    var source by remember { mutableStateOf(startSource) }
    var args by remember { mutableStateOf(startArgs) }
    var issues by remember { mutableStateOf<List<MacroIssue>?>(null) }
    var run by remember { mutableStateOf<MacroRun?>(null) }
    var argError by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    ScreenFrame(if (isLib) "Макрос из библиотеки" else if (existing == null) "Новый макрос" else "Макрос", onBack) {
        if (tpl != null) {
            Text(tpl.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text("O${tpl.program}", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(tpl.description, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            PanelCard {
                Text("Аргументы вызова G65", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                tpl.params.forEach { Text("${it.letter} — ${it.label}", color = Muted, fontSize = 13.sp) }
            }
            Text("Исходный текст макроса", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            PanelCard {
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    Text(tpl.source, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        } else {
            TextInput("Название", name) { name = it }
            Text("Текст макроса (начинается с O и номера, заканчивается M99)", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = source,
                onValueChange = { source = it; issues = null; run = null },
                modifier = Modifier.fillMaxWidth(),
                minLines = 10,
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp),
            )
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { source += "\nIF [#1 EQ #0] THEN #3000=1 (MESSAGE)" }) { Text("IF THEN") }
                OutlinedButton(onClick = { source += "\n#30=0\nWHILE [#30 LT 5] DO 1\n#30=#30+1\nEND 1" }) { Text("WHILE") }
                OutlinedButton(onClick = { source += "\nG65 P9101 X0 Y0" }) { Text("G65") }
                OutlinedButton(onClick = { source += "\nM98 P1000 L2" }) { Text("M98") }
                OutlinedButton(onClick = { source += "\nM99" }) { Text("M99") }
            }
        }
        Spacer(Modifier.height(8.dp))
        TextInput("Аргументы вызова (например X50 Y35 Z-5 F300)", args) { args = it; run = null }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { issues = MacroChecker.check(source); argError = null },
                modifier = Modifier.weight(1f),
            ) { Text("Проверить") }
            Button(
                onClick = {
                    val parsed = MacroArgs.parse(args)
                    issues = MacroChecker.check(source)
                    if (parsed.second != null) {
                        argError = parsed.second
                        run = null
                    } else {
                        argError = null
                        run = MacroRunner.run(source, parsed.first, Triple(0.0, 0.0, 50.0))
                    }
                },
                modifier = Modifier.weight(1f),
            ) { Text("Выполнить") }
        }
        Spacer(Modifier.height(10.dp))
        RunReport(run, issues, argError)

        Spacer(Modifier.height(10.dp))
        if (tpl != null) {
            OutlinedButton(
                onClick = {
                    MacroStore.save(UserMacro(0L, "Копия: ${tpl.name}", tpl.source, args))
                    onBack()
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Скопировать в «Мои макросы»") }
            Text(
                "Копию можно менять и перенумеровать (например O8101), если O9000–O9999 защищены на станке.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp),
            )
        } else {
            Button(
                onClick = {
                    MacroStore.save(UserMacro(userId, name.trim().ifBlank { "Мой макрос" }, source, args))
                    onBack()
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Сохранить") }
            if (existing != null) {
                TextButton(
                    onClick = {
                        if (confirmDelete) {
                            MacroStore.delete(existing.id)
                            onBack()
                        } else confirmDelete = true
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (confirmDelete) "Точно удалить?" else "Удалить макрос", color = MErr) }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** Операция проекта «Макрос Fanuc Macro B (вызов G65)». */
@Composable
fun MacroOpEditor(opId: Long, onBack: () -> Unit) {
    val entries = MacroCatalog.entries()
    if (Library.tools.isEmpty()) {
        StubScreen("Макрос в проект", "Сначала добавьте инструмент в разделе «Материалы и инструменты».", onBack)
        return
    }
    MacroOpBody(opId, entries, onBack)
}

@Composable
private fun MacroOpBody(opId: Long, entries: List<ru.cncai.programmer.domain.MacroEntry>, onBack: () -> Unit) {
    val project = ProjectStore.current.value
    val part = project.part
    val existing = project.operations.firstOrNull { it.id == opId }
    val mat = Library.materials.firstOrNull { it.name == part.materialName } ?: Library.materials.firstOrNull()
    val toolStart = existing?.let { e -> Library.tools.indexOfFirst { it.id == e.toolId } }?.takeIf { it >= 0 }
        ?: Library.tools.indexOfFirst { it.type != "Сверло" && it.type != "Резьбофреза" }.coerceAtLeast(0)
    val macroStart = existing?.let { e -> entries.indexOfFirst { it.ref == e.macroRef } }?.takeIf { it >= 0 } ?: 0

    var mi by remember { mutableIntStateOf(macroStart) }
    var ti by remember { mutableIntStateOf(toolStart) }
    var vc by remember { mutableStateOf((existing?.vc ?: mat?.vc ?: 100.0).fmt2()) }
    var fz by remember { mutableStateOf((existing?.fz ?: mat?.fz ?: 0.05).fmt2()) }
    var safeZ by remember { mutableStateOf((existing?.safeZ ?: 5.0).fmt2()) }
    var args by remember {
        mutableStateOf(existing?.args ?: MacroArgs.strip(entries[macroStart].defaultArgs, setOf('D', 'F')))
    }
    var run by remember { mutableStateOf<MacroRun?>(null) }
    var issues by remember { mutableStateOf<List<MacroIssue>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    val mIdx = mi.coerceIn(0, entries.lastIndex)
    val tIdx = ti.coerceIn(0, Library.tools.lastIndex)
    val macro = entries[mIdx]
    val tool = Library.tools[tIdx]

    // Считает S, F, проверяет и выполняет макрос. Возвращает операцию, если ошибок нет.
    fun checkNow(): OpInstance? {
        val v = vc.num()
        val f = fz.num()
        val sz = safeZ.num()
        if (v == null || f == null || sz == null || v <= 0 || f <= 0) {
            error = "Заполните Vc, fz и высоту отвода положительными числами"
            run = null
            return null
        }
        val parsed = MacroArgs.parse(args)
        if (parsed.second != null) {
            error = parsed.second
            run = null
            return null
        }
        val a = parsed.first
        val maxRpm = Library.maxRpm.intValue
        val n = minOf(1000.0 * v / (PI * tool.diameter), maxRpm.toDouble())
        val feed = (n * f * tool.teeth).roundToInt().coerceAtLeast(1)
        if (!a.containsKey('D')) a['D'] = tool.diameter
        if (!a.containsKey('F')) a['F'] = feed.toDouble()
        val zTop = if (part.zeroZ == ZeroZ.TOP) 0.0 else part.thickness
        val iss = MacroChecker.check(macro.source)
        issues = iss
        val r = MacroRunner.run(macro.source, a, Triple(0.0, 0.0, zTop + sz))
        run = r
        if (iss.any { it.isError } || r.errors.isNotEmpty()) {
            error = "В макросе или аргументах есть ошибки (см. ниже)"
            return null
        }
        error = null
        return OpInstance(existing?.id ?: 0L, "macro", 0L, tool.id, v, f, 1.0, 1.0, 0.0, 0.0, 0.0, sz, macro.ref, args)
    }

    ScreenFrame("Макрос в проект", onBack) {
        Picker("Макрос", entries.map { "O${it.program} ${it.name}" }, mIdx) {
            mi = it
            args = MacroArgs.strip(entries[it].defaultArgs, setOf('D', 'F'))
            run = null
            issues = null
        }
        Picker("Инструмент", Library.tools.map { it.name }, tIdx) { ti = it; run = null }
        Text("Ø${tool.diameter.fmt()} мм, зубьев ${tool.teeth}, T${tool.t} H${tool.h} D${tool.d}", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        NumberField("Скорость резания Vc, м/мин", vc) { vc = it }
        NumberField("Подача на зуб fz, мм/зуб", fz) { fz = it }
        NumberField("Высота отвода над деталью, мм", safeZ) { safeZ = it }
        TextInput("Аргументы макроса (D и F подставятся по инструменту)", args) { args = it; run = null }
        Text(
            "Координаты X, Y, Z в аргументах задаются в системе нуля детали (${part.wcs}).",
            color = Muted, fontSize = 12.sp,
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = { checkNow() }, modifier = Modifier.fillMaxWidth()) { Text("Проверить и показать траекторию") }
        Spacer(Modifier.height(8.dp))
        error?.let { Text(it, color = MErr, modifier = Modifier.padding(bottom = 6.dp)) }
        RunReport(run, issues, null)
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                val op = checkNow()
                if (op != null) {
                    ProjectStore.saveOperation(op)
                    onBack()
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (existing == null) "Добавить в проект" else "Сохранить изменения") }
        if (existing != null) {
            TextButton(
                onClick = {
                    if (confirmDelete) {
                        ProjectStore.deleteOperation(existing.id)
                        onBack()
                    } else confirmDelete = true
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (confirmDelete) "Точно удалить?" else "Удалить операцию", color = MErr) }
        }
        Text(
            "В G-код попадёт вызов G65 и текст макроса после M30. Перед запуском на станке проверьте программу на холостом ходу.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp),
        )
        Spacer(Modifier.height(16.dp))
    }
}
