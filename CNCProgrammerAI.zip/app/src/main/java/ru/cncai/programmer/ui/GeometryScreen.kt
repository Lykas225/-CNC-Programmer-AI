package ru.cncai.programmer.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.domain.Feature
import ru.cncai.programmer.domain.FeatureType
import ru.cncai.programmer.domain.GeometryValidator
import ru.cncai.programmer.domain.Part
import ru.cncai.programmer.domain.PartShape
import ru.cncai.programmer.domain.Project
import ru.cncai.programmer.domain.ZeroXY
import ru.cncai.programmer.domain.ZeroZ

private val DangerRed = Color(0xFFFF6B6B)
private val WcsList = listOf("G54", "G55", "G56", "G57", "G58", "G59")

fun partSummary(p: Part): String = when (p.shape) {
    PartShape.RECT -> "Прямоугольная ${p.sizeX.fmt2()} × ${p.sizeY.fmt2()} × ${p.thickness.fmt2()} мм"
    PartShape.ROUND -> "Круглая Ø${p.sizeX.fmt2()} × ${p.thickness.fmt2()} мм"
}

private fun describeFeature(f: Feature): String = when (f.type) {
    FeatureType.HOLE, FeatureType.ROUND_POCKET ->
        "Ø${f.a.fmt2()} в (${f.x.fmt2()}; ${f.y.fmt2()}), глубина ${f.depth.fmt2()}"
    FeatureType.RECT_POCKET ->
        "${f.a.fmt2()} × ${f.b.fmt2()}, R${f.r.fmt2()}, центр (${f.x.fmt2()}; ${f.y.fmt2()}), глубина ${f.depth.fmt2()}"
    FeatureType.SLOT ->
        "ширина ${f.a.fmt2()}, от (${f.x.fmt2()}; ${f.y.fmt2()}) до (${f.x2.fmt2()}; ${f.y2.fmt2()}), глубина ${f.depth.fmt2()}"
}

@Composable
fun GeometryScreen(onBack: () -> Unit) {
    val project = ProjectStore.current.value
    val part = project.part
    var editPart by remember { mutableStateOf(false) }
    var editFeature by remember { mutableStateOf<Feature?>(null) }

    ScreenFrame("Геометрия детали", onBack) {
        PanelCard(onClick = { editPart = true }) {
            Text(project.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(partSummary(part), color = Muted, fontSize = 13.sp)
            Text("Ноль: ${part.zeroXY.title}, ${part.zeroZ.title} • ${part.wcs}", color = Muted, fontSize = 13.sp)
            Text("Материал: ${part.materialName}", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(4.dp))
            Text("Нажмите, чтобы изменить деталь", color = Muted, fontSize = 12.sp)
        }

        PartCanvas(project)
        Text(
            "Вид сверху. Белая точка — ноль детали, красная линия — ось X, зелёная — ось Y.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp),
        )

        Button(
            onClick = {
                editFeature = Feature(
                    0, FeatureType.HOLE, part.cx, part.cy, part.cx + 10.0, part.cy,
                    10.0, 20.0, 0.0, minOf(5.0, part.thickness),
                )
            },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Добавить элемент")
        }

        if (project.features.isEmpty()) {
            Text("Элементов пока нет: добавьте отверстия, карманы или пазы.", color = Muted, fontSize = 13.sp)
        }
        project.features.forEachIndexed { i, f ->
            PanelCard(onClick = { editFeature = f }) {
                Text("${i + 1}. ${f.type.title}", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(describeFeature(f), color = Muted, fontSize = 13.sp)
            }
        }
        Text(
            "Контуры произвольной формы и импорт DXF появятся позже.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 16.dp),
        )
    }

    if (editPart) PartDialog(project) { editPart = false }
    editFeature?.let { FeatureDialog(it, part) { editFeature = null } }
}

@Composable
private fun PartCanvas(project: Project) {
    val part = project.part
    val features = project.features
    Canvas(
        Modifier.fillMaxWidth().height(260.dp).clip(RoundedCornerShape(14.dp)).background(Panel)
    ) {
        val pad = 24.dp.toPx()
        val w = part.xMax - part.xMin
        val h = part.yMax - part.yMin
        val scale = minOf((size.width - 2 * pad) / w, (size.height - 2 * pad) / h)
        val ox = (size.width - w * scale) / 2.0
        val oy = (size.height - h * scale) / 2.0
        fun px(x: Double): Float = (ox + (x - part.xMin) * scale).toFloat()
        fun py(y: Double): Float = (oy + (part.yMax - y) * scale).toFloat()

        val fillPart = Color(0xFF3A4660)
        val edge = Color(0xFF9FB0D0)
        val dark = Color(0xFF1E3A8A)
        val light = Color(0xFF60A5FA)

        if (part.shape == PartShape.RECT) {
            val tl = Offset(px(part.xMin), py(part.yMax))
            val sz = Size((w * scale).toFloat(), (h * scale).toFloat())
            drawRect(color = fillPart, topLeft = tl, size = sz)
            drawRect(color = edge, topLeft = tl, size = sz, style = Stroke(width = 2f))
        } else {
            val c = Offset(px(part.cx), py(part.cy))
            val rad = (w * scale / 2).toFloat()
            drawCircle(color = fillPart, radius = rad, center = c)
            drawCircle(color = edge, radius = rad, center = c, style = Stroke(width = 2f))
        }

        features.forEach { f ->
            when (f.type) {
                FeatureType.HOLE, FeatureType.ROUND_POCKET -> {
                    val c = Offset(px(f.x), py(f.y))
                    val rad = (f.a / 2 * scale).toFloat()
                    drawCircle(color = dark, radius = rad, center = c)
                    drawCircle(color = light, radius = rad, center = c, style = Stroke(width = 2f))
                }
                FeatureType.RECT_POCKET -> {
                    val tl = Offset(px(f.x - f.a / 2), py(f.y + f.b / 2))
                    val sz = Size((f.a * scale).toFloat(), (f.b * scale).toFloat())
                    val cr = CornerRadius((f.r * scale).toFloat())
                    drawRoundRect(color = dark, topLeft = tl, size = sz, cornerRadius = cr)
                    drawRoundRect(color = light, topLeft = tl, size = sz, cornerRadius = cr, style = Stroke(width = 2f))
                }
                FeatureType.SLOT -> {
                    val s = Offset(px(f.x), py(f.y))
                    val e = Offset(px(f.x2), py(f.y2))
                    val sw = (f.a * scale).toFloat()
                    drawLine(color = light, start = s, end = e, strokeWidth = sw, cap = StrokeCap.Round)
                    drawLine(color = dark, start = s, end = e, strokeWidth = (sw - 4f).coerceAtLeast(1f), cap = StrokeCap.Round)
                }
            }
        }

        val z = Offset(px(0.0), py(0.0))
        val len = 28.dp.toPx()
        drawLine(color = Color(0xFFEF4444), start = z, end = Offset(z.x + len, z.y), strokeWidth = 4f)
        drawLine(color = Color(0xFF22C55E), start = z, end = Offset(z.x, z.y - len), strokeWidth = 4f)
        drawCircle(color = Color.White, radius = 6f, center = z)
    }
}

@Composable
private fun PartDialog(project: Project, onDismiss: () -> Unit) {
    val part = project.part
    var name by remember { mutableStateOf(project.name) }
    var shapeIdx by remember { mutableIntStateOf(part.shape.ordinal) }
    var sx by remember { mutableStateOf(part.sizeX.fmt2()) }
    var sy by remember { mutableStateOf(part.sizeY.fmt2()) }
    var th by remember { mutableStateOf(part.thickness.fmt2()) }
    var zxy by remember { mutableIntStateOf(part.zeroXY.ordinal) }
    var zz by remember { mutableIntStateOf(part.zeroZ.ordinal) }
    var wcs by remember { mutableIntStateOf(WcsList.indexOf(part.wcs).coerceAtLeast(0)) }
    val matNames = Library.materials.map { it.name }
    var mat by remember { mutableIntStateOf(matNames.indexOf(part.materialName).coerceAtLeast(0)) }
    var error by remember { mutableStateOf<String?>(null) }
    val shape = PartShape.entries[shapeIdx]

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Деталь") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TextInput("Название проекта", name) { name = it }
                Picker("Форма детали", PartShape.entries.map { it.title }, shapeIdx) { shapeIdx = it }
                NumberField(if (shape == PartShape.ROUND) "Диаметр, мм" else "Размер по X, мм", sx) { sx = it }
                if (shape == PartShape.RECT) NumberField("Размер по Y, мм", sy) { sy = it }
                NumberField("Толщина (высота по Z), мм", th) { th = it }
                Picker("Ноль детали по X/Y", ZeroXY.entries.map { it.title }, zxy) { zxy = it }
                Picker("Ноль детали по Z", ZeroZ.entries.map { it.title }, zz) { zz = it }
                Picker("Рабочая система координат", WcsList, wcs) { wcs = it }
                if (matNames.isNotEmpty()) {
                    Picker("Материал заготовки", matNames, mat.coerceIn(0, matNames.lastIndex)) { mat = it }
                }
                error?.let { Text(it, color = DangerRed) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val sxv = sx.num()
                val syv = if (shape == PartShape.RECT) sy.num() else sxv
                val thv = th.num()
                val err = when {
                    name.isBlank() -> "Введите название проекта"
                    sxv == null || sxv <= 0 -> "Размер по X должен быть больше 0"
                    syv == null || syv <= 0 -> "Размер по Y должен быть больше 0"
                    thv == null || thv <= 0 -> "Толщина должна быть больше 0"
                    else -> null
                }
                if (err != null) {
                    error = err
                } else {
                    val newPart = Part(
                        shape, sxv!!, syv!!, thv!!, ZeroXY.entries[zxy], ZeroZ.entries[zz], WcsList[wcs],
                        matNames.getOrElse(mat) { part.materialName },
                    )
                    val bad = project.features.withIndex().firstNotNullOfOrNull { (i, f) ->
                        GeometryValidator.validate(newPart, f)?.let { "Элемент ${i + 1}: $it" }
                    }
                    if (bad != null) {
                        error = bad
                    } else {
                        ProjectStore.updatePart(name.trim(), newPart)
                        onDismiss()
                    }
                }
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun FeatureDialog(initial: Feature, part: Part, onDismiss: () -> Unit) {
    var typeIdx by remember { mutableIntStateOf(FeatureType.entries.indexOf(initial.type)) }
    var x by remember { mutableStateOf(initial.x.fmt2()) }
    var y by remember { mutableStateOf(initial.y.fmt2()) }
    var x2 by remember { mutableStateOf(initial.x2.fmt2()) }
    var y2 by remember { mutableStateOf(initial.y2.fmt2()) }
    var a by remember { mutableStateOf(initial.a.fmt2()) }
    var b by remember { mutableStateOf(initial.b.fmt2()) }
    var r by remember { mutableStateOf(initial.r.fmt2()) }
    var depth by remember { mutableStateOf(initial.depth.fmt2()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val isNew = initial.id == 0L
    val type = FeatureType.entries[typeIdx]

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Новый элемент" else "Элемент") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Picker("Тип элемента", FeatureType.entries.map { it.title }, typeIdx) { typeIdx = it }
                when (type) {
                    FeatureType.HOLE, FeatureType.ROUND_POCKET -> {
                        NumberField("X центра, мм", x, signed = true) { x = it }
                        NumberField("Y центра, мм", y, signed = true) { y = it }
                        NumberField("Диаметр, мм", a) { a = it }
                    }
                    FeatureType.RECT_POCKET -> {
                        NumberField("X центра, мм", x, signed = true) { x = it }
                        NumberField("Y центра, мм", y, signed = true) { y = it }
                        NumberField("Размер по X, мм", a) { a = it }
                        NumberField("Размер по Y, мм", b) { b = it }
                        NumberField("Радиус угла, мм", r) { r = it }
                    }
                    FeatureType.SLOT -> {
                        NumberField("X начала, мм", x, signed = true) { x = it }
                        NumberField("Y начала, мм", y, signed = true) { y = it }
                        NumberField("X конца, мм", x2, signed = true) { x2 = it }
                        NumberField("Y конца, мм", y2, signed = true) { y2 = it }
                        NumberField("Ширина паза, мм", a) { a = it }
                    }
                }
                NumberField("Глубина от верха детали, мм", depth) { depth = it }
                error?.let { Text(it, color = DangerRed) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val xv = x.num()
                val yv = y.num()
                val x2v = x2.num()
                val y2v = y2.num()
                val av = a.num()
                val bv = b.num()
                val rv = r.num()
                val dv = depth.num()
                if (xv == null || yv == null || x2v == null || y2v == null ||
                    av == null || bv == null || rv == null || dv == null
                ) {
                    error = "Заполните все поля числами"
                } else {
                    val f = Feature(initial.id, type, xv, yv, x2v, y2v, av, bv, rv, dv)
                    val err = GeometryValidator.validate(part, f)
                    if (err != null) {
                        error = err
                    } else {
                        ProjectStore.saveFeature(f)
                        onDismiss()
                    }
                }
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                if (!isNew) {
                    TextButton(onClick = {
                        if (confirmDelete) {
                            ProjectStore.deleteFeature(initial.id)
                            onDismiss()
                        } else confirmDelete = true
                    }) { Text(if (confirmDelete) "Точно удалить?" else "Удалить", color = DangerRed) }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
            }
        },
    )
}
