package ru.cncai.programmer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.MacroCatalog
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.data.Tool
import ru.cncai.programmer.domain.FeatureType
import ru.cncai.programmer.domain.OpInstance
import ru.cncai.programmer.domain.OperationPlanner
import ru.cncai.programmer.domain.Operations
import ru.cncai.programmer.domain.Part
import ru.cncai.programmer.domain.PathPreview
import ru.cncai.programmer.domain.PlanOutcome
import ru.cncai.programmer.domain.ToolSpec

private val Warn = Color(0xFFFFB84D)
private val Err = Color(0xFFFF6B6B)

private fun Tool.toSpec() = ToolSpec(name, type, diameter, teeth, cuttingLength)

private fun featureTypeFor(kind: String): FeatureType? = when (kind) {
    "pocket_rect" -> FeatureType.RECT_POCKET
    "pocket_round" -> FeatureType.ROUND_POCKET
    "slot" -> FeatureType.SLOT
    "drill" -> FeatureType.HOLE
    else -> null
}

private fun defAp(kind: String, t: Tool): Double =
    if (kind == "drill") t.diameter else minOf(t.cuttingLength, t.diameter * 0.5)

private fun defAe(kind: String, t: Tool): Double =
    if (kind == "facing") t.diameter * 0.75 else t.diameter * 0.4

private fun defAllow(kind: String, t: Tool): Double = when (kind) {
    "drill" -> t.diameter * 0.3
    "facing" -> 0.0
    else -> 0.3
}

private fun defDepth(kind: String, part: Part): Double = when (kind) {
    "contour_outer" -> part.thickness
    "facing" -> minOf(1.0, part.thickness)
    else -> 0.0
}

@Composable
fun OperationsScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    val project = ProjectStore.current.value
    var pick by remember { mutableStateOf(false) }

    ScreenFrame("Операции обработки", onBack) {
        Button(onClick = { pick = true }, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Добавить операцию")
        }
        if (project.operations.isEmpty()) {
            Text("В проекте пока нет операций.", color = Muted, fontSize = 13.sp)
        }
        project.operations.forEachIndexed { i, op ->
            val tool = Library.tools.firstOrNull { it.id == op.toolId }
            if (op.kind == "macro") {
                val entry = MacroCatalog.byRef(op.macroRef)
                PanelCard(onClick = { onOpen("opedit/macro/${op.id}") }) {
                    Text("${i + 1}. Макрос: ${entry?.name ?: "не найден"}", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(tool?.name ?: "Инструмент удалён из библиотеки", color = Muted, fontSize = 13.sp)
                    Text("G65 P${entry?.program ?: 0} ${op.args}", fontSize = 13.sp)
                }
                return@forEachIndexed
            }
            val outcome: PlanOutcome? = tool?.let {
                OperationPlanner.plan(project, op, it.toSpec(), Library.maxRpm.intValue)
            }
            PanelCard(onClick = { onOpen("opedit/${op.kind}/${op.id}") }) {
                Text("${i + 1}. ${Operations.byId(op.kind)?.title ?: op.kind}", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(tool?.name ?: "Инструмент удалён из библиотеки", color = Muted, fontSize = 13.sp)
                val res = outcome?.result
                if (res != null) {
                    Text("≈ ${res.timeMin.fmtTime()} • S${res.rpm} F${res.feed} • кадров: ${res.moves.size}", fontSize = 13.sp)
                } else {
                    Text(outcome?.error ?: "Выберите инструмент", color = Err, fontSize = 13.sp)
                }
            }
        }
        Text(
            "Резьбофрезерование, фаски, цекование, уступы и внутренний контур добавим позже.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 16.dp),
        )
    }

    if (pick) {
        AlertDialog(
            onDismissRequest = { pick = false },
            title = { Text("Новая операция") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Operations.all.forEach { info ->
                        val ok = info.id in OperationPlanner.supported || info.id == "macro"
                        TextButton(
                            onClick = { pick = false; onOpen("opedit/${info.id}/0") },
                            enabled = ok,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (ok) info.title else "${info.title} (позже)") }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pick = false }) { Text("Отмена") } },
        )
    }
}

@Composable
fun OperationEditorScreen(kind: String, opId: Long, onBack: () -> Unit) {
    val title = Operations.byId(kind)?.title ?: "Операция"
    if (kind == "macro") {
        MacroOpEditor(opId, onBack)
        return
    }
    if (kind !in OperationPlanner.supported) {
        StubScreen(title, "Эта операция будет добавлена позже.", onBack)
        return
    }
    if (Library.tools.isEmpty()) {
        StubScreen(title, "Сначала добавьте инструмент в разделе «Материалы и инструменты».", onBack)
        return
    }
    val project = ProjectStore.current.value
    val ft = featureTypeFor(kind)
    if (ft != null && project.features.none { it.type == ft }) {
        StubScreen(title, "В детали нет подходящих элементов (${ft.title.lowercase()}). Добавьте их в разделе «Геометрия детали».", onBack)
        return
    }
    EditorContent(kind, opId, title, onBack)
}

@Composable
private fun EditorContent(kind: String, opId: Long, title: String, onBack: () -> Unit) {
    val project = ProjectStore.current.value
    val part = project.part
    val existing = project.operations.firstOrNull { it.id == opId }
    val isDrill = kind == "drill"
    val ft = featureTypeFor(kind)

    val indexed = project.features.withIndex().filter { it.value.type == ft }
    val featIds: List<Long> = (if (isDrill) listOf(0L) else emptyList()) + indexed.map { it.value.id }
    val featLabels: List<String> =
        (if (isDrill) listOf("Все отверстия по диаметру сверла") else emptyList()) +
            indexed.map { "Элемент ${it.index + 1}: ${describeFeature(it.value)}" }

    val suitable: (Tool) -> Boolean = { t ->
        if (isDrill) t.type == "Сверло" else t.type != "Сверло" && t.type != "Резьбофреза"
    }
    val savedIdx = existing?.let { e -> Library.tools.indexOfFirst { it.id == e.toolId } } ?: -1
    val defTool = if (savedIdx >= 0) savedIdx else Library.tools.indexOfFirst(suitable).coerceAtLeast(0)
    val tool0 = Library.tools[defTool]
    val mat = Library.materials.firstOrNull { it.name == part.materialName } ?: Library.materials.firstOrNull()

    var ti by remember { mutableIntStateOf(defTool) }
    var fi by remember {
        mutableIntStateOf(if (existing != null) featIds.indexOf(existing.featureId).coerceAtLeast(0) else 0)
    }
    var vc by remember { mutableStateOf((existing?.vc ?: mat?.vc ?: 100.0).fmt2()) }
    var fz by remember { mutableStateOf((existing?.fz ?: mat?.fz ?: 0.05).fmt2()) }
    var ap by remember { mutableStateOf((existing?.ap ?: defAp(kind, tool0)).fmt2()) }
    var ae by remember { mutableStateOf((existing?.ae ?: defAe(kind, tool0)).fmt2()) }
    var allow by remember { mutableStateOf((existing?.allowance ?: defAllow(kind, tool0)).fmt2()) }
    var depth by remember { mutableStateOf((existing?.depth ?: defDepth(kind, part)).fmt2()) }
    var stock by remember { mutableStateOf((existing?.stock ?: 3.0).fmt2()) }
    var safeZ by remember { mutableStateOf((existing?.safeZ ?: 5.0).fmt2()) }
    var outcome by remember { mutableStateOf<PlanOutcome?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    val tIdx = ti.coerceIn(0, Library.tools.lastIndex)
    val tool = Library.tools[tIdx]
    val showAe = !isDrill
    val showAllow = true
    val showDepth = kind == "contour_outer" || kind == "facing"
    val showStock = kind == "contour_outer"
    val allowLabel = if (isDrill) "Перебег сверла для сквозных отверстий, мм" else "Припуск под чистовую (на стенку), мм"
    val apLabel = if (isDrill) "Шаг сверления (прерывистая подача), мм" else "Глубина резания за проход ap, мм"
    val showAllowField = showAllow && kind != "facing"

    // Строит операцию, считает траекторию. Возвращает операцию, если расчёт успешен.
    fun planNow(): OpInstance? {
        val v = vc.num()
        val f = fz.num()
        val a = ap.num()
        val e = ae.num()
        val al = allow.num()
        val d = depth.num()
        val s = stock.num()
        val sz = safeZ.num()
        if (v == null || f == null || a == null || e == null || al == null || d == null || s == null || sz == null) {
            error = "Заполните все поля числами"
            outcome = null
            return null
        }
        val op = OpInstance(
            existing?.id ?: 0L, kind, featIds.getOrElse(fi) { 0L }, tool.id,
            v, f, a, e, al, d, s, sz,
        )
        val r = OperationPlanner.plan(project, op, tool.toSpec(), Library.maxRpm.intValue)
        return if (r.error != null) {
            error = r.error
            outcome = null
            null
        } else {
            error = null
            outcome = r
            op
        }
    }

    ScreenFrame(title, onBack) {
        if (featLabels.isNotEmpty()) {
            Picker(if (isDrill) "Отверстия" else "Элемент", featLabels, fi.coerceIn(0, featLabels.lastIndex)) {
                fi = it
                outcome = null
            }
        } else {
            Text("Обрабатывается наружный контур/верх всей детали: ${partSummary(part)}", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
        }
        Picker("Инструмент", Library.tools.map { it.name }, tIdx) {
            ti = it
            val t = Library.tools[it]
            ap = defAp(kind, t).fmt2()
            ae = defAe(kind, t).fmt2()
            allow = defAllow(kind, t).fmt2()
            outcome = null
        }
        Text("Ø${tool.diameter.fmt()} мм, зубьев ${tool.teeth}, рабочая длина ${tool.cuttingLength.fmt()} мм", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        NumberField("Скорость резания Vc, м/мин", vc) { vc = it }
        NumberField("Подача на зуб fz, мм/зуб", fz) { fz = it }
        NumberField(apLabel, ap) { ap = it }
        if (showAe) NumberField(if (kind == "facing") "Шаг между проходами ae, мм" else "Ширина резания ae, мм", ae) { ae = it }
        if (showAllowField) NumberField(allowLabel, allow) { allow = it }
        if (showDepth) NumberField(if (kind == "facing") "Глубина торцовки, мм" else "Глубина контура, мм", depth) { depth = it }
        if (showStock) NumberField("Слой заготовки по периметру, мм", stock) { stock = it }
        NumberField("Высота отвода над деталью, мм", safeZ) { safeZ = it }
        if (isDrill) {
            Text("Режимы взяты из таблицы фрез: для сверла проверьте Vc и fz по каталогу.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
        }

        Button(onClick = { planNow() }, modifier = Modifier.fillMaxWidth()) { Text("Рассчитать траекторию") }
        Spacer(Modifier.height(10.dp))
        error?.let { Text(it, color = Err, modifier = Modifier.padding(bottom = 8.dp)) }

        val res = outcome?.result
        if (res != null) {
            val lines = remember(res) { PathPreview.flatten(res.moves) }
            PartCanvas(project, lines)
            Text(
                "Жёлтое — рабочие ходы центра фрезы, серое — быстрые перемещения.",
                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp),
            )
            PanelCard {
                Text("Результат", fontWeight = FontWeight.Bold, color = Color(0xFF4ADE80))
                Spacer(Modifier.height(6.dp))
                Text("S${res.rpm} об/мин • F${res.feed} мм/мин • врезание F${res.plungeFeed}")
                Text("Резание: ${res.cutLength.fmt2()} мм • холостые: ${res.rapidLength.fmt2()} мм")
                Text("Время ≈ ${res.timeMin.fmtTime()}", fontWeight = FontWeight.SemiBold)
                Text("Кадров траектории: ${res.moves.size}", color = Muted, fontSize = 13.sp)
                res.warnings.forEach { Text("• $it", color = Warn, fontSize = 13.sp) }
            }
            Text(
                "Время без смены инструмента, холостые ходы оценены при 10 м/мин. Это траектория центра фрезы: вывод в G-код с коррекцией G41/G42 будет на этапе 6.",
                color = Muted, fontSize = 12.sp,
            )
        }

        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                val op = planNow()
                if (op != null) {
                    ProjectStore.saveOperation(op)
                    onBack()
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (existing == null) "Добавить в проект" else "Сохранить изменения") }
        if (existing != null) {
            TextButton(
                onClick = {
                    if (confirmDelete) {
                        ProjectStore.deleteOperation(existing.id)
                        onBack()
                    } else confirmDelete = true
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text(if (confirmDelete) "Точно удалить?" else "Удалить операцию", color = Err) }
        }
        Spacer(Modifier.height(16.dp))
    }
}
