package ru.cncai.programmer.domain

import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.roundToInt

data class CuttingInput(
    val vc: Double,             // скорость резания, м/мин
    val diameter: Double,       // диаметр фрезы, мм
    val teeth: Int,
    val fz: Double,             // подача на зуб, мм/зуб
    val maxRpm: Int,            // предел оборотов шпинделя станка
    val cuttingLength: Double,  // рабочая длина фрезы, мм
    val ap: Double,             // глубина резания за проход, мм
    val ae: Double,             // ширина резания за проход, мм
    val totalDepth: Double,     // полная глубина обработки, мм
    val totalWidth: Double,     // полная ширина снимаемого слоя, мм
    val length: Double,         // длина одного прохода, мм
    val allowance: Double,      // припуск под чистовую, мм
)

data class CuttingPlan(
    val rpm: Int,
    val rpmIdeal: Int,
    val rpmLimited: Boolean,
    val vcActual: Double,
    val feed: Int,
    val fz: Double,
    val axialPasses: Int,
    val radialPasses: Int,
    val apActual: Double,
    val aeActual: Double,
    val removalRate: Double,    // см3/мин
    val roughTimeMin: Double,
    val hasFinish: Boolean,
    val finishFeed: Int,
    val finishTimeMin: Double,
    val totalTimeMin: Double,
)

object CuttingCalculator {
    /** Чистовая подача относительно черновой. */
    const val FINISH_FEED_FACTOR = 0.7

    fun validate(i: CuttingInput): String? = when {
        i.vc <= 0 -> "Скорость резания Vc должна быть больше 0"
        i.fz <= 0 -> "Подача на зуб fz должна быть больше 0"
        i.maxRpm <= 0 -> "Предел оборотов станка должен быть больше 0"
        i.ap <= 0 -> "Глубина резания ap должна быть больше 0"
        i.ap > i.cuttingLength -> "ap больше рабочей длины фрезы"
        i.ae <= 0 -> "Ширина резания ae должна быть больше 0"
        i.ae > i.diameter -> "ae больше диаметра фрезы"
        i.allowance < 0 -> "Припуск не может быть отрицательным"
        i.totalDepth <= i.allowance -> "Глубина обработки должна быть больше припуска"
        i.totalWidth <= i.allowance -> "Ширина обработки должна быть больше припуска"
        i.length <= 0 -> "Длина прохода должна быть больше 0"
        else -> null
    }

    /**
     * n = 1000 * Vc / (pi * D), не больше maxRpm
     * F = n * fz * z
     * проходов по глубине = ceil((H - припуск) / ap), по ширине = ceil((W - припуск) / ae)
     * Q = ap * ae * F / 1000, см3/мин
     * время = длина пути / подача
     */
    fun plan(i: CuttingInput): CuttingPlan {
        val nIdeal = 1000.0 * i.vc / (PI * i.diameter)
        val limited = nIdeal > i.maxRpm
        val n = if (limited) i.maxRpm.toDouble() else nIdeal
        val vcActual = PI * i.diameter * n / 1000.0
        val feed = n * i.fz * i.teeth

        val roughDepth = i.totalDepth - i.allowance
        val roughWidth = i.totalWidth - i.allowance
        val axial = ceil(roughDepth / i.ap).toInt().coerceAtLeast(1)
        val radial = ceil(roughWidth / i.ae).toInt().coerceAtLeast(1)
        val apAct = roughDepth / axial
        val aeAct = roughWidth / radial
        val roughPath = axial.toDouble() * radial * i.length
        val roughTime = roughPath / feed

        val hasFinish = i.allowance > 0
        val finishFeed = feed * FINISH_FEED_FACTOR
        val finishAxial = ceil(i.totalDepth / i.cuttingLength).toInt().coerceAtLeast(1)
        val finishTime = if (hasFinish) finishAxial * i.length / finishFeed else 0.0

        return CuttingPlan(
            rpm = n.roundToInt(),
            rpmIdeal = nIdeal.roundToInt(),
            rpmLimited = limited,
            vcActual = vcActual,
            feed = feed.roundToInt(),
            fz = i.fz,
            axialPasses = axial,
            radialPasses = radial,
            apActual = apAct,
            aeActual = aeAct,
            removalRate = apAct * aeAct * feed / 1000.0,
            roughTimeMin = roughTime,
            hasFinish = hasFinish,
            finishFeed = finishFeed.roundToInt(),
            finishTimeMin = finishTime,
            totalTimeMin = roughTime + finishTime,
        )
    }
}
