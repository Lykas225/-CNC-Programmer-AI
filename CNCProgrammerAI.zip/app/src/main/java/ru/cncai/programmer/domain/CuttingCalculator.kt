package ru.cncai.programmer.domain

import kotlin.math.PI
import kotlin.math.roundToInt

data class CuttingResult(
    val vc: Double,
    val fz: Double,
    val teeth: Int,
    val rpm: Int,   // S, об/мин
    val feed: Int,  // F, мм/мин
)

object CuttingCalculator {
    /**
     * n = 1000 * Vc / (pi * D)
     * F = n * fz * z
     */
    fun calculate(vc: Double, diameter: Double, teeth: Int, fz: Double): CuttingResult {
        require(vc > 0 && diameter > 0 && teeth > 0 && fz > 0) { "Параметры должны быть > 0" }
        val n = 1000.0 * vc / (PI * diameter)
        val f = n * fz * teeth
        return CuttingResult(vc, fz, teeth, n.roundToInt(), f.roundToInt())
    }
}
