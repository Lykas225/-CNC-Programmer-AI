package ru.cncai.programmer.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

/** Одно сообщение диалога. content — то, что уходит модели (с вложениями), shown — что видит пользователь. */
data class ChatMsg(val role: String, val shown: String, val content: String, val attached: String)

/** Ключ API и модель хранятся только на телефоне (файл cnc_ai исключён из резервных копий). */
object AiStore {
    const val DEFAULT_MODEL = "claude-sonnet-5-5"
    val MODELS = listOf(
        "claude-sonnet-5-5" to "Claude Sonnet 5.5 (баланс скорости и качества)",
        "claude-opus-5-5" to "Claude Opus 5.5 (сильнее, дороже и медленнее)",
        "claude-haiku-5-5" to "Claude Haiku 5.5 (быстро и дёшево)",
    )

    val apiKey = mutableStateOf("")
    val model = mutableStateOf(DEFAULT_MODEL)
    val messages = mutableStateListOf<ChatMsg>()
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.getSharedPreferences("cnc_ai", Context.MODE_PRIVATE)
        apiKey.value = prefs?.getString("key", "") ?: ""
        model.value = prefs?.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    }

    fun save(key: String, modelId: String) {
        apiKey.value = key.trim()
        model.value = modelId
        prefs?.edit()?.putString("key", key.trim())?.putString("model", modelId)?.apply()
    }

    fun clearKey() {
        apiKey.value = ""
        prefs?.edit()?.remove("key")?.apply()
    }
}
