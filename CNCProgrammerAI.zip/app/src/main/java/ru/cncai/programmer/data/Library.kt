package ru.cncai.programmer.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

/** Стартовые режимы для твёрдосплавной фрезы. Это ориентир: сверяйте с каталогом инструмента. */
data class Material(
    val id: Long,
    val name: String,
    val hardness: String,
    val vc: Double,   // скорость резания, м/мин
    val fz: Double,   // подача на зуб, мм/зуб
)

data class Tool(
    val id: Long,
    val name: String,
    val type: String,
    val diameter: Double,
    val teeth: Int,
    val cuttingLength: Double,  // рабочая длина, мм
    val totalLength: Double,    // общая длина, мм
    val toolMaterial: String,
    val t: Int,                 // номер инструмента T
    val h: Int,                 // корректор длины H
    val d: Int,                 // корректор радиуса D
)

object Library {
    val toolTypes = listOf(
        "Концевая фреза", "Торцевая фреза", "Сферическая фреза", "Радиусная фреза",
        "Фасочная фреза", "Пазовая фреза", "Резьбофреза", "Сверло",
    )
    val toolMaterials = listOf("Твёрдый сплав", "Быстрорежущая сталь (HSS)", "Керамика")

    val materials = mutableStateListOf<Material>()
    val tools = mutableStateListOf<Tool>()
    private var prefs: SharedPreferences? = null

    private val defaultMaterials = listOf(
        Material(1, "Сталь 45", "HB 180–220", 150.0, 0.06),
        Material(2, "09Г2С", "HB 150–190", 140.0, 0.06),
        Material(3, "Алюминий Д16Т", "HB 70–90", 350.0, 0.10),
        Material(4, "Нержавеющая сталь 12Х18Н10Т", "HB 200–240", 80.0, 0.04),
        Material(5, "Чугун СЧ20", "HB 180–230", 120.0, 0.08),
        Material(6, "Латунь Л63", "HB 80–110", 250.0, 0.10),
        Material(7, "Титан ВТ6", "HB 300–340", 50.0, 0.04),
    )

    private val defaultTools = listOf(
        Tool(1, "Концевая фреза Ø6", "Концевая фреза", 6.0, 3, 15.0, 50.0, "Твёрдый сплав", 1, 1, 1),
        Tool(2, "Концевая фреза Ø10", "Концевая фреза", 10.0, 4, 22.0, 72.0, "Твёрдый сплав", 2, 2, 2),
        Tool(3, "Концевая фреза Ø12", "Концевая фреза", 12.0, 4, 26.0, 75.0, "Твёрдый сплав", 3, 3, 3),
        Tool(4, "Концевая фреза Ø16", "Концевая фреза", 16.0, 4, 32.0, 92.0, "Твёрдый сплав", 4, 4, 4),
        Tool(5, "Торцевая фреза Ø50", "Торцевая фреза", 50.0, 5, 10.0, 50.0, "Твёрдый сплав", 5, 5, 5),
    )

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.getSharedPreferences("cnc_library", Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        val p = prefs
        val m = try { p?.getString("materials", null)?.let { materialsFromJson(it) } } catch (e: Exception) { null }
        val t = try { p?.getString("tools", null)?.let { toolsFromJson(it) } } catch (e: Exception) { null }
        materials.clear()
        materials.addAll(m ?: defaultMaterials)
        tools.clear()
        tools.addAll(t ?: defaultTools)
    }

    private fun save() {
        prefs?.edit()
            ?.putString("materials", materialsToJson(materials))
            ?.putString("tools", toolsToJson(tools))
            ?.apply()
    }

    /** id == 0 — новая запись. */
    fun saveMaterial(m: Material) {
        val i = materials.indexOfFirst { it.id == m.id }
        if (m.id != 0L && i >= 0) {
            materials[i] = m
        } else {
            val newId = (materials.maxOfOrNull { it.id } ?: 0L) + 1
            materials.add(m.copy(id = newId))
        }
        save()
    }

    fun deleteMaterial(id: Long) {
        materials.removeAll { it.id == id }
        save()
    }

    fun saveTool(t: Tool) {
        val i = tools.indexOfFirst { it.id == t.id }
        if (t.id != 0L && i >= 0) {
            tools[i] = t
        } else {
            val newId = (tools.maxOfOrNull { it.id } ?: 0L) + 1
            tools.add(t.copy(id = newId))
        }
        save()
    }

    fun deleteTool(id: Long) {
        tools.removeAll { it.id == id }
        save()
    }

    fun nextToolNumber(): Int = (tools.maxOfOrNull { it.t } ?: 0) + 1

    fun resetDefaults() {
        materials.clear()
        materials.addAll(defaultMaterials)
        tools.clear()
        tools.addAll(defaultTools)
        save()
    }

    private fun materialsToJson(list: List<Material>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("name", it.name).put("hardness", it.hardness)
                    .put("vc", it.vc).put("fz", it.fz)
            )
        }
        return arr.toString()
    }

    private fun materialsFromJson(s: String): List<Material> {
        val arr = JSONArray(s)
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Material(o.getLong("id"), o.getString("name"), o.getString("hardness"), o.getDouble("vc"), o.getDouble("fz"))
        }
    }

    private fun toolsToJson(list: List<Tool>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("name", it.name).put("type", it.type)
                    .put("diameter", it.diameter).put("teeth", it.teeth)
                    .put("cutLen", it.cuttingLength).put("totLen", it.totalLength)
                    .put("toolMaterial", it.toolMaterial)
                    .put("t", it.t).put("h", it.h).put("d", it.d)
            )
        }
        return arr.toString()
    }

    private fun toolsFromJson(s: String): List<Tool> {
        val arr = JSONArray(s)
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            Tool(
                o.getLong("id"), o.getString("name"), o.getString("type"),
                o.getDouble("diameter"), o.getInt("teeth"),
                o.getDouble("cutLen"), o.getDouble("totLen"), o.getString("toolMaterial"),
                o.getInt("t"), o.getInt("h"), o.getInt("d"),
            )
        }
    }
}
