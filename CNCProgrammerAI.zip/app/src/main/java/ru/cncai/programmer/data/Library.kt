package ru.cncai.programmer.data

/** Стартовые режимы для твёрдосплавной фрезы. Это ориентир: сверяйте с каталогом инструмента. */
data class Material(
    val name: String,
    val hardness: String,
    val vc: Double,   // скорость резания, м/мин
    val fz: Double,   // подача на зуб, мм/зуб
)

data class Tool(
    val name: String,
    val diameter: Double,
    val teeth: Int,
    val t: Int,       // номер инструмента T
    val h: Int,       // корректор длины H
    val d: Int,       // корректор радиуса D
)

object Library {
    val materials = listOf(
        Material("Сталь 45", "HB 180–220", 150.0, 0.06),
        Material("Алюминий Д16Т", "HB 70–90", 350.0, 0.10),
        Material("Нержавеющая сталь 12Х18Н10Т", "HB 200–240", 80.0, 0.04),
        Material("Чугун СЧ20", "HB 180–230", 120.0, 0.08),
        Material("Латунь Л63", "HB 80–110", 250.0, 0.10),
        Material("Титан ВТ6", "HB 300–340", 50.0, 0.04),
    )

    val tools = listOf(
        Tool("Концевая фреза Ø6", 6.0, 3, 1, 1, 1),
        Tool("Концевая фреза Ø10", 10.0, 4, 2, 2, 2),
        Tool("Концевая фреза Ø12", 12.0, 4, 3, 3, 3),
        Tool("Концевая фреза Ø16", 16.0, 4, 4, 4, 4),
        Tool("Торцевая фреза Ø50", 50.0, 5, 5, 5, 5),
    )
}
