package ru.cncai.programmer

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import ru.cncai.programmer.domain.Operations
import ru.cncai.programmer.ui.*

private data class TabItem(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabItem("home", "Главная", Icons.Default.Home),
    TabItem("projects", "Проекты", Icons.Default.List),
    TabItem("settings", "Настройки", Icons.Default.Settings),
    TabItem("about", "О программе", Icons.Default.Info),
)

@Composable
fun AppNav() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val back: () -> Unit = { nav.popBackStack() }

    Scaffold(
        bottomBar = {
            if (tabs.any { it.route == route }) {
                NavigationBar(containerColor = Panel) {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = {
                                nav.navigate(t.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") { HomeScreen(onOpen = { nav.navigate(it) }) }
            composable("materials") { MaterialsScreen(back) }
            composable("calc") { CalcScreen(back) }
            composable("operations") { OperationsScreen(back) { nav.navigate("op/$it") } }
            composable("op/{id}") { e ->
                val op = Operations.byId(e.arguments?.getString("id") ?: "")
                StubScreen(op?.title ?: "Операция", "Форма ввода параметров и расчёт траектории будут на этапе 5.", back)
            }
            composable("gcode") { StubScreen("Генерация G-кода", "Генератор Fanuc 0i Plus будет на этапе 6.", back) }
            composable("simulation") { StubScreen("Симуляция траектории", "2D/3D симулятор будет на этапе 8.", back) }
            composable("check") { StubScreen("Проверка УП", "Проверка программ будет на этапе 9.", back) }
            composable("projects") { SimpleTab("Проекты", listOf("Проектов пока нет.", "Сохранение проектов появится на этапе 11.")) }
            composable("settings") {
                SimpleTab("Настройки", listOf("Стойка: Fanuc 0i Plus", "Оси: X, Y, Z", "Единицы: миллиметры", "Постпроцессор: этап 6"))
            }
            composable("about") { SimpleTab("О программе", listOf("CNC Programmer AI", "Версия 0.2.0 (этап 2)", "Готовые программы нужно проверять перед запуском на станке.")) }
        }
    }
}
