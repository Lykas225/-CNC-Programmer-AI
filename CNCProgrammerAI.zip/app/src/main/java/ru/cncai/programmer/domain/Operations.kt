package ru.cncai.programmer.domain

data class OperationInfo(val id: String, val title: String)

/**
 * Каждая технологическая операция — отдельный модуль.
 * Чтобы добавить новую: реализовать Operation и внести в Operations.all.
 * Генерация кадров появится на этапах 5–6.
 */
interface Operation {
    val info: OperationInfo
    fun generate(params: Map<String, Double>): List<String>
}

object Operations {
    val all = listOf(
        OperationInfo("pocket_rect", "Прямоугольный карман"),
        OperationInfo("pocket_round", "Круглый карман"),
        OperationInfo("contour_outer", "Наружный контур"),
        OperationInfo("contour_inner", "Внутренний контур"),
        OperationInfo("drill", "Отверстие (сверление)"),
        OperationInfo("slot", "Паз"),
        OperationInfo("facing", "Торцовое фрезерование"),
        OperationInfo("step", "Уступ"),
        OperationInfo("spot_face", "Цекование"),
        OperationInfo("chamfer", "Фаска"),
        OperationInfo("thread_mill", "Резьбофрезерование"),
        OperationInfo("macro", "Макрос Fanuc Macro B (G65)"),
    )

    fun byId(id: String): OperationInfo? = all.firstOrNull { it.id == id }
}
