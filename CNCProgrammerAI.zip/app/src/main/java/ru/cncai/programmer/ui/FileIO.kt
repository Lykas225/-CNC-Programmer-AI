package ru.cncai.programmer.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatTime(ms: Long): String =
    if (ms <= 0) "" else SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(Date(ms))

fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
}

/** Сохранение файла через системный выбор места (Загрузки, облако и т.д.): разрешения не нужны. */
@Composable
fun rememberExporter(): (String, ByteArray) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<ByteArray?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri: Uri? ->
        val data = pending
        if (uri != null && data != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) }
                toast(ctx, "Файл сохранён")
            } catch (e: Exception) {
                toast(ctx, "Не удалось сохранить файл: ${e.message}")
            }
        }
        pending = null
    }
    return { name, bytes ->
        pending = bytes
        launcher.launch(name)
    }
}

/** Выбор файла на телефоне: возвращает имя и текст (UTF-8, при ошибке кодировки — Windows-1251). */
@Composable
fun rememberImporter(onText: (String, String) -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val cb by rememberUpdatedState(onText)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
                if (bytes.size > 2_000_000) {
                    toast(ctx, "Файл больше 2 МБ: он не похож на программу ЧПУ")
                } else {
                    var text = String(bytes, Charsets.UTF_8)
                    if (text.contains('\uFFFD')) text = String(bytes, charset("windows-1251"))
                    var name = "Программа"
                    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) {
                            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (idx >= 0) name = c.getString(idx) ?: name
                        }
                    }
                    cb(name, text)
                }
            } catch (e: Exception) {
                toast(ctx, "Не удалось прочитать файл: ${e.message}")
            }
        }
    }
    return { launcher.launch(arrayOf("*/*")) }
}

fun shareText(ctx: Context, title: String, text: String) {
    if (text.length > 200_000) {
        toast(ctx, "Программа слишком большая для отправки текстом: сохраните файл")
        return
    }
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, title)
        putExtra(Intent.EXTRA_TEXT, text)
    }
    ctx.startActivity(Intent.createChooser(i, "Поделиться программой"))
}
