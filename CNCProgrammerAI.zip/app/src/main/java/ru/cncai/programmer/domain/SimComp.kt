package ru.cncai.programmer.domain

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Пересчёт траектории с коррекцией на радиус (G41/G42) в траекторию центра фрезы.
 * Работает по кадрам: линии смещаются, радиус дуг меняется на радиус фрезы,
 * на внутренних углах кадры подрезаются, на внешних вставляется дуга.
 * Врезание и отмена коррекции — прямые ходы (тип A).
 */
object CompApplier {
    class Result(val moves: List<Move>, val infos: List<MoveInfo>, val warnings: List<String>)

    private class CSeg(
        var arc: Boolean,
        var ax: Double, var ay: Double, var az: Double,
        var bx: Double, var by: Double, var bz: Double,
        var cx: Double, var cy: Double, var ccw: Boolean,
        val feed: Int,
        val info: MoveInfo,
    )

    private fun tanStart(s: CSeg): Pair<Double, Double> {
        if (!s.arc) {
            val dx = s.bx - s.ax
            val dy = s.by - s.ay
            val l = hypot(dx, dy)
            return if (l < 1e-12) Pair(1.0, 0.0) else Pair(dx / l, dy / l)
        }
        val ux = s.ax - s.cx
        val uy = s.ay - s.cy
        val l = hypot(ux, uy)
        if (l < 1e-12) return Pair(1.0, 0.0)
        val tx = -uy / l
        val ty = ux / l
        return if (s.ccw) Pair(tx, ty) else Pair(-tx, -ty)
    }

    private fun tanEnd(s: CSeg): Pair<Double, Double> {
        if (!s.arc) return tanStart(s)
        val ux = s.bx - s.cx
        val uy = s.by - s.cy
        val l = hypot(ux, uy)
        if (l < 1e-12) return Pair(1.0, 0.0)
        val tx = -uy / l
        val ty = ux / l
        return if (s.ccw) Pair(tx, ty) else Pair(-tx, -ty)
    }

    private fun offsetSeg(s: CSeg, r: Double, sgn: Double, warnings: MutableList<String>): CSeg {
        if (!s.arc) {
            val t = tanStart(s)
            val nx = sgn * (-t.second) * r
            val ny = sgn * t.first * r
            return CSeg(false, s.ax + nx, s.ay + ny, s.az, s.bx + nx, s.by + ny, s.bz, 0.0, 0.0, true, s.feed, s.info)
        }
        val rad = hypot(s.ax - s.cx, s.ay - s.cy)
        var r2 = rad + (if (s.ccw) -sgn else sgn) * r
        if (r2 <= 0.001) {
            warnings.add("Строка ${s.info.line}: радиус дуги меньше радиуса фрезы при G41/G42 (контур будет искажён)")
            r2 = 0.001
        }
        val k = if (rad < 1e-12) 1.0 else r2 / rad
        return CSeg(
            true,
            s.cx + (s.ax - s.cx) * k, s.cy + (s.ay - s.cy) * k, s.az,
            s.cx + (s.bx - s.cx) * k, s.cy + (s.by - s.cy) * k, s.bz,
            s.cx, s.cy, s.ccw, s.feed, s.info,
        )
    }

    private fun toMove(s: CSeg): Move =
        if (!s.arc) Move(MoveType.LINEAR, s.bx, s.by, s.bz, 0.0, 0.0, s.feed)
        else Move(if (s.ccw) MoveType.ARC_CCW else MoveType.ARC_CW, s.bx, s.by, s.bz, s.cx - s.ax, s.cy - s.ay, s.feed)

    fun apply(moves: List<Move>, infos: List<MoveInfo>, radiusByD: Map<Int, Double>): Result {
        val outM = ArrayList<Move>()
        val outI = ArrayList<MoveInfo>()
        val warnings = ArrayList<String>()
        fun info(i: Int): MoveInfo = if (i < infos.size) infos[i] else MoveInfo(0, 0, 0, 0, false)

        var i = 0
        while (i < moves.size) {
            val m = moves[i]
            val isOn = m.type == MoveType.COMP_LEFT || m.type == MoveType.COMP_RIGHT
            if (!isOn || i == 0) {
                // COMP_OFF без включения и прочие кадры: как линия
                val t = if (m.type == MoveType.COMP_OFF || m.type == MoveType.COMP_LEFT || m.type == MoveType.COMP_RIGHT) MoveType.LINEAR else m.type
                outM.add(if (t == m.type) m else Move(t, m.x, m.y, m.z, m.i, m.j, m.feed))
                outI.add(info(i).copy(comp = 0))
                i++
                continue
            }
            val sgn = if (m.type == MoveType.COMP_LEFT) 1.0 else -1.0
            val inf = info(i)
            val r = radiusByD[inf.d]
            var e = i + 1
            while (e < moves.size) {
                val t = moves[e].type
                if (t == MoveType.COMP_OFF || t == MoveType.RAPID || t == MoveType.COMP_LEFT || t == MoveType.COMP_RIGHT) break
                e++
            }
            val hasCancel = e < moves.size && moves[e].type == MoveType.COMP_OFF
            val last = if (hasCancel) e else e - 1

            if (r == null || r <= 0.0) {
                warnings.add("Строка ${inf.line}: для корректора D${inf.d} нет инструмента, коррекция в симуляции не применена")
                for (k in i..last) {
                    val q = moves[k]
                    val t = if (q.type == MoveType.ARC_CW || q.type == MoveType.ARC_CCW) q.type else MoveType.LINEAR
                    outM.add(if (t == q.type) q else Move(t, q.x, q.y, q.z, 0.0, 0.0, q.feed))
                    outI.add(info(k).copy(comp = 0))
                }
                i = last + 1
                continue
            }
            if (e == i + 1) {
                // нет контура между включением и отменой
                for (k in i..last) {
                    val q = moves[k]
                    outM.add(Move(MoveType.LINEAR, q.x, q.y, q.z, 0.0, 0.0, q.feed))
                    outI.add(info(k).copy(comp = 0))
                }
                i = last + 1
                continue
            }

            val segs = ArrayList<CSeg>()
            var px = m.x
            var py = m.y
            var pz = m.z
            for (k in i + 1 until e) {
                val c = moves[k]
                val ci = info(k)
                if (c.type == MoveType.ARC_CW || c.type == MoveType.ARC_CCW) {
                    segs.add(CSeg(true, px, py, pz, c.x, c.y, c.z, px + c.i, py + c.j, c.type == MoveType.ARC_CCW, c.feed, ci))
                } else {
                    segs.add(CSeg(false, px, py, pz, c.x, c.y, c.z, 0.0, 0.0, true, c.feed, ci))
                }
                px = c.x
                py = c.y
                pz = c.z
            }

            val out = ArrayList<CSeg>()
            for (k in segs.indices) {
                val cur = offsetSeg(segs[k], r, sgn, warnings)
                if (k > 0) {
                    val prevO = segs[k - 1]
                    val thisO = segs[k]
                    val t1 = tanEnd(prevO)
                    val t2 = tanStart(thisO)
                    val cross = t1.first * t2.second - t1.second * t2.first
                    val dot = t1.first * t2.first + t1.second * t2.second
                    val delta = atan2(cross, dot)
                    if (abs(delta) > 0.01) {
                        val vx = thisO.ax
                        val vy = thisO.ay
                        val n1x = sgn * (-t1.second)
                        val n1y = sgn * t1.first
                        val n2x = sgn * (-t2.second)
                        val n2y = sgn * t2.first
                        val inside = sgn * cross > 0
                        val prevOut = out[out.size - 1]
                        if (inside && !prevO.arc && !thisO.arc) {
                            var den = 1 + (n1x * n2x + n1y * n2y)
                            if (den < 0.2) den = 0.2
                            val mx = vx + r * (n1x + n2x) / den
                            val my = vy + r * (n1y + n2y) / den
                            prevOut.bx = mx
                            prevOut.by = my
                            cur.ax = mx
                            cur.ay = my
                        } else if (!inside) {
                            out.add(
                                CSeg(true, prevOut.bx, prevOut.by, prevOut.bz, cur.ax, cur.ay, cur.az, vx, vy, delta > 0, cur.feed, cur.info)
                            )
                        } else {
                            out.add(CSeg(false, prevOut.bx, prevOut.by, prevOut.bz, cur.ax, cur.ay, cur.az, 0.0, 0.0, true, cur.feed, cur.info))
                        }
                    }
                }
                out.add(cur)
            }

            // врезание: прямой ход к смещённому началу контура
            outM.add(Move(MoveType.LINEAR, out[0].ax, out[0].ay, out[0].az, 0.0, 0.0, m.feed))
            outI.add(inf.copy(comp = 0))
            for (s in out) {
                outM.add(toMove(s))
                outI.add(s.info.copy(comp = 0))
            }
            if (hasCancel) {
                val k = moves[e]
                outM.add(Move(MoveType.LINEAR, k.x, k.y, k.z, 0.0, 0.0, k.feed))
                outI.add(info(e).copy(comp = 0))
                i = e + 1
            } else {
                i = e
            }
        }
        return Result(outM, outI, warnings)
    }
}
