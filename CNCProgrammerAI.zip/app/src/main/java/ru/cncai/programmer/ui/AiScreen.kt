package ru.cncai.programmer.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.cncai.programmer.data.AiClient
import ru.cncai.programmer.data.AiStore
import ru.cncai.programmer.data.ChatMsg
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.MacroCatalog
import ru.cncai.programmer.data.MacroStore
import ru.cncai.programmer.data.PostStore
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.data.Tool
import ru.cncai.programmer.data.UserMacro
import ru.cncai.programmer.domain.AiPrompts
import ru.cncai.programmer.domain.CheckContext
import ru.cncai.programmer.domain.CheckSeverity
import ru.cncai.programmer.domain.CheckTool
import ru.cncai.programmer.domain.GcodeGenerator
import ru.cncai.programmer.domain.MacroChecker
import ru.cncai.programmer.domain.MacroParser
import ru.cncai.programmer.domain.Operations
import ru.cncai.programmer.domain.ProgramChecker
import ru.cncai.programmer.domain.Project
import ru.cncai.programmer.domain.ToolRef
import ru.cncai.programmer.domain.ToolSpec

private val AOk = Color(0xFF4ADE80)
private val AWarn = Color(0xFFFFB84D)
private val AErr = Color(0xFFFF6B6B)
private const val MAX_PROGRAM_LINES = 1200

private class Quick(val label: String, val prompt: String, val project: Boolean, val program: Boolean, val report: Boolean)

private val QUICK = listOf(
    Quick("Объяснить G-код", "Объясни по шагам, что делает эта программа и что означают её команды.", true, true, false),
    Quick("Найти ошибки", "Найди ошибки и риски в этой программе и предложи исправления с указанием строк.", true, true, true),
    Quick("Создать макрос", "Составь макрос Fanuc Macro B для такой задачи: ", false, false, false),
    Quick("Технология", "Объясни технологию обработки этой детали: порядок операций, режимы, на что обратить внимание.", true, false, false),
    Quick("Начальные режимы", "Предложи начальные режимы резания (S, F, ap, ae) для материала и инструментов этого проекта и объясни выбор.", true, false, false),
    Quick("Порядок операций", "Предложи, как оптимизировать последовательность операций в проекте: смены инструмента, холостые ходы, жёсткость детали.", true, false, false),
)

private fun describeProject(p: Project, tools: List<Tool>, maxRpm: Int): String {
    val part = p.part
    val sb = StringBuilder()
    sb.append("Станок: Fanuc 0i Plus, 3 оси, мм, предел оборотов $maxRpm об/мин.\n")
    sb.append("Проект: ${p.name}. Деталь: ${partSummary(part)}. Материал: ${part.materialName}. ")
    sb.append("Ноль: ${part.zeroXY.title}, ${part.zeroZ.title}, ${part.wcs}.\n")
    if (p.features.isNotEmpty()) {
        sb.append("Элементы (координаты в системе нуля детали, мм):\n")
        p.features.forEachIndexed { i, f -> sb.append("${i + 1}. ${f.type.title}: ${describeFeature(f)}\n") }
    }
    if (p.operations.isNotEmpty()) {
        sb.append("Операции по порядку:\n")
        p.operations.forEachIndexed { i, op ->
            val tool = tools.firstOrNull { it.id == op.toolId }
            val title = Operations.byId(op.kind)?.title ?: op.kind
            val tn = tool?.let { "T${it.t} ${it.name}, Ø${it.diameter.fmt()}, зубьев ${it.teeth}" } ?: "инструмент удалён"
            if (op.kind == "macro") {
                val m = MacroCatalog.byRef(op.macroRef)
                sb.append("${i + 1}. Макрос ${m?.name ?: "?"}: G65 P${m?.program ?: 0} ${op.args}; $tn; Vc ${op.vc.fmt2()}, fz ${op.fz.fmt2()}\n")
            } else {
                sb.append("${i + 1}. $title; $tn; Vc ${op.vc.fmt2()} м/мин, fz ${op.fz.fmt2()}, ap ${op.ap.fmt2()}, ae ${op.ae.fmt2()}, припуск ${op.allowance.fmt2()}")
                if (op.kind == "contour_outer" || op.kind == "facing") sb.append(", глубина ${op.depth.fmt2()}")
                sb.append("\n")
            }
        }
    }
    if (tools.isNotEmpty()) {
        sb.append("Библиотека инструмента:\n")
        for (t in tools) sb.append("T${t.t} ${t.name}: Ø${t.diameter.fmt()}, зубьев ${t.teeth}, раб. длина ${t.cuttingLength.fmt()}, ${t.toolMaterial}\n")
    }
    return sb.toString().trimEnd()
}

private fun aiCtx(project: Project, tools: List<Tool>, maxRpm: Int): CheckContext =
    CheckContext(
        project.part,
        tools.map { CheckTool(it.t, it.name, it.diameter / 2, it.d, it.h, it.type == "Сферическая фреза") },
        maxRpm,
    )

private class Seg(val code: Boolean, val text: String)

private val LANG_TAG = Regex("^[a-z][a-z0-9+#-]{0,14}$")

private fun segments(t: String): List<Seg> {
    val parts = t.split("```")
    val out = ArrayList<Seg>()
    for (i in parts.indices) {
        var s = parts[i]
        if (i % 2 == 1) {
            val nl = s.indexOf('\n')
            if (nl >= 0 && LANG_TAG.matches(s.substring(0, nl).trim())) s = s.substring(nl + 1)
            val c = s.trim('\n', ' ')
            if (c.isNotBlank()) out.add(Seg(true, c))
        } else {
            val c = s.replace("**", "").trim()
            if (c.isNotEmpty()) out.add(Seg(false, c))
        }
    }
    return out
}

@Composable
fun AiScreen(onBack: () -> Unit) {
    val project = ProjectStore.current.value
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var attachProject by remember { mutableStateOf(true) }
    var attachProgram by remember { mutableStateOf(false) }
    var attachReport by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(AiStore.apiKey.value.isBlank()) }

    fun send() {
        val q = input.trim()
        if (q.isEmpty() || busy) return
        val key = AiStore.apiKey.value
        if (key.isBlank()) {
            error = "Сначала укажите API-ключ в настройках ИИ."
            showSettings = true
            return
        }
        val wantProject = attachProject
        val wantProgram = attachProgram
        val wantReport = attachReport
        val model = AiStore.model.value
        val tools = Library.tools.toList()
        val post = PostStore.settings.value
        val rpm = Library.maxRpm.intValue
        val macros = MacroCatalog.entries()
        scope.launch {
            busy = true
            error = null
            val built = withContext(Dispatchers.Default) {
                val sb = StringBuilder(q)
                val labels = ArrayList<String>()
                if (wantProject) {
                    sb.append("\n\n[Проект]\n").append(describeProject(project, tools, rpm))
                    labels.add("проект")
                }
                if (wantProgram || wantReport) {
                    val refs = tools.map { ToolRef(it.id, ToolSpec(it.name, it.type, it.diameter, it.teeth, it.cuttingLength), it.t, it.h, it.d) }
                    val g = GcodeGenerator.generate(project, refs, post, rpm, macros)
                    if (g.errors.isNotEmpty()) {
                        sb.append("\n\n[Программу сформировать не удалось]\n").append(g.errors.joinToString("\n"))
                        labels.add("ошибки формирования")
                    } else {
                        val lines = g.lines
                        if (wantProgram) {
                            sb.append("\n\n[G-код программы, нумерация строк = номер строки в тексте]\n")
                            lines.take(MAX_PROGRAM_LINES).forEachIndexed { i, l -> sb.append("${i + 1}: $l\n") }
                            if (lines.size > MAX_PROGRAM_LINES) sb.append("... (показаны первые $MAX_PROGRAM_LINES строк из ${lines.size})\n")
                            labels.add("G-код")
                        }
                        if (wantReport) {
                            val rep = ProgramChecker.check(lines.joinToString("\n"), aiCtx(project, tools, rpm))
                            sb.append("\n\n[Результат проверки УП приложением]\n")
                            if (rep.issues.isEmpty()) sb.append("замечаний нет\n")
                            rep.issues.take(40).forEach {
                                sb.append("строка ${it.line} [${if (it.severity == CheckSeverity.ERROR) "ошибка" else "предупреждение"}]: ${it.message}\n")
                            }
                            labels.add("результат проверки")
                        }
                    }
                }
                Pair(sb.toString(), labels.joinToString(", "))
            }
            val history = ArrayList<Pair<String, String>>()
            for (m in AiStore.messages.toList().takeLast(8)) {
                history.add(Pair(m.role, if (m.role == "user") m.shown else m.content))
            }
            history.add(Pair("user", built.first))
            val r = AiClient.ask(key, model, AiPrompts.SYSTEM, history)
            if (r.text != null) {
                AiStore.messages.add(ChatMsg("user", q, built.first, built.second))
                AiStore.messages.add(ChatMsg("assistant", r.text, r.text, ""))
                input = ""
            } else {
                error = r.error
            }
            busy = false
        }
    }

    ScreenFrame("ИИ-помощник", onBack) {
        val hasKey = AiStore.apiKey.value.isNotBlank()
        if (!hasKey) {
            Text("Нужен API-ключ Anthropic и интернет.", color = AWarn, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
        }
        TextButton(onClick = { showSettings = !showSettings }, modifier = Modifier.fillMaxWidth()) {
            Text(if (showSettings) "Скрыть настройки ИИ" else "Настройки ИИ (ключ, модель)")
        }
        if (showSettings) AiSettings { showSettings = false }

        Text("Быстрые задачи", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QUICK.forEach { qk ->
                OutlinedButton(onClick = {
                    input = qk.prompt
                    attachProject = qk.project
                    attachProgram = qk.program
                    attachReport = qk.report
                }) { Text(qk.label) }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Вопрос или задание") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            maxLines = 8,
        )
        Spacer(Modifier.height(4.dp))
        Text("Приложить к запросу:", color = Muted, fontSize = 13.sp)
        ASwitch("Данные проекта (деталь, элементы, операции, инструмент)", attachProject) { attachProject = it }
        ASwitch("G-код программы", attachProgram) { attachProgram = it }
        ASwitch("Результат проверки УП", attachReport) { attachReport = it }
        Spacer(Modifier.height(6.dp))
        Button(onClick = { send() }, enabled = !busy && input.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Text(if (busy) "Запрос выполняется…" else "Отправить")
        }
        if (busy) {
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }
        error?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = AErr, fontSize = 13.sp)
        }

        val msgs = AiStore.messages.toList()
        if (msgs.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Диалог (новые сверху)", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                TextButton(onClick = { AiStore.messages.clear() }) { Text("Очистить") }
            }
            val pairs = ArrayList<Pair<ChatMsg, ChatMsg?>>()
            var idx = 0
            while (idx < msgs.size) {
                val m = msgs[idx]
                if (m.role == "user") {
                    val nx = msgs.getOrNull(idx + 1)
                    if (nx != null && nx.role == "assistant") {
                        pairs.add(Pair(m, nx))
                        idx += 2
                    } else {
                        pairs.add(Pair(m, null))
                        idx += 1
                    }
                } else idx += 1
            }
            pairs.reversed().forEach { pr ->
                PanelCard {
                    Text("Вы", color = Muted, fontSize = 12.sp)
                    Text(pr.first.shown, fontSize = 14.sp)
                    if (pr.first.attached.isNotEmpty()) Text("Приложено: ${pr.first.attached}", color = Muted, fontSize = 12.sp)
                }
                val a = pr.second
                if (a != null) AnswerView(a.content, project)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            "Ответы ИИ могут содержать ошибки. Код от ИИ не проверен на станке: перед использованием прогоните его через «Проверку УП» и «Симуляцию», затем проверьте на холостом ходу. " +
                "Вопросы и выбранные вложения отправляются в Anthropic по вашему ключу.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 16.dp),
        )
    }
}

@Composable
private fun ASwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun AiSettings(onDone: () -> Unit) {
    var key by remember { mutableStateOf(AiStore.apiKey.value) }
    var modelIdx by remember { mutableIntStateOf(AiStore.MODELS.indexOfFirst { it.first == AiStore.model.value }.coerceAtLeast(0)) }
    PanelCard {
        Text("Настройки ИИ", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            label = { Text("API-ключ Anthropic") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Picker("Модель", AiStore.MODELS.map { it.second }, modelIdx) { modelIdx = it }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    AiStore.save(key, AiStore.MODELS[modelIdx].first)
                    onDone()
                },
                modifier = Modifier.weight(1f),
            ) { Text("Сохранить") }
            OutlinedButton(
                onClick = {
                    AiStore.clearKey()
                    key = ""
                },
                modifier = Modifier.weight(1f),
            ) { Text("Удалить ключ") }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "Ключ создаётся в консоли Anthropic (раздел API keys). Запросы оплачиваются с вашего аккаунта. " +
                "Ключ хранится только на этом телефоне и не попадает в резервные копии. Для работы нужен интернет.",
            color = Muted, fontSize = 12.sp,
        )
    }
}

@Composable
private fun AnswerView(content: String, project: Project) {
    val segs = remember(content) { segments(content) }
    PanelCard {
        Text("Claude", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        segs.forEach { s ->
            if (!s.code) {
                Text(s.text, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
            } else {
                CodeBlock(s.text, project)
            }
        }
        if (segs.any { it.code }) {
            Text(
                "Код не проверен на станке. Проверьте его кнопкой ниже, затем в «Проверке УП», «Симуляции» и на холостом ходу.",
                color = AWarn, fontSize = 12.sp,
            )
        }
    }
}

@Composable
private fun CodeBlock(code: String, project: Project) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var lines by remember(code) { mutableStateOf<List<Pair<Boolean, String>>?>(null) }
    var hasErrors by remember(code) { mutableStateOf(false) }
    var saved by remember(code) { mutableStateOf(false) }
    var checking by remember(code) { mutableStateOf(false) }
    val isMacro = remember(code) {
        Regex("^\\s*O\\d+", RegexOption.MULTILINE).containsMatchIn(code) && code.contains("M99")
    }

    suspend fun runCheck() {
        checking = true
        val tools = Library.tools.toList()
        val rpm = Library.maxRpm.intValue
        val res = withContext(Dispatchers.Default) {
            try {
                if (isMacro) {
                    MacroChecker.check(code).map { Pair(it.isError, "строка ${it.line}: ${it.message}") }
                } else {
                    ProgramChecker.check(code, aiCtx(project, tools, rpm)).issues.map {
                        Pair(it.severity == CheckSeverity.ERROR, "строка ${it.line}: ${it.message}")
                    }
                }
            } catch (e: Exception) {
                listOf(Pair(true, "Проверка не выполнена: ${e.message}"))
            }
        }
        lines = res
        hasErrors = res.any { it.first }
        checking = false
    }

    Column(Modifier.padding(bottom = 8.dp)) {
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            Text(code, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)) }) { Text("Копировать") }
            TextButton(onClick = { scope.launch { runCheck() } }, enabled = !checking) {
                Text(if (checking) "Проверка…" else "Проверить")
            }
            if (isMacro) {
                TextButton(onClick = {
                    scope.launch {
                        if (lines == null) runCheck()
                        if (!hasErrors) {
                            val num = MacroParser.programNumber(code)
                            MacroStore.save(UserMacro(0L, "ИИ: O$num", code, ""))
                            saved = true
                        }
                    }
                }) { Text(if (saved) "Сохранено" else "В «Мои макросы»") }
            }
        }
        val l = lines
        if (l != null) {
            if (l.isEmpty()) {
                Text("Проверка: замечаний не найдено (это не гарантия безопасности).", color = AOk, fontSize = 12.sp)
            } else {
                l.take(8).forEach {
                    Text("• ${it.second}", color = if (it.first) AErr else AWarn, fontSize = 12.sp)
                }
                if (l.size > 8) Text("… и ещё ${l.size - 8}", color = Muted, fontSize = 12.sp)
                if (!isMacro && !code.contains("M30")) {
                    Text("Это фрагмент: замечания про начало и конец программы можно игнорировать.", color = Muted, fontSize = 12.sp)
                }
                if (isMacro && hasErrors) Text("С ошибками макрос не сохраняется: исправьте их или попросите ИИ переписать.", color = AErr, fontSize = 12.sp)
            }
        }
    }
}

