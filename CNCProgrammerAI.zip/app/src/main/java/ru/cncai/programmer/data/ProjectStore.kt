package ru.cncai.programmer.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import ru.cncai.programmer.domain.Feature
import ru.cncai.programmer.domain.FeatureType
import ru.cncai.programmer.domain.OpInstance
import ru.cncai.programmer.domain.Part
import ru.cncai.programmer.domain.PartShape
import ru.cncai.programmer.domain.Project
import ru.cncai.programmer.domain.ZeroXY
import ru.cncai.programmer.domain.ZeroZ

/** Текущий проект. Полноценный список проектов появится на этапе 11. */
object ProjectStore {
    private fun defaultProject() = Project(
        name = "Корпус_001",
        part = Part(PartShape.RECT, 100.0, 70.0, 20.0, ZeroXY.CORNER_LL, ZeroZ.TOP, "G54", "Сталь 45"),
        features = emptyList(),
    )

    val current = mutableStateOf(defaultProject())
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.getSharedPreferences("cnc_project", Context.MODE_PRIVATE)
        val s = prefs?.getString("project", null)
        if (s != null) {
            try {
                current.value = fromJson(s)
            } catch (e: Exception) {
                // повреждённые данные: остаёмся на проекте по умолчанию
            }
        }
    }

    fun updatePart(name: String, part: Part) {
        current.value = current.value.copy(name = name, part = part)
        save()
    }

    /** id == 0 — новый элемент. */
    fun saveFeature(f: Feature) {
        val list = current.value.features
        val i = list.indexOfFirst { it.id == f.id }
        val newList = if (f.id != 0L && i >= 0) {
            list.toMutableList().also { it[i] = f }
        } else {
            val newId = (list.maxOfOrNull { it.id } ?: 0L) + 1
            list + f.copy(id = newId)
        }
        current.value = current.value.copy(features = newList)
        save()
    }

    fun deleteFeature(id: Long) {
        current.value = current.value.copy(features = current.value.features.filter { it.id != id })
        save()
    }

    /** id == 0 — новая операция. */
    fun saveOperation(op: OpInstance) {
        val list = current.value.operations
        val i = list.indexOfFirst { it.id == op.id }
        val newList = if (op.id != 0L && i >= 0) {
            list.toMutableList().also { it[i] = op }
        } else {
            val newId = (list.maxOfOrNull { it.id } ?: 0L) + 1
            list + op.copy(id = newId)
        }
        current.value = current.value.copy(operations = newList)
        save()
    }

    fun deleteOperation(id: Long) {
        current.value = current.value.copy(operations = current.value.operations.filter { it.id != id })
        save()
    }

    private fun save() {
        prefs?.edit()?.putString("project", toJson(current.value))?.apply()
    }

    private fun toJson(p: Project): String {
        val part = JSONObject()
            .put("shape", p.part.shape.name).put("sizeX", p.part.sizeX).put("sizeY", p.part.sizeY)
            .put("thickness", p.part.thickness).put("zeroXY", p.part.zeroXY.name)
            .put("zeroZ", p.part.zeroZ.name).put("wcs", p.part.wcs).put("material", p.part.materialName)
        val arr = JSONArray()
        p.features.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("type", it.type.name)
                    .put("x", it.x).put("y", it.y).put("x2", it.x2).put("y2", it.y2)
                    .put("a", it.a).put("b", it.b).put("r", it.r).put("depth", it.depth)
            )
        }
        val ops = JSONArray()
        p.operations.forEach {
            ops.put(
                JSONObject()
                    .put("id", it.id).put("kind", it.kind).put("featureId", it.featureId).put("toolId", it.toolId)
                    .put("vc", it.vc).put("fz", it.fz).put("ap", it.ap).put("ae", it.ae)
                    .put("allowance", it.allowance).put("depth", it.depth).put("stock", it.stock)
                    .put("safeZ", it.safeZ).put("macroRef", it.macroRef).put("args", it.args)
            )
        }
        return JSONObject().put("name", p.name).put("part", part).put("features", arr).put("operations", ops).toString()
    }

    private fun fromJson(s: String): Project {
        val o = JSONObject(s)
        val po = o.getJSONObject("part")
        val part = Part(
            PartShape.valueOf(po.getString("shape")),
            po.getDouble("sizeX"), po.getDouble("sizeY"), po.getDouble("thickness"),
            ZeroXY.valueOf(po.getString("zeroXY")), ZeroZ.valueOf(po.getString("zeroZ")),
            po.getString("wcs"), po.getString("material"),
        )
        val arr = o.getJSONArray("features")
        val feats = List(arr.length()) { i ->
            val f = arr.getJSONObject(i)
            Feature(
                f.getLong("id"), FeatureType.valueOf(f.getString("type")),
                f.getDouble("x"), f.getDouble("y"), f.getDouble("x2"), f.getDouble("y2"),
                f.getDouble("a"), f.getDouble("b"), f.getDouble("r"), f.getDouble("depth"),
            )
        }
        val opsArr = o.optJSONArray("operations")
        val ops = List(opsArr?.length() ?: 0) { i ->
            val q = opsArr!!.getJSONObject(i)
            OpInstance(
                q.getLong("id"), q.getString("kind"), q.getLong("featureId"), q.getLong("toolId"),
                q.getDouble("vc"), q.getDouble("fz"), q.getDouble("ap"), q.getDouble("ae"),
                q.getDouble("allowance"), q.getDouble("depth"), q.getDouble("stock"), q.getDouble("safeZ"),
                q.optString("macroRef", ""), q.optString("args", ""),
            )
        }
        return Project(o.getString("name"), part, feats, ops)
    }
}
