package ru.cncai.programmer.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import ru.cncai.programmer.domain.Feature
import ru.cncai.programmer.domain.FeatureType
import ru.cncai.programmer.domain.OpInstance
import ru.cncai.programmer.domain.Part
import ru.cncai.programmer.domain.PartShape
import ru.cncai.programmer.domain.Project
import ru.cncai.programmer.domain.ZeroXY
import ru.cncai.programmer.domain.ZeroZ

data class ProjectMeta(val id: Long, val name: String, val updated: Long)

/** Проекты хранятся на телефоне: список и текущий проект (с него работают все разделы). */
object ProjectStore {
    private fun defaultProject(name: String = "Корпус_001") = Project(
        name = name,
        part = Part(PartShape.RECT, 100.0, 70.0, 20.0, ZeroXY.CORNER_LL, ZeroZ.TOP, "G54", "Сталь 45"),
        features = emptyList(),
    )

    val current = mutableStateOf(defaultProject())
    val projects = mutableStateListOf<ProjectMeta>()
    val currentId = mutableLongStateOf(1L)
    private var prefs: SharedPreferences? = null

    private fun now(): Long = System.currentTimeMillis()

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.getSharedPreferences("cnc_projects", Context.MODE_PRIVATE)
        prefs = p
        loadIndex(p)
        if (projects.isEmpty()) {
            // перенос проекта из прежней версии приложения (один проект)
            val old = context.getSharedPreferences("cnc_project", Context.MODE_PRIVATE).getString("project", null)
            val proj = (try {
                if (old != null) fromJson(old) else null
            } catch (e: Exception) {
                null
            }) ?: defaultProject()
            val id = 1L
            projects.add(ProjectMeta(id, proj.name, now()))
            p.edit().putString("p_$id", toJson(proj)).apply()
            currentId.longValue = id
            current.value = proj
            persistIndex()
        } else {
            val cid = p.getLong("cur", projects[0].id)
            loadInto(if (projects.any { it.id == cid }) cid else projects[0].id)
        }
    }

    private fun loadIndex(p: SharedPreferences) {
        val s = p.getString("index", null) ?: return
        try {
            val arr = JSONArray(s)
            projects.clear()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                projects.add(ProjectMeta(o.getLong("id"), o.getString("name"), o.optLong("updated", 0L)))
            }
        } catch (e: Exception) {
            projects.clear()
        }
    }

    private fun persistIndex() {
        val arr = JSONArray()
        projects.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name).put("updated", it.updated)) }
        prefs?.edit()?.putString("index", arr.toString())?.putLong("cur", currentId.longValue)?.apply()
    }

    private fun loadInto(id: Long) {
        val s = prefs?.getString("p_$id", null)
        current.value = try {
            if (s != null) fromJson(s) else defaultProject()
        } catch (e: Exception) {
            defaultProject()
        }
        currentId.longValue = id
        persistIndex()
    }

    private fun save() {
        val id = currentId.longValue
        prefs?.edit()?.putString("p_$id", toJson(current.value))?.apply()
        val i = projects.indexOfFirst { it.id == id }
        if (i >= 0) projects[i] = ProjectMeta(id, current.value.name, now())
        persistIndex()
    }

    fun newProject(name: String) {
        val nm = name.trim().ifBlank { "Новый проект" }
        val id = (projects.maxOfOrNull { it.id } ?: 0L) + 1
        val proj = defaultProject(nm)
        projects.add(ProjectMeta(id, nm, now()))
        prefs?.edit()?.putString("p_$id", toJson(proj))?.apply()
        current.value = proj
        currentId.longValue = id
        persistIndex()
    }

    fun open(id: Long) {
        if (projects.any { it.id == id }) loadInto(id)
    }

    private fun jsonOf(id: Long): String? =
        if (id == currentId.longValue) toJson(current.value) else prefs?.getString("p_$id", null)

    fun duplicate(id: Long) {
        val s = jsonOf(id) ?: return
        try {
            val p = fromJson(s)
            val nm = p.name + " (копия)"
            val nid = (projects.maxOfOrNull { it.id } ?: 0L) + 1
            projects.add(ProjectMeta(nid, nm, now()))
            prefs?.edit()?.putString("p_$nid", toJson(p.copy(name = nm)))?.apply()
            persistIndex()
        } catch (e: Exception) {
            // повреждённый проект не копируется
        }
    }

    fun rename(id: Long, name: String) {
        val nm = name.trim()
        if (nm.isEmpty()) return
        if (id == currentId.longValue) {
            current.value = current.value.copy(name = nm)
            save()
            return
        }
        val s = prefs?.getString("p_$id", null) ?: return
        try {
            val p = fromJson(s).copy(name = nm)
            prefs?.edit()?.putString("p_$id", toJson(p))?.apply()
            val i = projects.indexOfFirst { it.id == id }
            if (i >= 0) projects[i] = ProjectMeta(id, nm, now())
            persistIndex()
        } catch (e: Exception) {
            // ничего не меняем
        }
    }

    fun delete(id: Long) {
        projects.removeAll { it.id == id }
        prefs?.edit()?.remove("p_$id")?.apply()
        if (id == currentId.longValue) {
            if (projects.isNotEmpty()) loadInto(projects[0].id) else newProject("Новый проект")
        } else {
            persistIndex()
        }
    }

    fun exportJson(p: Project): String = toJson(p)

    /** Добавляет проект из файла как новый. Возвращает false, если файл не распознан. */
    fun importJson(text: String): Boolean {
        return try {
            val p = fromJson(text)
            val nid = (projects.maxOfOrNull { it.id } ?: 0L) + 1
            projects.add(ProjectMeta(nid, p.name, now()))
            prefs?.edit()?.putString("p_$nid", toJson(p))?.apply()
            persistIndex()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun updatePart(name: String, part: Part) {
        current.value = current.value.copy(name = name, part = part)
        save()
    }

    /** id == 0 — новый элемент. */
    fun saveFeature(f: Feature) {
        val list = current.value.features
        val i = list.indexOfFirst { it.id == f.id }
        val newList = if (f.id != 0L && i >= 0) {
            list.toMutableList().also { it[i] = f }
        } else {
            val newId = (list.maxOfOrNull { it.id } ?: 0L) + 1
            list + f.copy(id = newId)
        }
        current.value = current.value.copy(features = newList)
        save()
    }

    fun deleteFeature(id: Long) {
        current.value = current.value.copy(features = current.value.features.filter { it.id != id })
        save()
    }

    /** id == 0 — новая операция. */
    fun saveOperation(op: OpInstance) {
        val list = current.value.operations
        val i = list.indexOfFirst { it.id == op.id }
        val newList = if (op.id != 0L && i >= 0) {
            list.toMutableList().also { it[i] = op }
        } else {
            val newId = (list.maxOfOrNull { it.id } ?: 0L) + 1
            list + op.copy(id = newId)
        }
        current.value = current.value.copy(operations = newList)
        save()
    }

    fun deleteOperation(id: Long) {
        current.value = current.value.copy(operations = current.value.operations.filter { it.id != id })
        save()
    }

    private fun toJson(p: Project): String {
        val part = JSONObject()
            .put("shape", p.part.shape.name).put("sizeX", p.part.sizeX).put("sizeY", p.part.sizeY)
            .put("thickness", p.part.thickness).put("zeroXY", p.part.zeroXY.name)
            .put("zeroZ", p.part.zeroZ.name).put("wcs", p.part.wcs).put("material", p.part.materialName)
        val arr = JSONArray()
        p.features.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id).put("type", it.type.name)
                    .put("x", it.x).put("y", it.y).put("x2", it.x2).put("y2", it.y2)
                    .put("a", it.a).put("b", it.b).put("r", it.r).put("depth", it.depth)
            )
        }
        val ops = JSONArray()
        p.operations.forEach {
            ops.put(
                JSONObject()
                    .put("id", it.id).put("kind", it.kind).put("featureId", it.featureId).put("toolId", it.toolId)
                    .put("vc", it.vc).put("fz", it.fz).put("ap", it.ap).put("ae", it.ae)
                    .put("allowance", it.allowance).put("depth", it.depth).put("stock", it.stock)
                    .put("safeZ", it.safeZ).put("macroRef", it.macroRef).put("args", it.args)
            )
        }
        return JSONObject().put("name", p.name).put("part", part).put("features", arr).put("operations", ops).toString()
    }

    private fun fromJson(s: String): Project {
        val o = JSONObject(s)
        val po = o.getJSONObject("part")
        val part = Part(
            PartShape.valueOf(po.getString("shape")),
            po.getDouble("sizeX"), po.getDouble("sizeY"), po.getDouble("thickness"),
            ZeroXY.valueOf(po.getString("zeroXY")), ZeroZ.valueOf(po.getString("zeroZ")),
            po.getString("wcs"), po.getString("material"),
        )
        val arr = o.getJSONArray("features")
        val feats = List(arr.length()) { i ->
            val f = arr.getJSONObject(i)
            Feature(
                f.getLong("id"), FeatureType.valueOf(f.getString("type")),
                f.getDouble("x"), f.getDouble("y"), f.getDouble("x2"), f.getDouble("y2"),
                f.getDouble("a"), f.getDouble("b"), f.getDouble("r"), f.getDouble("depth"),
            )
        }
        val opsArr = o.optJSONArray("operations")
        val ops = List(opsArr?.length() ?: 0) { i ->
            val q = opsArr!!.getJSONObject(i)
            OpInstance(
                q.getLong("id"), q.getString("kind"), q.getLong("featureId"), q.getLong("toolId"),
                q.getDouble("vc"), q.getDouble("fz"), q.getDouble("ap"), q.getDouble("ae"),
                q.getDouble("allowance"), q.getDouble("depth"), q.getDouble("stock"), q.getDouble("safeZ"),
                q.optString("macroRef", ""), q.optString("args", ""),
            )
        }
        return Project(o.getString("name"), part, feats, ops)
    }
}
