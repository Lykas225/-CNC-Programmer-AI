package ru.cncai.programmer.domain

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

data class SimTool(val t: Int, val name: String, val radius: Double, val ball: Boolean)

data class SimIssue(val point: Int, val line: Int, val message: String)

private class FBuf {
    var a = FloatArray(4096)
    var n = 0
    fun add(v: Float) {
        if (n == a.size) a = a.copyOf(n * 2)
        a[n] = v
        n++
    }
    fun arr(): FloatArray = a.copyOf(n)
}

private class IBuf {
    var a = IntArray(4096)
    var n = 0
    fun add(v: Int) {
        if (n == a.size) a = a.copyOf(n * 2)
        a[n] = v
        n++
    }
    fun arr(): IntArray = a.copyOf(n)
}

private class BBuf {
    var a = BooleanArray(4096)
    var n = 0
    fun add(v: Boolean) {
        if (n == a.size) a = a.copyOf(n * 2)
        a[n] = v
        n++
    }
    fun arr(): BooleanArray = a.copyOf(n)
}

/** Точки траектории центра инструмента с шагом выборки; cum — «время» проигрывания (быстрые ходы идут быстрее). */
class SimPath(
    val x: FloatArray,
    val y: FloatArray,
    val z: FloatArray,
    val cut: BooleanArray,
    val spindle: BooleanArray,
    val line: IntArray,
    val tool: IntArray,
    val cum: DoubleArray,
    val moveStart: IntArray,
) {
    val n: Int get() = x.size
    val total: Double get() = if (n == 0) 0.0 else cum[n - 1]

    /** Наибольший индекс точки, до которой дошло «время» t. */
    fun indexAt(t: Double): Int {
        if (n == 0) return 0
        var lo = 0
        var hi = n - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (cum[mid] <= t) lo = mid else hi = mid - 1
        }
        return lo
    }

    /** Индекс начала следующего кадра после точки p (или последняя точка). */
    fun nextMove(p: Int): Int {
        for (s in moveStart) if (s > p) return s
        return n - 1
    }

    fun prevMove(p: Int): Int {
        var best = 0
        for (s in moveStart) {
            if (s < p) best = s else break
        }
        return best
    }
}

object SimBuilder {
    private const val MAX_POINTS = 600_000
    private const val RAPID_WEIGHT = 0.15

    fun build(moves: List<Move>, infos: List<MoveInfo>, ds0: Double): SimPath {
        if (moves.isEmpty()) {
            return SimPath(FloatArray(1), FloatArray(1), FloatArray(1), BooleanArray(1), BooleanArray(1), IntArray(1), IntArray(1), DoubleArray(1), IntArray(0))
        }
        var total = 0.0
        var qx = moves[0].x
        var qy = moves[0].y
        var qz = moves[0].z
        for (k in 1 until moves.size) {
            val m = moves[k]
            if (m.type != MoveType.RAPID) total += sqrt((m.x - qx) * (m.x - qx) + (m.y - qy) * (m.y - qy) + (m.z - qz) * (m.z - qz))
            qx = m.x
            qy = m.y
            qz = m.z
        }
        val ds = max(ds0, total / (MAX_POINTS * 0.7))

        val xs = FBuf()
        val ys = FBuf()
        val zs = FBuf()
        val cuts = BBuf()
        val spin = BBuf()
        val lines = IBuf()
        val tools = IBuf()
        val cum = ArrayList<Double>()
        val moveStart = IntArray(moves.size)

        fun add(x: Double, y: Double, z: Double, cut: Boolean, inf: MoveInfo) {
            val k = xs.n
            var c = 0.0
            if (k > 0) {
                val dx = x - xs.a[k - 1]
                val dy = y - ys.a[k - 1]
                val dz = z - zs.a[k - 1]
                c = cum[k - 1] + sqrt(dx * dx + dy * dy + dz * dz) * (if (cut) 1.0 else RAPID_WEIGHT) + 1e-9
            }
            xs.add(x.toFloat())
            ys.add(y.toFloat())
            zs.add(z.toFloat())
            cuts.add(cut)
            spin.add(inf.spindle)
            lines.add(inf.line)
            tools.add(inf.tool)
            cum.add(c)
        }

        fun infoAt(i: Int): MoveInfo = if (i < infos.size) infos[i] else MoveInfo(0, 0, 0, 0, false)

        var px = moves[0].x
        var py = moves[0].y
        var pz = moves[0].z
        add(px, py, pz, false, infoAt(0))
        for (i in 1 until moves.size) {
            val m = moves[i]
            val inf = infoAt(i)
            moveStart[i] = xs.n
            val rapid = m.type == MoveType.RAPID
            val spacing = if (rapid) 2.0 else ds
            if (m.type == MoveType.ARC_CW || m.type == MoveType.ARC_CCW) {
                val ccw = m.type == MoveType.ARC_CCW
                val cx = px + m.i
                val cy = py + m.j
                val r = hypot(m.i, m.j)
                val sw = ArcMath.sweep(ccw, px, py, m.x, m.y, cx, cy)
                val a0 = atan2(py - cy, px - cx)
                val len = hypot(r * sw, m.z - pz)
                val np = max(1, ceil(len / spacing).toInt())
                for (s in 1..np) {
                    val t = s.toDouble() / np
                    val ang = a0 + (if (ccw) sw else -sw) * t
                    val x = if (s == np) m.x else cx + r * cos(ang)
                    val y = if (s == np) m.y else cy + r * sin(ang)
                    add(x, y, pz + (m.z - pz) * t, true, inf)
                }
            } else {
                val dx = m.x - px
                val dy = m.y - py
                val dz = m.z - pz
                val len = sqrt(dx * dx + dy * dy + dz * dz)
                val np = max(1, ceil(len / spacing).toInt())
                for (s in 1..np) {
                    val t = s.toDouble() / np
                    add(px + dx * t, py + dy * t, pz + dz * t, !rapid, inf)
                }
            }
            px = m.x
            py = m.y
            pz = m.z
        }
        return SimPath(xs.arr(), ys.arr(), zs.arr(), cuts.arr(), spin.arr(), lines.arr(), tools.arr(), cum.toDoubleArray(), moveStart)
    }
}

/** Заготовка в виде карты высот (верхняя поверхность материала). */
class SimStock(val part: Part, targetCells: Int = 160) {
    val round = part.shape == PartShape.ROUND
    val xMin = part.xMin
    val yMin = part.yMin
    val w = part.width
    val hgt = part.height
    val cs: Double = max(0.4, max(w, hgt) / targetCells)
    val nx: Int = max(1, ceil(w / cs).toInt())
    val ny: Int = max(1, ceil(hgt / cs).toInt())
    val zTop: Double = if (part.zeroZ == ZeroZ.TOP) 0.0 else part.thickness
    val zBot: Double = zTop - part.thickness
    val cxw: Double = part.cx
    val cyw: Double = part.cy
    val mask = BooleanArray(nx * ny)

    init {
        for (j in 0 until ny) {
            for (i in 0 until nx) {
                val x = xMin + (i + 0.5) * cs
                val y = yMin + (j + 0.5) * cs
                val inBox = x <= part.xMax + 1e-9 && y <= part.yMax + 1e-9
                val inShape = if (round) hypot(x - cxw, y - cyw) <= w / 2 + 1e-9 else true
                mask[j * nx + i] = inBox && inShape
            }
        }
    }
}

class SimState(private val stock: SimStock, private val path: SimPath, private val tools: Map<Int, SimTool>) {
    val h = FloatArray(stock.nx * stock.ny)
    val owner = ByteArray(stock.nx * stock.ny)
    var applied = 0
        private set
    val issues = ArrayList<SimIssue>()
    val toolOrder = ArrayList<Int>()
    private val toolIdx = HashMap<Int, Int>()

    private class Checkpoint(val applied: Int, val h: FloatArray, val owner: ByteArray)

    private val checkpoints = ArrayList<Checkpoint>()
    private val zTopF = stock.zTop.toFloat()
    private val zBotF = stock.zBot.toFloat()

    init {
        for (k in 0 until path.n) {
            val t = path.tool[k]
            if (t != 0 && !toolIdx.containsKey(t)) {
                toolIdx[t] = toolOrder.size
                toolOrder.add(t)
            }
        }
        reset()
    }

    private fun reset() {
        java.util.Arrays.fill(h, zTopF)
        java.util.Arrays.fill(owner, 0.toByte())
        applied = 0
    }

    private fun stamp(k: Int) {
        if (!path.cut[k] || !path.spindle[k]) return
        val z = path.z[k].toDouble()
        if (z >= stock.zTop) return
        val tool = tools[path.tool[k]]
        val r = tool?.radius ?: 3.0
        val ball = tool?.ball ?: false
        val x = path.x[k].toDouble()
        val y = path.y[k].toDouble()
        val cs = stock.cs
        val i0 = max(0, floor((x - r - stock.xMin) / cs).toInt())
        val i1 = min(stock.nx - 1, floor((x + r - stock.xMin) / cs).toInt())
        val j0 = max(0, floor((y - r - stock.yMin) / cs).toInt())
        val j1 = min(stock.ny - 1, floor((y + r - stock.yMin) / cs).toInt())
        val ow = ((toolIdx[path.tool[k]] ?: 0) + 1).toByte()
        val r2 = r * r
        for (j in j0..j1) {
            val dy = stock.yMin + (j + 0.5) * cs - y
            val row = j * stock.nx
            for (i in i0..i1) {
                val idx = row + i
                if (!stock.mask[idx]) continue
                val dx = stock.xMin + (i + 0.5) * cs - x
                val d2 = dx * dx + dy * dy
                if (d2 > r2) continue
                var zt = z
                if (ball) zt = z + r - sqrt(r2 - d2)
                var zf = zt.toFloat()
                if (zf < zBotF) zf = zBotF
                if (zf < h[idx]) {
                    h[idx] = zf
                    owner[idx] = ow
                }
            }
        }
    }

    private fun hAt(x: Double, y: Double): Double? {
        val i = floor((x - stock.xMin) / stock.cs).toInt()
        val j = floor((y - stock.yMin) / stock.cs).toInt()
        if (i < 0 || j < 0 || i >= stock.nx || j >= stock.ny) return null
        val idx = j * stock.nx + i
        if (!stock.mask[idx]) return null
        return h[idx].toDouble()
    }

    /** Один проход по всей программе: вычисляет контрольные точки и замечания. */
    fun analyze() {
        reset()
        checkpoints.clear()
        issues.clear()
        val seen = HashSet<String>()
        val interval = max(1500, path.n / 80)
        fun add(k: Int, key: String, msg: String) {
            if (issues.size < 60 && seen.add(key + ":" + path.line[k])) issues.add(SimIssue(k, path.line[k], msg))
        }
        for (k in 0 until path.n) {
            val z = path.z[k].toDouble()
            val t = path.tool[k]
            val tool = tools[t]
            val r = tool?.radius ?: 3.0
            if (path.cut[k] && z < stock.zTop - 0.01) {
                if (t == 0) add(k, "notool", "Рабочий ход без выбранного инструмента (нет T и M06)")
                else if (tool == null) add(k, "unk$t", "Инструмент T$t не найден в библиотеке")
                if (!path.spindle[k]) add(k, "nospin", "Рабочий ход без вращения шпинделя (нет M03)")
                val x = path.x[k].toDouble()
                val y = path.y[k].toDouble()
                val margin = max(6 * r, 20.0)
                if (x < stock.xMin - margin || x > stock.xMin + stock.w + margin ||
                    y < stock.yMin - margin || y > stock.yMin + stock.hgt + margin
                ) {
                    add(k, "far", "Рабочий ход далеко за пределами заготовки: проверьте нуль детали и координаты")
                }
            }
            if (z < stock.zBot - 0.01) add(k, "below", "Инструмент опускается ниже низа детали (Z ${GcodeGenerator.fmtNum(z, 2)})")
            if (!path.cut[k] && z < stock.zTop - 0.02) {
                val x = path.x[k].toDouble()
                val y = path.y[k].toDouble()
                var m = hAt(x, y)
                val q = 0.7 * r
                val offs = arrayOf(doubleArrayOf(q, 0.0), doubleArrayOf(-q, 0.0), doubleArrayOf(0.0, q), doubleArrayOf(0.0, -q))
                for (o in offs) {
                    val v = hAt(x + o[0], y + o[1])
                    if (v != null && (m == null || v < m)) m = v
                }
                if (m != null && z < m - 0.02) add(k, "rapid", "Быстрый ход (G00) внутри материала")
            }
            stamp(k)
            applied = k + 1
            if (applied % interval == 0) checkpoints.add(Checkpoint(applied, h.copyOf(), owner.copyOf()))
        }
    }

    /** Приводит карту высот к состоянию после точки p (включительно). */
    fun seek(p: Int) {
        val target = (p + 1).coerceIn(0, path.n)
        if (target < applied) {
            var cp: Checkpoint? = null
            for (c in checkpoints) {
                if (c.applied <= target) cp = c else break
            }
            if (cp != null) {
                System.arraycopy(cp.h, 0, h, 0, h.size)
                System.arraycopy(cp.owner, 0, owner, 0, owner.size)
                applied = cp.applied
            } else {
                reset()
            }
        }
        while (applied < target) {
            stamp(applied)
            applied++
        }
    }

    private val palette = intArrayOf(
        0xFF60A5FA.toInt(), 0xFFF59E0B.toInt(), 0xFF34D399.toInt(), 0xFFF472B6.toInt(),
        0xFFA78BFA.toInt(), 0xFFFB7185.toInt(), 0xFF2DD4BF.toInt(), 0xFFFACC15.toInt(),
    )

    private fun rgb(r: Int, g: Int, b: Int): Int = (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    private fun shaded(base: Int, shade: Float): Int {
        val r = ((base shr 16) and 0xFF)
        val g = ((base shr 8) and 0xFF)
        val b = (base and 0xFF)
        return rgb((r * shade).toInt(), (g * shade).toInt(), (b * shade).toInt())
    }

    private fun baseColor(idx: Int, byTool: Boolean): Int {
        val thick = max(0.001, stock.zTop - stock.zBot).toFloat()
        val frac = ((zTopF - h[idx]) / thick).coerceIn(0f, 1f)
        val ow = owner[idx].toInt()
        if (byTool && ow != 0) {
            val c = palette[(ow - 1) % palette.size]
            val k = 1f - 0.35f * frac
            return shaded(c, k)
        }
        val r = (176 + (30 - 176) * frac).toInt()
        val g = (184 + (90 - 184) * frac).toInt()
        val b = (200 + (220 - 200) * frac).toInt()
        return rgb(r, g, b)
    }

    /** Заполняет массив пикселей вида сверху (строка 0 — верхняя по Y). */
    fun fillPixels(out: IntArray, byTool: Boolean) {
        val nx = stock.nx
        val ny = stock.ny
        for (j in 0 until ny) {
            val row = ny - 1 - j
            for (i in 0 until nx) {
                val idx = j * nx + i
                val o = row * nx + i
                if (!stock.mask[idx]) {
                    out[o] = 0
                    continue
                }
                val hl = h[if (i > 0) idx - 1 else idx]
                val hr = h[if (i < nx - 1) idx + 1 else idx]
                val hd = h[if (j > 0) idx - nx else idx]
                val hu = h[if (j < ny - 1) idx + nx else idx]
                val g = ((hl - hr) + (hu - hd)).toDouble() / (2 * stock.cs)
                val shade = (1.0 + g * 0.35).coerceIn(0.6, 1.3).toFloat()
                out[o] = shaded(baseColor(idx, byTool), shade)
            }
        }
    }

    /** Высоты в узлах сетки (gn+1)×(gn+1) для 3D-вида. */
    fun vertexHeights(gn: Int): FloatArray {
        val out = FloatArray((gn + 1) * (gn + 1))
        for (jv in 0..gn) {
            for (iv in 0..gn) {
                val x = stock.xMin + stock.w * iv / gn
                val y = stock.yMin + stock.hgt * jv / gn
                val i = floor((x - stock.xMin) / stock.cs).toInt().coerceIn(0, stock.nx - 1)
                val j = floor((y - stock.yMin) / stock.cs).toInt().coerceIn(0, stock.ny - 1)
                val idx = j * stock.nx + i
                out[jv * (gn + 1) + iv] = if (stock.mask[idx]) h[idx] else zTopF
            }
        }
        return out
    }

    fun colorAt(frac: Float, ow: Int, byTool: Boolean): Int {
        if (byTool && ow != 0) return shaded(palette[(ow - 1) % palette.size], 1f - 0.35f * frac)
        val r = (176 + (30 - 176) * frac).toInt()
        val g = (184 + (90 - 184) * frac).toInt()
        val b = (200 + (220 - 200) * frac).toInt()
        return rgb(r, g, b)
    }

    fun ownerAtVertex(gn: Int, iv: Int, jv: Int): Int {
        val x = stock.xMin + stock.w * iv / gn
        val y = stock.yMin + stock.hgt * jv / gn
        val i = floor((x - stock.xMin) / stock.cs).toInt().coerceIn(0, stock.nx - 1)
        val j = floor((y - stock.yMin) / stock.cs).toInt().coerceIn(0, stock.ny - 1)
        return owner[j * stock.nx + i].toInt()
    }
}
