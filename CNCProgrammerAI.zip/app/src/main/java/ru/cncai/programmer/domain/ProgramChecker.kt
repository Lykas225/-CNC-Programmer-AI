package ru.cncai.programmer.domain

import kotlin.math.abs

enum class CheckSeverity { ERROR, WARNING }

enum class CheckCategory(val title: String) {
    SYNTAX("Синтаксис G-кода"),
    COMMANDS("Обязательные команды"),
    SEQUENCE("Последовательность операций"),
    VARIABLES("Макропеременные и циклы"),
    SAFETY("Безопасные перемещения"),
    COORDS("Координаты, режимы G20/G21, плоскость G17–G19"),
    BOUNDS("Границы заготовки"),
}

data class CheckIssue(val line: Int, val severity: CheckSeverity, val category: CheckCategory, val message: String)

class CheckReport(val issues: List<CheckIssue>, val lineCount: Int) {
    val errors: Int get() = issues.count { it.severity == CheckSeverity.ERROR }
    val warnings: Int get() = issues.count { it.severity == CheckSeverity.WARNING }

    /** 0 — замечаний нет, 1 — только предупреждения, 2 — есть ошибки. */
    fun status(c: CheckCategory): Int {
        val list = issues.filter { it.category == c }
        if (list.any { it.severity == CheckSeverity.ERROR }) return 2
        return if (list.isNotEmpty()) 1 else 0
    }

    fun count(c: CheckCategory): Int = issues.count { it.category == c }
}

data class CheckTool(val t: Int, val name: String, val radius: Double, val d: Int, val h: Int, val ball: Boolean)

data class CheckContext(val part: Part?, val tools: List<CheckTool>, val maxRpm: Int)

private class Tok(val l: Char, val raw: String, val v: Double?)

object ProgramChecker {
    private val COMMENT = Regex("\\(([^)]*)\\)")
    private const val SANE = 5000.0

    private fun tokenize(body: String): Pair<List<Tok>, String?> {
        val out = ArrayList<Tok>()
        var i = 0
        while (i < body.length) {
            val ch = body[i]
            if (ch !in 'A'..'Z') return Pair(out, body.substring(i))
            val j = i + 1
            if (j >= body.length) return Pair(out, body.substring(i))
            val c = body[j]
            if (c == '[') {
                val e = MacroParser.findClose(body, j)
                if (e < 0) return Pair(out, body.substring(i))
                out.add(Tok(ch, body.substring(j, e + 1), null))
                i = e + 1
                continue
            }
            if (c == '#') {
                var k = j + 1
                if (k < body.length && body[k] == '[') {
                    val e = MacroParser.findClose(body, k)
                    if (e < 0) return Pair(out, body.substring(i))
                    k = e + 1
                } else {
                    while (k < body.length && body[k] in '0'..'9') k++
                    if (k == j + 1) return Pair(out, body.substring(i))
                }
                out.add(Tok(ch, body.substring(j, k), null))
                i = k
                continue
            }
            if (c in 'A'..'Z') {
                var k = j
                while (k < body.length && body[k] in 'A'..'Z') k++
                if (k < body.length && body[k] == '[') {
                    val e = MacroParser.findClose(body, k)
                    if (e < 0) return Pair(out, body.substring(i))
                    out.add(Tok(ch, body.substring(j, e + 1), null))
                    i = e + 1
                    continue
                }
                return Pair(out, body.substring(i))
            }
            var k = j
            if (body[k] == '+' || body[k] == '-') k++
            val s0 = k
            var dot = false
            while (k < body.length && (body[k] in '0'..'9' || (body[k] == '.' && !dot))) {
                if (body[k] == '.') dot = true
                k++
            }
            if (k == s0 || body.substring(s0, k) == ".") return Pair(out, body.substring(i))
            val raw = body.substring(j, k)
            out.add(Tok(ch, raw, raw.toDoubleOrNull()))
            i = k
        }
        return Pair(out, null)
    }

    private fun gGroup(g: Double): Int = when (g.toInt()) {
        0, 1, 2, 3 -> 1
        17, 18, 19 -> 2
        90, 91 -> 3
        20, 21 -> 4
        40, 41, 42 -> 5
        43, 44, 49 -> 6
        54, 55, 56, 57, 58, 59 -> 7
        73, 74, 76, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89 -> 8
        98, 99 -> 9
        93, 94, 95 -> 10
        else -> 0
    }

    fun check(text: String, ctx: CheckContext): CheckReport {
        val issues = ArrayList<CheckIssue>()
        val seen = HashSet<String>()
        fun add(line: Int, sev: CheckSeverity, cat: CheckCategory, msg: String) {
            if (seen.add("$line|${cat.name}|$msg")) issues.add(CheckIssue(line, sev, cat, msg))
        }
        val rows = text.split('\n')

        // 1. построчный синтаксис
        for (k in rows.indices) {
            val n = k + 1
            val row = rows[k]
            val opens = row.count { it == '(' }
            val closes = row.count { it == ')' }
            if (opens != closes) add(n, CheckSeverity.ERROR, CheckCategory.SYNTAX, "Не закрыта скобка комментария")
            val noComment = COMMENT.replace(row, "")
            val bad = noComment.firstOrNull { it.code > 127 }
            if (bad != null) {
                add(n, CheckSeverity.ERROR, CheckCategory.SYNTAX, "Недопустимый символ «$bad» вне комментария (только латиница и цифры)")
            }
            for (m in COMMENT.findAll(row)) {
                if (m.groupValues[1].any { it.code > 127 }) {
                    add(n, CheckSeverity.WARNING, CheckCategory.SYNTAX, "Кириллица в комментарии: большинство стоек Fanuc её не отображает")
                    break
                }
            }
        }
        val nonEmpty = rows.map { it.trim() }.filter { it.isNotEmpty() }
        if (nonEmpty.isNotEmpty() && (nonEmpty.first() == "%") != (nonEmpty.last() == "%")) {
            add(1, CheckSeverity.WARNING, CheckCategory.SYNTAX, "Знак % есть только в начале или только в конце файла")
        }

        // 2. структура программ
        val progs = try {
            MacroParser.parse(text)
        } catch (e: MacroException) {
            add(e.line, CheckSeverity.ERROR, CheckCategory.SYNTAX, e.msg)
            return finish(issues, rows.size)
        }
        if (progs.isEmpty()) {
            add(1, CheckSeverity.ERROR, CheckCategory.SYNTAX, "В тексте нет программы O")
            return finish(issues, rows.size)
        }

        // 3. переменные, метки, циклы
        for (mi in MacroChecker.check(text)) {
            val lower = mi.message.lowercase()
            val cat = if (lower.contains("переменн") || lower.contains("метк") || lower.contains("цикл") ||
                lower.contains("while") || lower.contains("m99")
            ) CheckCategory.VARIABLES else CheckCategory.SYNTAX
            add(mi.line, if (mi.isError) CheckSeverity.ERROR else CheckSeverity.WARNING, cat, mi.message)
        }

        val main = progs.values.first()
        if (main.number == 0) add(1, CheckSeverity.ERROR, CheckCategory.SYNTAX, "Номер программы O0000 недопустим")
        if (main.number in 9000..9999) {
            add(1, CheckSeverity.WARNING, CheckCategory.SYNTAX, "Главная программа O${main.number} в защищённом диапазоне O9000–O9999")
        }
        val hasEnd = main.lines.any { it.body.contains("M30") || it.body.contains("M02") }
        val isSub = !hasEnd && main.lines.any { it.body.contains("M99") }

        if (!isSub) staticMain(main, progs, ctx, ::add)

        // 4. выполнение: ошибки интерпретатора и анализ перемещений по детали
        val run = MacroRunner.run(text, emptyMap(), Triple(0.0, 0.0, 100.0))
        val lineRe = Regex("^Строка (\\d+): (.*)$")
        for (e in run.errors) {
            val m = lineRe.find(e)
            val line = m?.groupValues?.get(1)?.toInt() ?: 0
            val msg = m?.groupValues?.get(2) ?: e
            val cat = when {
                msg.startsWith("Радиусы дуги") -> CheckCategory.COORDS
                msg.startsWith("ALARM") || msg.startsWith("Превышен лимит") -> CheckCategory.VARIABLES
                else -> CheckCategory.SYNTAX
            }
            add(line, CheckSeverity.ERROR, cat, msg)
        }
        val part = ctx.part
        if (run.errors.isEmpty() && part != null && !isSub && run.moves.size > 1) {
            val simTools = HashMap<Int, SimTool>()
            val radiusByD = HashMap<Int, Double>()
            for (t in ctx.tools) {
                simTools[t.t] = SimTool(t.t, t.name, t.radius, t.ball)
                radiusByD[t.d] = t.radius
            }
            val comp = CompApplier.apply(run.moves, run.infos, radiusByD)
            for (w in comp.warnings) add(0, CheckSeverity.WARNING, CheckCategory.COORDS, w)
            val stock = SimStock(part, 120)
            val path = SimBuilder.build(comp.moves, comp.infos, stock.cs * 0.5)
            val state = SimState(stock, path, simTools)
            state.analyze()
            for (si in state.issues) {
                val msg = si.message
                if (msg.startsWith("Рабочий ход без вращения шпинделя") || msg.startsWith("Рабочий ход без выбранного") ||
                    msg.startsWith("Инструмент T")
                ) {
                    continue // эти случаи проверяются статически
                }
                val cat = if (msg.contains("за пределами заготовки")) CheckCategory.BOUNDS else CheckCategory.SAFETY
                add(si.line, CheckSeverity.ERROR, cat, msg)
            }
        }
        return finish(issues, rows.size)
    }

    private fun finish(issues: List<CheckIssue>, lines: Int): CheckReport {
        val sorted = issues.sortedWith(compareBy({ it.line }, { if (it.severity == CheckSeverity.ERROR) 0 else 1 }))
        return CheckReport(sorted, lines)
    }

    /** Статическая проверка главной программы: модальные состояния, обязательные команды, последовательность. */
    private fun staticMain(
        main: MProgram,
        progs: Map<Int, MProgram>,
        ctx: CheckContext,
        add: (Int, CheckSeverity, CheckCategory, String) -> Unit,
    ) {
        val E = CheckSeverity.ERROR
        val W = CheckSeverity.WARNING
        val part = ctx.part

        var units: Int? = null
        var dist: Int? = null
        var plane: Int? = null
        var wcs: Int? = null
        var comp = 0
        var compD = 0
        var tlen = false
        var spindle = false
        var sSeen = false
        var coolant = false
        var toolChanged = false
        var tSeen = false
        var canned: Int? = null
        var cannedR = false
        var motion = -1
        var feedSeen = false
        var retracted = true
        var g43Since = true
        var ended = false
        var lastN = -1
        var firstMotionDone = false
        var noToolWarned = false
        var noPlaneWarned = false
        var g91Warned = false
        var sawG20 = false
        var sawG21 = false
        var lastLine = 0

        for (ln in main.lines) {
            val b = ln.body
            val line = ln.src
            lastLine = line
            if (b.isEmpty()) continue
            val lab = ln.label
            if (lab != null) {
                if (lab <= lastN) add(line, W, CheckCategory.SYNTAX, "Номер кадра N$lab не больше предыдущего N$lastN")
                lastN = lab
            }
            if (b.startsWith("IF[") || b.startsWith("WHILE[") || b.startsWith("GOTO") || b.startsWith("#") ||
                Regex("^(DO|END)\\d$").matches(b)
            ) {
                continue
            }
            val tk = tokenize(b)
            val toks = tk.first
            if (tk.second != null) {
                add(line, E, CheckCategory.SYNTAX, "Не удалось разобрать «${tk.second}»")
            }
            // повтор адресов и групп G
            val gs = toks.filter { it.l == 'G' && it.v != null }.map { it.v!! }
            val groups = HashMap<Int, Double>()
            for (g in gs) {
                val grp = gGroup(g)
                if (grp != 0) {
                    val prev = groups[grp]
                    if (prev != null && prev != g) {
                        add(line, E, CheckCategory.SYNTAX, "Два G-кода одной группы в одном кадре: G${prev.toInt()} и G${g.toInt()}")
                    }
                    groups[grp] = g
                }
            }
            val counts = HashMap<Char, Int>()
            for (t in toks) counts[t.l] = (counts[t.l] ?: 0) + 1
            for ((l, c) in counts) {
                if (c > 1 && l != 'G' && l != 'M') add(line, E, CheckCategory.SYNTAX, "Адрес $l повторяется в кадре")
            }
            val isCall = gs.any { it.toInt() == 65 } || toks.any { it.l == 'M' && it.v?.toInt() == 98 }
            if (isCall) {
                for (t in toks) {
                    if (t.l in "XYZIJKR" && t.v != null && abs(t.v) > SANE) {
                        add(line, E, CheckCategory.COORDS, "Аргумент ${t.l} вне разумных пределов (${t.raw})")
                    }
                }
                continue
            }
            fun tv(l: Char): Tok? = toks.firstOrNull { it.l == l }

            // числовые адреса
            for (t in toks) {
                val v = t.v
                if (t.l in "XYZIJKR" && v != null) {
                    if (abs(v) > SANE) add(line, E, CheckCategory.COORDS, "Координата ${t.l} вне разумных пределов (${t.raw})")
                    if (!t.raw.contains('.') && v != 0.0) {
                        add(line, W, CheckCategory.SYNTAX, "Значение ${t.l}${t.raw} без десятичной точки: результат зависит от параметра DPI (3401#0)")
                    }
                }
            }

            val ms = toks.filter { it.l == 'M' && it.v != null }.map { it.v!!.toInt() }
            val gi = gs.map { it.toInt() }
            val special = gi.contains(28) || gi.contains(53) || gi.contains(92) || gi.contains(10)

            // единицы
            if (gi.contains(20)) {
                sawG20 = true
                units = 20
                if (part != null) add(line, E, CheckCategory.COORDS, "Задан дюймовый режим G20, проект рассчитан в миллиметрах (G21)")
            }
            if (gi.contains(21)) {
                sawG21 = true
                units = 21
            }
            if (sawG20 && sawG21) add(line, W, CheckCategory.COORDS, "В программе есть и G20, и G21")
            for (g in gi) {
                when (g) {
                    90, 91 -> dist = g
                    17, 18, 19 -> plane = g
                    54, 55, 56, 57, 58, 59 -> {
                        wcs = g
                        if (part != null && "G$g" != part.wcs) {
                            add(line, W, CheckCategory.COORDS, "Система координат G$g не совпадает с настроенной в детали (${part.wcs})")
                        }
                    }
                    40 -> comp = 0
                    41, 42 -> comp = g
                    43 -> tlen = true
                    49 -> tlen = false
                    80 -> canned = null
                    81, 82, 83, 84, 85, 86, 87, 88, 89 -> {
                        canned = g
                        cannedR = false
                    }
                    0, 1, 2, 3 -> motion = g
                    else -> {}
                }
            }
            if (dist == 91 && !g91Warned && !special && toks.any { it.l in "XYZ" }) {
                // перемещения в G91 (кроме возврата G28)
                add(line, W, CheckCategory.SEQUENCE, "Перемещения заданы в приращениях (G91): проверьте, что это намеренно")
                g91Warned = true
            }
            // G43 / H
            if (gi.contains(43)) {
                val h = tv('H')
                if (h == null) add(line, E, CheckCategory.COMMANDS, "G43 без адреса H (номер корректора длины)")
                else if (h.v != null && (h.v < 0 || h.v > 99)) add(line, W, CheckCategory.COORDS, "Номер корректора H${h.raw} вне диапазона 0–99")
                g43Since = true
            }
            // D
            val dTok = tv('D')
            if (dTok?.v != null) {
                compD = dTok.v.toInt()
                if (dTok.v < 0 || dTok.v > 99) add(line, W, CheckCategory.COORDS, "Номер корректора D${dTok.raw} вне диапазона 0–99")
            }
            if (gi.contains(41) || gi.contains(42)) {
                if (dTok == null && compD == 0) add(line, E, CheckCategory.COMMANDS, "G41/G42 без корректора радиуса D")
                if (motion == 2 || motion == 3 || gi.contains(2) || gi.contains(3)) {
                    add(line, E, CheckCategory.SEQUENCE, "Включение коррекции G41/G42 на дуге: врезание должно быть прямым ходом G00/G01")
                }
            }
            if (gi.contains(40) && (gi.contains(2) || gi.contains(3))) {
                add(line, E, CheckCategory.SEQUENCE, "Отмена коррекции G40 на дуге: используйте прямой ход")
            }
            // T, S, F
            val tTok = tv('T')
            if (tTok?.v != null) {
                tSeen = true
                if (tTok.v <= 0 || tTok.v > 99) add(line, E, CheckCategory.COORDS, "Номер инструмента T${tTok.raw} вне диапазона 1–99")
                else if (ctx.tools.isNotEmpty() && ctx.tools.none { it.t == tTok.v.toInt() }) {
                    add(line, W, CheckCategory.COMMANDS, "Инструмент T${tTok.raw} не найден в библиотеке приложения")
                }
            }
            val sTok = tv('S')
            if (sTok != null) {
                val sv = sTok.v
                if (sv != null) {
                    if (sv <= 0) add(line, E, CheckCategory.COORDS, "Обороты S${sTok.raw} должны быть больше 0")
                    else if (sv > ctx.maxRpm) add(line, E, CheckCategory.COORDS, "Обороты S${sTok.raw} выше предела станка (${ctx.maxRpm})")
                    else sSeen = true
                } else sSeen = true
            }
            val fTok = tv('F')
            if (fTok != null) {
                val fv = fTok.v
                if (fv != null) {
                    if (fv <= 0) add(line, E, CheckCategory.COORDS, "Подача F${fTok.raw} должна быть больше 0")
                    else {
                        if (fv > 10000) add(line, W, CheckCategory.COORDS, "Подача F${fTok.raw} необычно велика")
                        feedSeen = true
                    }
                } else feedSeen = true
            }
            // M-коды
            for (m in ms) {
                when (m) {
                    3, 4 -> {
                        if (!sSeen) add(line, E, CheckCategory.COMMANDS, "Включение шпинделя M0$m без заданных оборотов S")
                        if (!tSeen && !noToolWarned) {
                            add(line, W, CheckCategory.COMMANDS, "Шпиндель включается до выбора инструмента (нет T и M06)")
                            noToolWarned = true
                        }
                        spindle = true
                    }
                    5 -> spindle = false
                    6 -> {
                        if (!tSeen) add(line, E, CheckCategory.COMMANDS, "M06 без номера инструмента T")
                        if (comp != 0) add(line, E, CheckCategory.SEQUENCE, "Смена инструмента при включённой коррекции G41/G42")
                        if (canned != null) add(line, E, CheckCategory.SEQUENCE, "Смена инструмента при активном цикле (нет G80)")
                        if (!retracted) add(line, W, CheckCategory.SEQUENCE, "Смена инструмента без отвода по Z (G91 G28 Z0)")
                        if (spindle) add(line, W, CheckCategory.SEQUENCE, "Смена инструмента при вращающемся шпинделе (нет M05)")
                        toolChanged = true
                        g43Since = false
                    }
                    8 -> coolant = true
                    9 -> coolant = false
                    30, 2 -> ended = true
                    else -> {}
                }
            }

            // перемещения
            val hasAxis = toks.any { it.l == 'X' || it.l == 'Y' || it.l == 'Z' }
            val cannedActive = canned != null && canned != 80
            if (cannedActive && gi.any { it in 81..89 }) {
                val c = canned
                if (toks.none { it.l == 'R' } && !cannedR) add(line, W, CheckCategory.COMMANDS, "В цикле G$c не задана плоскость возврата R")
                if (toks.any { it.l == 'R' }) cannedR = true
                if (toks.none { it.l == 'Z' }) add(line, E, CheckCategory.COMMANDS, "В цикле G$c не задана глубина Z")
                if (c == 83 && toks.none { it.l == 'Q' }) add(line, E, CheckCategory.COMMANDS, "В цикле G83 не задан шаг Q")
                if (!feedSeen) add(line, E, CheckCategory.COMMANDS, "В цикле G$c нет подачи F")
                val zt = tv('Z')?.v
                if (part != null && zt != null && dist != 91) {
                    val zTop = if (part.zeroZ == ZeroZ.TOP) 0.0 else part.thickness
                    if (zt < zTop - part.thickness - 0.01) add(line, E, CheckCategory.SAFETY, "Глубина цикла Z${tv('Z')!!.raw} ниже низа детали")
                }
            }
            if (cannedActive && part != null && dist != 91) {
                val xv = tv('X')?.v
                val yv = tv('Y')?.v
                if (xv != null && yv != null && !gi.contains(80)) {
                    val inside = if (part.shape == PartShape.RECT) {
                        xv >= part.xMin - 0.01 && xv <= part.xMax + 0.01 && yv >= part.yMin - 0.01 && yv <= part.yMax + 0.01
                    } else {
                        Math.hypot(xv - part.cx, yv - part.cy) <= part.sizeX / 2 + 0.01
                    }
                    if (!inside) add(line, E, CheckCategory.BOUNDS, "Позиция цикла X${tv('X')!!.raw} Y${tv('Y')!!.raw} вне контура заготовки")
                }
            }
            val moving = !special && (hasAxis || (cannedActive && toks.any { it.l == 'X' || it.l == 'Y' }))
            if (moving) {
                if (!firstMotionDone) {
                    firstMotionDone = true
                    if (units == null) add(line, E, CheckCategory.COMMANDS, "До первого перемещения не задан режим единиц G20/G21")
                    if (wcs == null) add(line, E, CheckCategory.COMMANDS, "До первого перемещения не выбрана рабочая система координат G54–G59")
                    if (dist == null) add(line, W, CheckCategory.COMMANDS, "Не задан режим G90/G91")
                }
                val isFeed = motion in 1..3 && !cannedActive
                val isArc = motion == 2 || motion == 3
                if (isArc && !cannedActive) {
                    if (toks.none { it.l == 'I' || it.l == 'J' || it.l == 'K' || it.l == 'R' }) {
                        add(line, E, CheckCategory.COMMANDS, "Дуга G0$motion без I, J, K или R")
                    }
                    if (plane == null && !noPlaneWarned) {
                        add(line, W, CheckCategory.COORDS, "Не задана плоскость G17/G18/G19 перед дугой")
                        noPlaneWarned = true
                    }
                    val p = plane ?: 17
                    if (p == 17 && toks.any { it.l == 'K' }) add(line, E, CheckCategory.COORDS, "В плоскости G17 дуга задаётся I, J, а не K")
                    if (p == 18 && toks.any { it.l == 'J' }) add(line, E, CheckCategory.COORDS, "В плоскости G18 дуга задаётся I, K, а не J")
                    if (p == 19 && toks.any { it.l == 'I' }) add(line, E, CheckCategory.COORDS, "В плоскости G19 дуга задаётся J, K, а не I")
                    if (p != 17) add(line, W, CheckCategory.COORDS, "Рабочая плоскость G$p: симуляция и генератор приложения рассчитаны на G17")
                }
                if (isFeed || cannedActive) {
                    if (!feedSeen) add(line, E, CheckCategory.COMMANDS, "Нет подачи F до первого рабочего хода")
                    if (!spindle) add(line, E, CheckCategory.COMMANDS, "Рабочий ход или цикл при выключенном шпинделе (нет M03/M04)")
                    if (!tSeen && !noToolWarned) {
                        add(line, W, CheckCategory.COMMANDS, "Рабочий ход без выбранного инструмента (нет T и M06)")
                        noToolWarned = true
                    }
                    if (toolChanged && !g43Since) {
                        add(line, W, CheckCategory.COMMANDS, "После смены инструмента не включена коррекция на длину G43 H…")
                        g43Since = true
                    }
                    retracted = false
                }
            }
            if (special && (gi.contains(28) || gi.contains(53))) retracted = true
        }

        if (!ended) {
            add(lastLine, E, CheckCategory.COMMANDS, "Нет конца программы M30 (или M02)")
        }
        if (comp != 0) add(lastLine, E, CheckCategory.SEQUENCE, "Программа заканчивается при включённой коррекции G41/G42 (нет G40)")
        if (canned != null) add(lastLine, E, CheckCategory.SEQUENCE, "Программа заканчивается при активном цикле (нет G80)")
        if (coolant) add(lastLine, W, CheckCategory.SEQUENCE, "Охлаждение включено до конца программы (нет M09)")
        if (dist == 91) add(lastLine, W, CheckCategory.SEQUENCE, "Программа заканчивается в режиме G91")
        // вызовы подпрограмм
        for (ln in main.lines) {
            if (ln.body.contains("M98") || ln.body.contains("G65")) {
                val m = Regex("P(\\d+)").find(ln.body)
                val t = m?.groupValues?.get(1)?.toIntOrNull()
                if (t != null && !progs.containsKey(t)) {
                    add(ln.src, W, CheckCategory.COMMANDS, "Программа O$t вызывается, но не входит в текст: она должна быть в памяти станка")
                }
            }
        }
    }
}
