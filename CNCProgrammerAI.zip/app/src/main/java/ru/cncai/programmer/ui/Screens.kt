package ru.cncai.programmer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.domain.CuttingCalculator
import ru.cncai.programmer.domain.CuttingResult
import ru.cncai.programmer.domain.Operations

private data class Tile(val route: String, val title: String, val icon: ImageVector, val color: Color)

private val tiles = listOf(
    Tile("materials", "Материалы\nи инструменты", Icons.Default.Build, Blue),
    Tile("calc", "Расчёт\nрежимов", Icons.Default.List, Green),
    Tile("operations", "Операции\nобработки", Icons.Default.Create, Purple),
    Tile("gcode", "Генерация\nG-кода", Icons.Default.Edit, Orange),
    Tile("simulation", "Симуляция\nтраектории", Icons.Default.PlayArrow, Teal),
    Tile("check", "Проверка\nУП", Icons.Default.CheckCircle, Slate),
)

@Composable
private fun TileCard(t: Tile, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(110.dp).clip(RoundedCornerShape(16.dp)).background(t.color)
            .clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(t.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(6.dp))
        Text(t.title, color = Color.White, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Blue, modifier = Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("CNC Programmer AI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Fanuc 0i Plus • 3 оси • мм", color = Muted)
            }
        }
        Spacer(Modifier.height(20.dp))
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { t -> TileCard(t, Modifier.weight(1f)) { onOpen(t.route) } }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Последний проект", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        PanelCard { Text("Проектов пока нет", color = Muted) }
    }
}

@Composable
fun MaterialsScreen(onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    ScreenFrame("Материалы и инструменты", onBack) {
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (tab == 0) Button(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("Материалы") }
            else OutlinedButton(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("Материалы") }
            if (tab == 1) Button(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("Фрезы") }
            else OutlinedButton(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("Фрезы") }
        }
        if (tab == 0) {
            Library.materials.forEach { m ->
                PanelCard {
                    Text(m.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(m.hardness, color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Vc ${m.vc.fmt()} м/мин • fz ${m.fz.fmt()} мм/зуб", fontSize = 13.sp)
                }
            }
            Text("Значения стартовые, для твёрдосплавной фрезы. Проверяйте по каталогу инструмента.", color = Muted, fontSize = 12.sp)
        } else {
            Library.tools.forEach { t ->
                PanelCard {
                    Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("Зубьев: ${t.teeth} • T${t.t} H${t.h} D${t.d}", color = Muted, fontSize = 13.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun CalcScreen(onBack: () -> Unit) {
    var mi by remember { mutableIntStateOf(0) }
    var ti by remember { mutableIntStateOf(1) }
    var vc by remember { mutableStateOf(Library.materials[0].vc.fmt()) }
    var fz by remember { mutableStateOf(Library.materials[0].fz.fmt()) }
    var result by remember { mutableStateOf<CuttingResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val tool = Library.tools[ti]

    ScreenFrame("Расчёт режимов", onBack) {
        Picker("Материал", Library.materials.map { it.name }, mi) {
            mi = it
            vc = Library.materials[it].vc.fmt()
            fz = Library.materials[it].fz.fmt()
            result = null
        }
        Picker("Инструмент", Library.tools.map { it.name }, ti) { ti = it; result = null }
        Text("Диаметр ${tool.diameter.fmt()} мм, зубьев ${tool.teeth}", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        NumberField("Скорость резания Vc, м/мин", vc) { vc = it }
        NumberField("Подача на зуб fz, мм/зуб", fz) { fz = it }
        Button(
            onClick = {
                val v = vc.num()
                val f = fz.num()
                if (v == null || f == null || v <= 0 || f <= 0) {
                    error = "Введите положительные числа"
                    result = null
                } else {
                    error = null
                    result = CuttingCalculator.calculate(v, tool.diameter, tool.teeth, f)
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Рассчитать") }
        Spacer(Modifier.height(12.dp))
        error?.let { Text(it, color = Color(0xFFFF6B6B)) }
        result?.let { r ->
            PanelCard {
                Text("Результат расчёта", fontWeight = FontWeight.Bold, color = Color(0xFF4ADE80))
                Spacer(Modifier.height(6.dp))
                Text("Обороты шпинделя S: ${r.rpm} об/мин")
                Text("Рабочая подача F: ${r.feed} мм/мин")
                Text("Подача на зуб: ${r.fz.fmt()} мм/зуб")
                Text("Скорость резания: ${r.vc.fmt()} м/мин")
                Spacer(Modifier.height(6.dp))
                Text("S${r.rpm} M03   F${r.feed}", color = Muted, fontSize = 13.sp)
            }
            Text("Формулы: n = 1000·Vc / (π·D),  F = n · fz · z", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun OperationsScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    ScreenFrame("Операции обработки", onBack) {
        Operations.all.forEach { op ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Panel,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(14.dp)).clickable { onOpen(op.id) },
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(op.title, modifier = Modifier.weight(1f), fontSize = 16.sp)
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = Muted)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun StubScreen(title: String, note: String, onBack: () -> Unit) {
    ScreenFrame(title, onBack) {
        PanelCard { Text(note, color = Muted) }
    }
}

@Composable
fun SimpleTab(title: String, lines: List<String>) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        PanelCard { lines.forEach { Text(it, color = Muted, modifier = Modifier.padding(vertical = 2.dp)) } }
    }
}
