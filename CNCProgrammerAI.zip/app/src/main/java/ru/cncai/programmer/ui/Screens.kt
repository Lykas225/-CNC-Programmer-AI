package ru.cncai.programmer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.Material
import ru.cncai.programmer.data.Tool
import ru.cncai.programmer.domain.CuttingCalculator
import ru.cncai.programmer.domain.CuttingResult
import ru.cncai.programmer.domain.Operations

private data class Tile(val route: String, val title: String, val icon: ImageVector, val color: Color)

private val tiles = listOf(
    Tile("materials", "Материалы\nи инструменты", Icons.Default.Build, Blue),
    Tile("calc", "Расчёт\nрежимов", Icons.Default.List, Green),
    Tile("operations", "Операции\nобработки", Icons.Default.Create, Purple),
    Tile("gcode", "Генерация\nG-кода", Icons.Default.Edit, Orange),
    Tile("simulation", "Симуляция\nтраектории", Icons.Default.PlayArrow, Teal),
    Tile("check", "Проверка\nУП", Icons.Default.CheckCircle, Slate),
)

@Composable
private fun TileCard(t: Tile, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(110.dp).clip(RoundedCornerShape(16.dp)).background(t.color)
            .clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(t.icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(6.dp))
        Text(t.title, color = Color.White, textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Blue, modifier = Modifier.size(48.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("CNC Programmer AI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Fanuc 0i Plus • 3 оси • мм", color = Muted)
            }
        }
        Spacer(Modifier.height(20.dp))
        tiles.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { t -> TileCard(t, Modifier.weight(1f)) { onOpen(t.route) } }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Последний проект", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(6.dp))
        PanelCard { Text("Проектов пока нет", color = Muted) }
    }
}

private val ErrorRed = Color(0xFFFF6B6B)

@Composable
fun MaterialsScreen(onBack: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var editMaterial by remember { mutableStateOf<Material?>(null) }
    var editTool by remember { mutableStateOf<Tool?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    ScreenFrame("Материалы и инструменты", onBack) {
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (tab == 0) Button(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("Материалы") }
            else OutlinedButton(onClick = { tab = 0 }, modifier = Modifier.weight(1f)) { Text("Материалы") }
            if (tab == 1) Button(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("Фрезы") }
            else OutlinedButton(onClick = { tab = 1 }, modifier = Modifier.weight(1f)) { Text("Фрезы") }
        }
        if (tab == 0) {
            Button(
                onClick = { editMaterial = Material(0, "", "", 100.0, 0.05) },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Добавить материал")
            }
            Library.materials.forEach { m ->
                PanelCard(onClick = { editMaterial = m }) {
                    Text(m.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(m.hardness, color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("Vc ${m.vc.fmt()} м/мин • fz ${m.fz.fmt()} мм/зуб", fontSize = 13.sp)
                }
            }
            Text("Значения стартовые, для твёрдосплавной фрезы. Проверяйте по каталогу инструмента. Нажмите на карточку, чтобы изменить.", color = Muted, fontSize = 12.sp)
        } else {
            Button(
                onClick = {
                    val n = Library.nextToolNumber()
                    editTool = Tool(0, "", Library.toolTypes[0], 10.0, 4, 22.0, 72.0, Library.toolMaterials[0], n, n, n)
                },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Добавить фрезу")
            }
            Library.tools.forEach { t ->
                PanelCard(onClick = { editTool = t }) {
                    Text(t.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("${t.type} • Ø${t.diameter.fmt()} (R${(t.diameter / 2).fmt()}) • зубьев ${t.teeth}", color = Muted, fontSize = 13.sp)
                    Text("Длина: рабочая ${t.cuttingLength.fmt()} / общая ${t.totalLength.fmt()} мм", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("T${t.t} H${t.h} D${t.d} • ${t.toolMaterial}", fontSize = 13.sp)
                }
            }
        }
        TextButton(onClick = { confirmReset = true }) { Text("Вернуть стандартные списки", color = Muted) }
        Spacer(Modifier.height(16.dp))
    }

    editMaterial?.let { MaterialDialog(it) { editMaterial = null } }
    editTool?.let { ToolDialog(it) { editTool = null } }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Вернуть стандартные списки?") },
            text = { Text("Все ваши материалы и фрезы будут заменены стандартными. Это нельзя отменить.") },
            confirmButton = { TextButton(onClick = { Library.resetDefaults(); confirmReset = false }) { Text("Вернуть", color = ErrorRed) } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun MaterialDialog(initial: Material, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var hardness by remember { mutableStateOf(initial.hardness) }
    var vc by remember { mutableStateOf(initial.vc.fmt()) }
    var fz by remember { mutableStateOf(initial.fz.fmt()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val isNew = initial.id == 0L

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Новый материал" else "Материал") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TextInput("Название", name) { name = it }
                TextInput("Твёрдость (например HB 180–220)", hardness) { hardness = it }
                NumberField("Скорость резания Vc, м/мин", vc) { vc = it }
                NumberField("Подача на зуб fz, мм/зуб", fz) { fz = it }
                error?.let { Text(it, color = ErrorRed) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = vc.num()
                val f = fz.num()
                val err = when {
                    name.isBlank() -> "Введите название"
                    v == null || v <= 0 -> "Vc должна быть больше 0"
                    f == null || f <= 0 -> "fz должна быть больше 0"
                    else -> null
                }
                if (err != null) {
                    error = err
                } else {
                    Library.saveMaterial(Material(initial.id, name.trim(), hardness.trim(), v!!, f!!))
                    onDismiss()
                }
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                if (!isNew) {
                    TextButton(onClick = {
                        if (confirmDelete) {
                            Library.deleteMaterial(initial.id)
                            onDismiss()
                        } else confirmDelete = true
                    }) { Text(if (confirmDelete) "Точно удалить?" else "Удалить", color = ErrorRed) }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
            }
        },
    )
}

@Composable
private fun ToolDialog(initial: Tool, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var typeIdx by remember { mutableIntStateOf(Library.toolTypes.indexOf(initial.type).coerceAtLeast(0)) }
    var dia by remember { mutableStateOf(initial.diameter.fmt()) }
    var teeth by remember { mutableStateOf(initial.teeth.toString()) }
    var cutLen by remember { mutableStateOf(initial.cuttingLength.fmt()) }
    var totLen by remember { mutableStateOf(initial.totalLength.fmt()) }
    var matIdx by remember { mutableIntStateOf(Library.toolMaterials.indexOf(initial.toolMaterial).coerceAtLeast(0)) }
    var tNum by remember { mutableStateOf(initial.t.toString()) }
    var hNum by remember { mutableStateOf(initial.h.toString()) }
    var dNum by remember { mutableStateOf(initial.d.toString()) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    val isNew = initial.id == 0L

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Новая фреза" else "Фреза") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TextInput("Название (можно пусто)", name) { name = it }
                Picker("Тип инструмента", Library.toolTypes, typeIdx) { typeIdx = it }
                NumberField("Диаметр, мм", dia) { dia = it }
                TextInput("Число зубьев", teeth) { teeth = it }
                NumberField("Рабочая длина, мм", cutLen) { cutLen = it }
                NumberField("Общая длина, мм", totLen) { totLen = it }
                Picker("Материал инструмента", Library.toolMaterials, matIdx) { matIdx = it }
                TextInput("Номер T", tNum) { tNum = it }
                TextInput("Корректор длины H", hNum) { hNum = it }
                TextInput("Корректор радиуса D", dNum) { dNum = it }
                error?.let { Text(it, color = ErrorRed) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val dv = dia.num()
                val z = teeth.trim().toIntOrNull()
                val cl = cutLen.num()
                val tl = totLen.num()
                val tt = tNum.trim().toIntOrNull()
                val hh = hNum.trim().toIntOrNull()
                val dd = dNum.trim().toIntOrNull()
                val err = when {
                    dv == null || dv <= 0 -> "Диаметр должен быть больше 0"
                    z == null || z < 1 -> "Число зубьев: целое число от 1"
                    cl == null || cl <= 0 -> "Введите рабочую длину"
                    tl == null || tl < cl -> "Общая длина не может быть меньше рабочей"
                    tt == null || tt < 1 || hh == null || hh < 1 || dd == null || dd < 1 -> "T, H и D: целые числа от 1"
                    Library.tools.any { it.t == tt && it.id != initial.id } -> "Номер T$tt уже занят другой фрезой"
                    else -> null
                }
                if (err != null) {
                    error = err
                } else {
                    val type = Library.toolTypes[typeIdx]
                    val finalName = name.trim().ifBlank { "$type Ø${dv!!.fmt()}" }
                    Library.saveTool(
                        Tool(initial.id, finalName, type, dv!!, z!!, cl!!, tl!!, Library.toolMaterials[matIdx], tt!!, hh!!, dd!!)
                    )
                    onDismiss()
                }
            }) { Text("Сохранить") }
        },
        dismissButton = {
            Row {
                if (!isNew) {
                    TextButton(onClick = {
                        if (confirmDelete) {
                            Library.deleteTool(initial.id)
                            onDismiss()
                        } else confirmDelete = true
                    }) { Text(if (confirmDelete) "Точно удалить?" else "Удалить", color = ErrorRed) }
                }
                TextButton(onClick = onDismiss) { Text("Отмена") }
            }
        },
    )
}

@Composable
fun CalcScreen(onBack: () -> Unit) {
    if (Library.materials.isEmpty() || Library.tools.isEmpty()) {
        StubScreen("Расчёт режимов", "Добавьте хотя бы один материал и одну фрезу в разделе «Материалы и инструменты».", onBack)
    } else {
        CalcContent(onBack)
    }
}

@Composable
private fun CalcContent(onBack: () -> Unit) {
    var mi by remember { mutableIntStateOf(0) }
    var ti by remember { mutableIntStateOf(if (Library.tools.size > 1) 1 else 0) }
    val mIdx = mi.coerceIn(0, Library.materials.lastIndex)
    val tIdx = ti.coerceIn(0, Library.tools.lastIndex)
    val tool = Library.tools[tIdx]
    var vc by remember { mutableStateOf(Library.materials[mIdx].vc.fmt()) }
    var fz by remember { mutableStateOf(Library.materials[mIdx].fz.fmt()) }
    var result by remember { mutableStateOf<CuttingResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    ScreenFrame("Расчёт режимов", onBack) {
        Picker("Материал", Library.materials.map { it.name }, mIdx) {
            mi = it
            vc = Library.materials[it].vc.fmt()
            fz = Library.materials[it].fz.fmt()
            result = null
        }
        Picker("Инструмент", Library.tools.map { it.name }, tIdx) { ti = it; result = null }
        Text("Диаметр ${tool.diameter.fmt()} мм, зубьев ${tool.teeth}", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        NumberField("Скорость резания Vc, м/мин", vc) { vc = it }
        NumberField("Подача на зуб fz, мм/зуб", fz) { fz = it }
        Button(
            onClick = {
                val v = vc.num()
                val f = fz.num()
                if (v == null || f == null || v <= 0 || f <= 0) {
                    error = "Введите положительные числа"
                    result = null
                } else {
                    error = null
                    result = CuttingCalculator.calculate(v, tool.diameter, tool.teeth, f)
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Рассчитать") }
        Spacer(Modifier.height(12.dp))
        error?.let { Text(it, color = ErrorRed) }
        result?.let { r ->
            PanelCard {
                Text("Результат расчёта", fontWeight = FontWeight.Bold, color = Color(0xFF4ADE80))
                Spacer(Modifier.height(6.dp))
                Text("Обороты шпинделя S: ${r.rpm} об/мин")
                Text("Рабочая подача F: ${r.feed} мм/мин")
                Text("Подача на зуб: ${r.fz.fmt()} мм/зуб")
                Text("Скорость резания: ${r.vc.fmt()} м/мин")
                Spacer(Modifier.height(6.dp))
                Text("S${r.rpm} M03   F${r.feed}", color = Muted, fontSize = 13.sp)
            }
            Text("Формулы: n = 1000·Vc / (π·D),  F = n · fz · z", color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun OperationsScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    ScreenFrame("Операции обработки", onBack) {
        Operations.all.forEach { op ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Panel,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(14.dp)).clickable { onOpen(op.id) },
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(op.title, modifier = Modifier.weight(1f), fontSize = 16.sp)
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = Muted)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
fun StubScreen(title: String, note: String, onBack: () -> Unit) {
    ScreenFrame(title, onBack) {
        PanelCard { Text(note, color = Muted) }
    }
}

@Composable
fun SimpleTab(title: String, lines: List<String>) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        PanelCard { lines.forEach { Text(it, color = Muted, modifier = Modifier.padding(vertical = 2.dp)) } }
    }
}
