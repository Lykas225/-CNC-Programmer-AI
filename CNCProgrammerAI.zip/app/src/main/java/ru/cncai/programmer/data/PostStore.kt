package ru.cncai.programmer.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import org.json.JSONObject
import ru.cncai.programmer.domain.PostSettings

/** Настройки постпроцессора (хранятся на телефоне). */
object PostStore {
    val settings = mutableStateOf(PostSettings())
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.getSharedPreferences("cnc_post", Context.MODE_PRIVATE)
        val s = prefs?.getString("post", null) ?: return
        try {
            val o = JSONObject(s)
            val d = PostSettings()
            settings.value = PostSettings(
                programNumber = o.optInt("programNumber", d.programNumber),
                comment = o.optString("comment", d.comment),
                useLineNumbers = o.optBoolean("useLineNumbers", d.useLineNumbers),
                lineStep = o.optInt("lineStep", d.lineStep),
                decimals = o.optInt("decimals", d.decimals),
                useToolLengthComp = o.optBoolean("useToolLengthComp", d.useToolLengthComp),
                useCoolant = o.optBoolean("useCoolant", d.useCoolant),
                useCutterComp = o.optBoolean("useCutterComp", d.useCutterComp),
                useCannedDrill = o.optBoolean("useCannedDrill", d.useCannedDrill),
                homeXYAtEnd = o.optBoolean("homeXYAtEnd", d.homeXYAtEnd),
                addPercent = o.optBoolean("addPercent", d.addPercent),
            )
        } catch (e: Exception) {
            // повреждённые данные: остаются настройки по умолчанию
        }
    }

    fun update(s: PostSettings) {
        settings.value = s
        val o = JSONObject()
            .put("programNumber", s.programNumber).put("comment", s.comment)
            .put("useLineNumbers", s.useLineNumbers).put("lineStep", s.lineStep).put("decimals", s.decimals)
            .put("useToolLengthComp", s.useToolLengthComp).put("useCoolant", s.useCoolant)
            .put("useCutterComp", s.useCutterComp).put("useCannedDrill", s.useCannedDrill)
            .put("homeXYAtEnd", s.homeXYAtEnd).put("addPercent", s.addPercent)
        prefs?.edit()?.putString("post", o.toString())?.apply()
    }
}
