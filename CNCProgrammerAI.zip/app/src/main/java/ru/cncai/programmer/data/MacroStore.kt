package ru.cncai.programmer.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import ru.cncai.programmer.domain.MacroEntry
import ru.cncai.programmer.domain.MacroLibrary
import ru.cncai.programmer.domain.MacroParser

data class UserMacro(val id: Long, val name: String, val source: String, val args: String)

/** Пользовательские макросы (хранятся на телефоне). */
object MacroStore {
    val list = mutableStateListOf<UserMacro>()
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.getSharedPreferences("cnc_macros", Context.MODE_PRIVATE)
        val s = prefs?.getString("macros", null) ?: return
        try {
            val arr = JSONArray(s)
            val loaded = List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                UserMacro(o.getLong("id"), o.getString("name"), o.getString("source"), o.optString("args", ""))
            }
            list.clear()
            list.addAll(loaded)
        } catch (e: Exception) {
            // повреждённые данные: список остаётся пустым
        }
    }

    /** id == 0 — новый макрос. */
    fun save(m: UserMacro) {
        val i = list.indexOfFirst { it.id == m.id }
        if (m.id != 0L && i >= 0) {
            list[i] = m
        } else {
            val newId = (list.maxOfOrNull { it.id } ?: 0L) + 1
            list.add(m.copy(id = newId))
        }
        persist()
    }

    fun delete(id: Long) {
        list.removeAll { it.id == id }
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("source", it.source).put("args", it.args))
        }
        prefs?.edit()?.putString("macros", arr.toString())?.apply()
    }
}

object MacroCatalog {
    fun entries(): List<MacroEntry> =
        MacroLibrary.all.map { MacroEntry("lib_${it.id}", it.name, it.program, it.source, it.defaultArgs) } +
            list().map { MacroEntry("user_${it.id}", it.name, MacroParser.programNumber(it.source), it.source, it.args) }

    private fun list(): List<UserMacro> = MacroStore.list.toList()

    fun byRef(ref: String): MacroEntry? = entries().firstOrNull { it.ref == ref }
}
