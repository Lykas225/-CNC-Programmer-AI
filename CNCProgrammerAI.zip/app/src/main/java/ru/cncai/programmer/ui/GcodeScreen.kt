package ru.cncai.programmer.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.cncai.programmer.data.Library
import ru.cncai.programmer.data.MacroCatalog
import ru.cncai.programmer.data.PostStore
import ru.cncai.programmer.data.ProjectStore
import ru.cncai.programmer.domain.GcodeGenerator
import ru.cncai.programmer.domain.GcodeResult
import ru.cncai.programmer.domain.PostSettings
import ru.cncai.programmer.domain.ToolRef
import ru.cncai.programmer.domain.ToolSpec

private val GWarn = Color(0xFFFFB84D)
private val GErr = Color(0xFFFF6B6B)
private const val MAX_SHOWN = 400

@Composable
fun GcodeScreen(onBack: () -> Unit) {
    val project = ProjectStore.current.value
    val post = PostStore.settings.value
    var progNo by remember { mutableStateOf(post.programNumber.toString()) }
    var comment by remember { mutableStateOf(post.comment.ifBlank { project.name }) }
    var result by remember { mutableStateOf<GcodeResult?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current

    ScreenFrame("Генерация G-кода", onBack) {
        TextInput("Номер программы O", progNo) { progNo = it }
        TextInput("Комментарий (латиницей в файле)", comment) { comment = it }
        Text(
            "Стойка Fanuc 0i Plus • операций в проекте: ${project.operations.size}",
            color = Muted, fontSize = 13.sp,
        )
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = {
                val no = progNo.trim().toIntOrNull()
                if (no == null || no < 1 || no > 9999) {
                    error = "Номер программы: целое число от 1 до 9999"
                    result = null
                } else {
                    error = null
                    PostStore.update(PostStore.settings.value.copy(programNumber = no, comment = comment.trim()))
                    val tools = Library.tools.map {
                        ToolRef(it.id, ToolSpec(it.name, it.type, it.diameter, it.teeth, it.cuttingLength), it.t, it.h, it.d)
                    }
                    result = GcodeGenerator.generate(project, tools, PostStore.settings.value, Library.maxRpm.intValue, MacroCatalog.entries())
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Сформировать G-код") }
        TextButton(onClick = { showSettings = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Настройки постпроцессора")
        }
        error?.let { Text(it, color = GErr, modifier = Modifier.padding(bottom = 8.dp)) }

        result?.let { r ->
            r.errors.forEach { Text("• $it", color = GErr, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)) }
            r.warnings.forEach { Text("• $it", color = GWarn, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)) }
            if (r.lines.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Text("Строк в программе: ${r.lines.size}", fontWeight = FontWeight.SemiBold)
                Button(
                    onClick = { clipboard.setText(AnnotatedString(r.lines.joinToString("\n"))) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                ) { Text("Скопировать всю программу") }
                PanelCard {
                    Row(Modifier.horizontalScroll(rememberScrollState())) {
                        Text(
                            r.lines.take(MAX_SHOWN).joinToString("\n"),
                            fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                        )
                    }
                }
                if (r.lines.size > MAX_SHOWN) {
                    Text("Показаны первые $MAX_SHOWN строк, копируется вся программа.", color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(6.dp))
                ExportSection(
                    "O${PostStore.settings.value.programNumber}_${project.name}",
                    r.lines.joinToString("\n"),
                    "generated",
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Программа создана автоматически и не проверена на станке. Перед запуском проверьте её на холостом ходу, " +
                "корректоры H и D, нули G54–G59 и высоту отвода. Файл можно сохранить кнопками ниже.",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 16.dp),
        )
    }

    if (showSettings) PostDialog(PostStore.settings.value) { showSettings = false }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun PostDialog(s: PostSettings, onDismiss: () -> Unit) {
    var lineNumbers by remember { mutableStateOf(s.useLineNumbers) }
    var step by remember { mutableStateOf(s.lineStep.toString()) }
    var decIdx by remember { mutableIntStateOf((s.decimals - 2).coerceIn(0, 2)) }
    var g43 by remember { mutableStateOf(s.useToolLengthComp) }
    var coolant by remember { mutableStateOf(s.useCoolant) }
    var comp by remember { mutableStateOf(s.useCutterComp) }
    var canned by remember { mutableStateOf(s.useCannedDrill) }
    var homeXY by remember { mutableStateOf(s.homeXYAtEnd) }
    var percent by remember { mutableStateOf(s.addPercent) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Постпроцессор Fanuc 0i Plus") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                SwitchRow("Номера кадров N", lineNumbers) { lineNumbers = it }
                if (lineNumbers) TextInput("Шаг нумерации", step) { step = it }
                Picker("Знаков после точки", listOf("2", "3", "4"), decIdx) { decIdx = it }
                SwitchRow("Коррекция длины G43 H", g43) { g43 = it }
                SwitchRow("Охлаждение M08 / M09", coolant) { coolant = it }
                SwitchRow("Коррекция радиуса G41 на чистовых проходах", comp) { comp = it }
                if (comp) {
                    Text(
                        "Врезание в коррекцию рассчитано на тип A (стандарт для Fanuc). Проверьте значения D в корректорах.",
                        color = Muted, fontSize = 12.sp,
                    )
                }
                SwitchRow("Сверление циклом G83", canned) { canned = it }
                SwitchRow("В конце G28 X0 Y0", homeXY) { homeXY = it }
                SwitchRow("Знак % в начале и конце файла", percent) { percent = it }
                error?.let { Text(it, color = GErr) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val st = step.trim().toIntOrNull()
                if (lineNumbers && (st == null || st < 1 || st > 100)) {
                    error = "Шаг нумерации: целое число от 1 до 100"
                } else {
                    PostStore.update(
                        s.copy(
                            useLineNumbers = lineNumbers, lineStep = st ?: s.lineStep, decimals = decIdx + 2,
                            useToolLengthComp = g43, useCoolant = coolant, useCutterComp = comp,
                            useCannedDrill = canned, homeXYAtEnd = homeXY, addPercent = percent,
                        )
                    )
                    onDismiss()
                }
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
