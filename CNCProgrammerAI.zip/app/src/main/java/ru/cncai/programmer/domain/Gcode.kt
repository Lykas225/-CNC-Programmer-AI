package ru.cncai.programmer.domain

import java.util.Locale

/** Настройки постпроцессора Fanuc 0i Plus. */
data class PostSettings(
    val programNumber: Int = 1001,
    val comment: String = "",
    val useLineNumbers: Boolean = true,
    val lineStep: Int = 10,
    val decimals: Int = 3,
    val useToolLengthComp: Boolean = true,   // G43 H
    val useCoolant: Boolean = true,          // M08 / M09
    val useCutterComp: Boolean = false,      // G41 на чистовых проходах
    val useCannedDrill: Boolean = true,      // G83 вместо развёрнутых кадров
    val homeXYAtEnd: Boolean = false,        // G28 X0 Y0 в конце
    val addPercent: Boolean = false,         // знак % в начале и конце файла
)

data class ToolRef(val id: Long, val spec: ToolSpec, val t: Int, val h: Int, val d: Int)

data class GcodeResult(val lines: List<String>, val errors: List<String>, val warnings: List<String>)

private data class Planned(val index: Int, val op: OpInstance, val tool: ToolRef, val res: PlanResult)

object GcodeGenerator {

    private val TRANSLIT = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "zh",
        'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o",
        'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "kh", 'ц' to "ts",
        'ч' to "ch", 'ш' to "sh", 'щ' to "shch", 'ъ' to "", 'ы' to "y", 'ь' to "", 'э' to "e", 'ю' to "yu",
        'я' to "ya",
    )

    /** Fanuc не принимает кириллицу в комментариях: транслит, заглавные, без скобок. */
    fun ascii(text: String): String {
        val sb = StringBuilder()
        for (ch in text.lowercase()) {
            val t = TRANSLIT[ch]
            if (t != null) sb.append(t) else sb.append(ch)
        }
        val allowed = "abcdefghijklmnopqrstuvwxyz0123456789 .,+-*/#_:="
        val cleaned = sb.map { if (it in allowed) it else ' ' }.joinToString("")
        return cleaned.uppercase().replace(Regex(" +"), " ").trim()
    }

    fun fmtNum(v: Double, decimals: Int): String {
        var s = String.format(Locale.US, "%.${decimals}f", v)
        if (s.contains('.')) s = s.trimEnd('0')
        if (s == "-0.") s = "0."
        return s
    }

    private class Emitter(private val post: PostSettings) {
        val lines = ArrayList<String>()
        private var n = 0
        private var g = ""
        private var lx = ""
        private var ly = ""
        private var lz = ""
        private var lf = -1

        fun num(v: Double): String = fmtNum(v, post.decimals)

        fun raw(text: String) {
            lines.add(text)
        }

        fun comment(text: String) {
            lines.add("(" + ascii(text) + ")")
        }

        fun block(text: String) {
            n += post.lineStep
            lines.add(if (post.useLineNumbers) "N$n $text" else text)
        }

        fun resetModal() {
            g = ""
            lx = ""
            ly = ""
            lz = ""
            lf = -1
        }

        /** Запоминает позицию после ручного блока G00. */
        fun setRapidPos(x: Double, y: Double, z: Double) {
            g = "G00"
            lx = num(x)
            ly = num(y)
            lz = num(z)
        }

        fun move(m: Move, dNum: Int) {
            val parts = ArrayList<String>()
            val isArc = m.type == MoveType.ARC_CW || m.type == MoveType.ARC_CCW
            when (m.type) {
                MoveType.RAPID -> { if (g != "G00") parts.add("G00"); g = "G00" }
                MoveType.LINEAR -> { if (g != "G01") parts.add("G01"); g = "G01" }
                MoveType.COMP_LEFT -> { parts.add("G01"); parts.add("G41"); g = "G01" }
                MoveType.COMP_OFF -> { parts.add("G01"); parts.add("G40"); g = "G01" }
                MoveType.ARC_CW -> { if (g != "G02") parts.add("G02"); g = "G02" }
                MoveType.ARC_CCW -> { if (g != "G03") parts.add("G03"); g = "G03" }
            }
            val xs = num(m.x)
            val ys = num(m.y)
            val zs = num(m.z)
            if (isArc || xs != lx) parts.add("X$xs")
            if (isArc || ys != ly) parts.add("Y$ys")
            if (zs != lz) parts.add("Z$zs")
            lx = xs
            ly = ys
            lz = zs
            if (isArc) {
                val i = num(m.i)
                val j = num(m.j)
                if (i != "0.") parts.add("I$i")
                if (j != "0.") parts.add("J$j")
            }
            if (m.type == MoveType.COMP_LEFT) parts.add("D$dNum")
            if (m.type != MoveType.RAPID) {
                if (m.feed != lf) parts.add("F${m.feed}")
                lf = m.feed
            }
            if (parts.isNotEmpty()) block(parts.joinToString(" "))
        }
    }

    fun generate(project: Project, tools: List<ToolRef>, post: PostSettings, maxRpm: Int): GcodeResult {
        val errors = ArrayList<String>()
        val warnings = ArrayList<String>()
        if (project.operations.isEmpty()) {
            return GcodeResult(emptyList(), listOf("В проекте нет операций: добавьте их в разделе «Операции обработки»"), emptyList())
        }
        val planned = ArrayList<Planned>()
        project.operations.forEachIndexed { idx, op ->
            val title = Operations.byId(op.kind)?.title ?: op.kind
            val tool = tools.firstOrNull { it.id == op.toolId }
            if (tool == null) {
                errors.add("Операция ${idx + 1} ($title): инструмент удалён из библиотеки")
            } else {
                val out = OperationPlanner.plan(project, op, tool.spec, maxRpm, post.useCutterComp)
                val r = out.result
                if (r == null) {
                    errors.add("Операция ${idx + 1} ($title): ${out.error}")
                } else {
                    planned.add(Planned(idx, op, tool, r))
                    r.warnings.forEach { warnings.add("Операция ${idx + 1}: $it") }
                }
            }
        }
        if (errors.isNotEmpty()) return GcodeResult(emptyList(), errors, warnings)

        val part = project.part
        val zTop = if (part.zeroZ == ZeroZ.TOP) 0.0 else part.thickness
        val w = Emitter(post)
        if (post.addPercent) w.raw("%")
        val name = post.comment.ifBlank { project.name }
        w.raw("O" + post.programNumber.toString().padStart(4, '0') + " (" + ascii(name) + ")")
        w.comment("UP SOZDANA PRILOZHENIEM. PROVERIT PERED ZAPUSKOM NA STANKE")
        w.comment("DETAL " + ascii(part.shape.title) + " " + w.num(part.sizeX) +
            (if (part.shape == PartShape.RECT) " X " + w.num(part.sizeY) else "") + " X " + w.num(part.thickness))
        w.comment("MATERIAL " + part.materialName)
        w.comment("NOL: " + part.zeroXY.title + ", " + part.zeroZ.title + ", " + part.wcs)
        w.block("G21 G17 G40 G49 G80 G90")

        var prevToolId = -1L
        planned.forEachIndexed { pi, p ->
            val op = p.op
            val tool = p.tool
            val res = p.res
            val title = Operations.byId(op.kind)?.title ?: op.kind
            w.comment("OPERACIYA ${p.index + 1}: $title")
            w.comment("T${tool.t} ${tool.spec.name}")
            if (prevToolId != tool.id) w.block("T${tool.t} M06")
            w.block("G90 ${part.wcs}")
            w.block("S${res.rpm} M03")
            w.resetModal()

            val useCanned = op.kind == "drill" && post.useCannedDrill
            if (useCanned) {
                val targets = OperationPlanner.drillTargets(project, op, tool.spec.diameter)
                val zSafe = zTop + op.safeZ
                val zR = zTop + 2.0
                val t0 = targets[0]
                w.block("G00 X${w.num(t0.x)} Y${w.num(t0.y)}")
                if (post.useToolLengthComp) w.block("G43 H${tool.h} Z${w.num(zSafe)}") else w.block("G00 Z${w.num(zSafe)}")
                if (post.useCoolant) w.block("M08")
                w.block(
                    "G98 G83 X${w.num(t0.x)} Y${w.num(t0.y)} Z${w.num(t0.zBottom)} R${w.num(zR)} " +
                        "Q${w.num(op.ap)} F${res.feed}"
                )
                for (k in 1 until targets.size) {
                    w.block("X${w.num(targets[k].x)} Y${w.num(targets[k].y)}")
                }
                w.block("G80")
            } else {
                val moves = res.moves
                val first = moves[0]
                w.block("G00 X${w.num(first.x)} Y${w.num(first.y)}" +
                    (if (post.useToolLengthComp) "" else " Z${w.num(first.z)}"))
                if (post.useToolLengthComp) w.block("G43 H${tool.h} Z${w.num(first.z)}")
                w.setRapidPos(first.x, first.y, first.z)
                if (post.useCoolant) w.block("M08")
                for (k in 1 until moves.size) w.move(moves[k], tool.d)
            }

            if (post.useCoolant) w.block("M09")
            val last = pi == planned.size - 1
            val nextToolDiffers = !last && planned[pi + 1].tool.id != tool.id
            if (last || nextToolDiffers) {
                w.block("G49")
                w.block("G91 G28 Z0.")
                if (last && post.homeXYAtEnd) w.block("G28 X0. Y0.")
                w.block("G90")
                w.block("M05")
            }
            prevToolId = tool.id
        }
        w.block("M30")
        if (post.addPercent) w.raw("%")
        return GcodeResult(w.lines, emptyList(), warnings)
    }
}
