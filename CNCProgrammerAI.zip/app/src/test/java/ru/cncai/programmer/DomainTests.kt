package ru.cncai.programmer

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import ru.cncai.programmer.domain.CheckContext
import ru.cncai.programmer.domain.CheckSeverity
import ru.cncai.programmer.domain.CheckTool
import ru.cncai.programmer.domain.CompApplier
import ru.cncai.programmer.domain.CuttingCalculator
import ru.cncai.programmer.domain.CuttingInput
import ru.cncai.programmer.domain.ExportFormat
import ru.cncai.programmer.domain.Feature
import ru.cncai.programmer.domain.FeatureType
import ru.cncai.programmer.domain.GcodeGenerator
import ru.cncai.programmer.domain.MacroArgs
import ru.cncai.programmer.domain.MacroChecker
import ru.cncai.programmer.domain.MacroLibrary
import ru.cncai.programmer.domain.MacroRunner
import ru.cncai.programmer.domain.MoveType
import ru.cncai.programmer.domain.OpInstance
import ru.cncai.programmer.domain.Part
import ru.cncai.programmer.domain.PartShape
import ru.cncai.programmer.domain.PostSettings
import ru.cncai.programmer.domain.ProgramChecker
import ru.cncai.programmer.domain.ProgramExport
import ru.cncai.programmer.domain.ProgramFormatter
import ru.cncai.programmer.domain.Project
import ru.cncai.programmer.domain.SimBuilder
import ru.cncai.programmer.domain.SimState
import ru.cncai.programmer.domain.SimStock
import ru.cncai.programmer.domain.SimTool
import ru.cncai.programmer.domain.ToolRef
import ru.cncai.programmer.domain.ToolSpec
import ru.cncai.programmer.domain.ZeroXY
import ru.cncai.programmer.domain.ZeroZ

class DomainTests {
    private val tools = listOf(
        ToolRef(1, ToolSpec("End mill 10", "Концевая фреза", 10.0, 4, 22.0), 1, 1, 1),
        ToolRef(2, ToolSpec("Drill 8.5", "Сверло", 8.5, 2, 60.0), 2, 2, 2),
    )

    private fun project(): Project {
        val part = Part(PartShape.RECT, 100.0, 70.0, 20.0, ZeroXY.CORNER_LL, ZeroZ.TOP, "G54", "Сталь 45")
        val pocket = Feature(1, FeatureType.RECT_POCKET, 50.0, 35.0, 0.0, 0.0, 60.0, 40.0, 5.0, 8.0)
        val hole = Feature(2, FeatureType.HOLE, 15.0, 15.0, 0.0, 0.0, 8.5, 0.0, 0.0, 10.0)
        val op1 = OpInstance(1, "pocket_rect", 1, 1, 150.0, 0.06, 4.0, 4.0, 0.3, 0.0, 0.0, 5.0)
        val op2 = OpInstance(2, "drill", 0, 2, 25.0, 0.05, 3.0, 1.0, 2.5, 0.0, 0.0, 5.0)
        return Project("Test", part, listOf(pocket, hole), listOf(op1, op2))
    }

    private fun checkCtx(p: Project) =
        CheckContext(p.part, tools.map { CheckTool(it.t, it.spec.name, it.spec.diameter / 2, it.d, it.h, false) }, 8000)

    @Test
    fun cuttingRpmAndFeed() {
        val r = CuttingCalculator.plan(
            CuttingInput(150.0, 10.0, 4, 0.06, 8000, 22.0, 5.0, 4.0, 10.0, 10.0, 100.0, 0.5)
        )
        assertEquals(4775, r.rpm)
        assertEquals(1146, r.feed)
        assertEquals(2, r.axialPasses)
        assertEquals(3, r.radialPasses)
    }

    @Test
    fun libraryMacrosAreValidAndRun() {
        for (t in MacroLibrary.all) {
            val errs = MacroChecker.check(t.source).filter { it.isError }
            assertTrue("${t.id}: $errs", errs.isEmpty())
            val parsed = MacroArgs.parse(t.defaultArgs)
            assertNull("${t.id}: ${parsed.second}", parsed.second)
            val run = MacroRunner.run(t.source, parsed.first, Triple(0.0, 0.0, 50.0))
            assertTrue("${t.id}: ${run.errors}", run.errors.isEmpty())
            assertTrue("${t.id}: нет кадров", run.blocks.isNotEmpty())
        }
    }

    @Test
    fun macroLoopsAndAlarms() {
        val src = "O1\n#100=0\nWHILE [#100 LT 3] DO 1\n#100=#100+1\nEND 1\nM99\n"
        val r = MacroRunner.run(src, emptyMap(), Triple(0.0, 0.0, 0.0))
        assertTrue(r.errors.toString(), r.errors.isEmpty())
        assertEquals(3.0, r.globals[100]!!, 1e-9)
        val alarm = MacroRunner.run("O1\nIF [#4 LE 0] THEN #3000=1 (NO SIZE)\nM99\n", emptyMap(), Triple(0.0, 0.0, 0.0))
        assertTrue(alarm.errors.any { it.contains("ALARM") })
    }

    @Test
    fun generatedProgramPassesChecker() {
        val p = project()
        val g = GcodeGenerator.generate(p, tools, PostSettings(), 8000)
        assertTrue(g.errors.toString(), g.errors.isEmpty())
        val text = g.lines.joinToString("\n")
        assertTrue(text.contains("M30"))
        assertTrue(text.contains("S4775"))
        val rep = ProgramChecker.check(text, checkCtx(p))
        val errs = rep.issues.filter { it.severity == CheckSeverity.ERROR }
        assertTrue(errs.toString(), errs.isEmpty())
    }

    @Test
    fun compensationIsAppliedInSimulation() {
        val p = project()
        val g = GcodeGenerator.generate(p, tools, PostSettings(useCutterComp = true), 8000)
        assertTrue(g.errors.toString(), g.errors.isEmpty())
        val text = g.lines.joinToString("\n")
        assertTrue(text.contains("G41"))
        val run = MacroRunner.run(text, emptyMap(), Triple(0.0, 0.0, 100.0))
        assertTrue(run.errors.toString(), run.errors.isEmpty())
        assertTrue(run.moves.any { it.type == MoveType.COMP_LEFT })
        val comp = CompApplier.apply(run.moves, run.infos, mapOf(1 to 5.0, 2 to 4.25))
        assertTrue(comp.moves.none { it.type == MoveType.COMP_LEFT || it.type == MoveType.COMP_OFF })
    }

    @Test
    fun simulationRemovesMaterial() {
        val p = project()
        val g = GcodeGenerator.generate(p, tools, PostSettings(), 8000)
        val run = MacroRunner.run(g.lines.joinToString("\n"), emptyMap(), Triple(0.0, 0.0, 100.0))
        assertTrue(run.errors.toString(), run.errors.isEmpty())
        val comp = CompApplier.apply(run.moves, run.infos, mapOf(1 to 5.0, 2 to 4.25))
        val stock = SimStock(p.part)
        val path = SimBuilder.build(comp.moves, comp.infos, stock.cs * 0.5)
        val simTools = mapOf(1 to SimTool(1, "End mill", 5.0, false), 2 to SimTool(2, "Drill", 4.25, false))
        val state = SimState(stock, path, simTools)
        state.analyze()
        state.seek(path.n - 1)
        val minH = state.h.minOrNull() ?: 0f
        assertTrue("глубина кармана 8 мм, получили $minH", minH < -7.0f)
        assertTrue(state.issues.toString(), state.issues.isEmpty())
    }

    @Test
    fun formatterSplitsWordsAndRenumbers() {
        assertEquals("N10 G01 X10. Y5. F300", ProgramFormatter.format("g01x10.y5.f300", true, 10))
    }

    @Test
    fun exportFormats() {
        val tap = ProgramExport.text("O1 (TEST)\nM30", ExportFormat.TAP)
        assertTrue(tap.startsWith("%\r\n"))
        assertTrue(tap.trimEnd().endsWith("%"))
        assertTrue(ProgramExport.text("N10 G01 X10. Y5.", ExportFormat.EIA).contains("N10G01X10.Y5."))
        assertTrue(ProgramExport.text("(Корпус)", ExportFormat.NC).contains("KORPUS"))
        assertEquals("O1001_KORPUS_001.NC", ProgramExport.fileName("O1001 Корпус_001", ExportFormat.NC))
    }
}
